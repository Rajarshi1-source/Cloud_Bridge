#!/usr/bin/env python3
"""Grade each run's answer against its assertions with a headless `claude -p` grader (blind to configuration).
Writes <run>/grading.json with skill-creator's field names (text / passed / evidence)."""
import argparse, json, os, re, shutil, subprocess, tempfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

PROMPT = """You are a strict grader. Read the answer file at ./answer.md (it is a response to the task below).
For EACH expectation decide PASS only if the answer clearly and substantively satisfies it (not merely mentions a keyword).
When unsure, FAIL. Cite a short quote or precise description as evidence.

TASK GIVEN TO THE AUTHOR:
{prompt}

EXPECTATIONS (grade every one, in order):
{expectations}

Reply with ONLY a JSON object, no prose, exactly:
{{"expectations": [{{"text": "<expectation verbatim>", "passed": true|false, "evidence": "<= 40 words"}}], "eval_feedback": "<one sentence on weak or missing assertions, or empty>"}}"""

def grade(run_dir: Path, meta: dict, model: str) -> dict:
    proj = Path(tempfile.mkdtemp(prefix="cbgrade-"))
    try:
        shutil.copy(run_dir / "outputs" / "answer.md", proj / "answer.md")
        exp = "\n".join(f"{i+1}. {a}" for i, a in enumerate(meta["assertions"]))
        cmd = ["claude", "-p", PROMPT.format(prompt=meta["prompt"], expectations=exp), "--output-format", "json",
               "--model", model, "--max-turns", "8", "--allowedTools", "Read",
               "--disallowedTools", "Bash,Write,Edit,WebSearch,WebFetch,Skill,Agent"]
        env = {k: v for k, v in os.environ.items() if k != "CLAUDECODE"}
        last = ""
        for attempt in range(3):
            p = subprocess.run(cmd, cwd=proj, env=env, capture_output=True, text=True, timeout=600,
                               stdin=subprocess.DEVNULL)
            try:
                out = json.loads(p.stdout)
            except json.JSONDecodeError:
                last = (p.stdout or p.stderr)[:400]
                continue
            text = out.get("result") or ""
            if out.get("is_error") or "limit" in text.lower() and "reset" in text.lower():
                last = f"is_error/subtype={out.get('subtype')}: {text[:300]}"
                continue
            m = re.search(r"\{.*\}", text, re.S)
            if not m:
                last = f"no JSON in result (subtype={out.get('subtype')}): {text[:300]}"
                continue
            g = json.loads(m.group(0))
            break
        else:
            raise RuntimeError(f"grader failed 3x: {last}")
        exps = g["expectations"]
        passed = sum(bool(e["passed"]) for e in exps)
        g["summary"] = {"passed": passed, "failed": len(exps) - passed, "total": len(exps),
                        "pass_rate": round(passed / len(exps), 3) if exps else 0}
        return g
    finally:
        shutil.rmtree(proj, ignore_errors=True)

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--iteration", required=True)
    ap.add_argument("--model", default="claude-opus-5-5")
    ap.add_argument("--workers", type=int, default=4)
    a = ap.parse_args()
    it = Path(a.iteration)
    jobs = []
    for meta_p in sorted(it.glob("*/eval_metadata.json")):
        meta = json.loads(meta_p.read_text())
        for cfg in ("with_skill", "without_skill"):
            rd = meta_p.parent / cfg
            if (rd / "outputs" / "answer.md").exists() and (rd / "outputs" / "answer.md").read_text().strip() \
               and not (rd / "grading.json").exists():
                jobs.append((rd, meta))
    with ThreadPoolExecutor(max_workers=a.workers) as ex:
        futs = {ex.submit(grade, rd, m, a.model): rd for rd, m in jobs}
        for f in as_completed(futs):
            rd = futs[f]
            try:
                g = f.result()
                (rd / "grading.json").write_text(json.dumps(g, indent=2))
                print(f"{rd.parent.name:<34} {rd.name:<14} {g['summary']['passed']}/{g['summary']['total']}", flush=True)
            except Exception as e:
                print(f"{rd.parent.name:<34} {rd.name:<14} GRADE ERROR {e}", flush=True)

if __name__ == "__main__":
    main()
