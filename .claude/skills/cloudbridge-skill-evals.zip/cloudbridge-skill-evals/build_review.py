#!/usr/bin/env python3
"""Lay graded runs out the way skill-creator's aggregate_benchmark/generate_review expect:
<dest>/eval-<name>/<config>/run-1/{grading.json,timing.json,outputs/}. `--overlay` lets a later
iteration's with_skill reruns replace the earlier ones (the 'final' view)."""
import argparse, shutil
from pathlib import Path
ap = argparse.ArgumentParser()
ap.add_argument("--base", required=True); ap.add_argument("--overlay", nargs="*", default=[]); ap.add_argument("--dest", required=True)
a = ap.parse_args()
dest = Path(a.dest); shutil.rmtree(dest, ignore_errors=True)
def place(src_eval: Path, cfgs):
    e = dest / f"eval-{src_eval.name}"; e.mkdir(parents=True, exist_ok=True)
    shutil.copy(src_eval / "eval_metadata.json", e / "eval_metadata.json")
    for c in cfgs:
        s = src_eval / c
        if not (s / "grading.json").exists(): continue
        r = e / c / "run-1"; shutil.rmtree(r, ignore_errors=True); r.mkdir(parents=True)
        for f in ("grading.json", "timing.json", "transcript.json"):
            if (s / f).exists(): shutil.copy(s / f, r / f)
        shutil.copytree(s / "outputs", r / "outputs")
for ev in sorted(Path(a.base).iterdir()):
    if (ev / "eval_metadata.json").exists(): place(ev, ["with_skill", "without_skill"])
for ov in a.overlay:
    for ev in sorted(Path(ov).iterdir()):
        if (ev / "eval_metadata.json").exists(): place(ev, ["with_skill"])
print("built", dest, len(list(dest.glob("eval-*"))), "evals")
