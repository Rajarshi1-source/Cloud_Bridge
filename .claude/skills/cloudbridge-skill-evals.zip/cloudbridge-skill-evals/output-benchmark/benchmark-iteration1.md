# Skill Benchmark: cloudbridge-skills

**Model**: <model-name>
**Date**: 2026-10-09T20:07:55Z
**Evals**: 1, 2, 3 (3 runs each per configuration)

## Summary

| Metric | With Skill | Without Skill | Delta |
|--------|------------|---------------|-------|
| Pass Rate | 93% ± 13% | 41% ± 22% | +0.51 |
| Time | 74.4s ± 64.2s | 53.4s ± 62.3s | +21.0s |
| Tokens | 209002 ± 117326 | 132045 ± 163892 | +76957 |