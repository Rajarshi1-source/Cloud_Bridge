# Skill Benchmark: cloudbridge-skills

**Model**: <model-name>
**Date**: 2026-10-09T20:07:55Z
**Evals**: 1, 2, 3 (3 runs each per configuration)

## Summary

| Metric | With Skill | Without Skill | Delta |
|--------|------------|---------------|-------|
| Pass Rate | 100% ± 0% | 41% ± 22% | +0.59 |
| Time | 70.9s ± 64.1s | 53.4s ± 62.3s | +17.5s |
| Tokens | 202193 ± 111079 | 132045 ± 163892 | +70147 |