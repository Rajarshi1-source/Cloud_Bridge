The working directory (`/tmp/cbout-4i8uf6qh`) is empty, so I couldn't find an existing parity harness to add this to. This session also has no tool for writing files, so I haven't saved anything. Below is a standalone check you can drop into your repo.

It connects to both databases and reads the live values from `pg_settings`, rather than reading the RDS parameter group or Cloud SQL flags. That matters because RDS often sets `max_connections` with a formula based on instance memory. It also compares `statement_timeout` overrides set per role or per database with `ALTER ROLE/DATABASE ... SET`, because those can differ even when the server-level values match.

```python
#!/usr/bin/env python3
"""Parity check: Postgres max_connections and statement_timeout, RDS vs Cloud SQL.

Usage:
    RDS_DSN=postgresql://... CLOUDSQL_DSN=postgresql://... ./pg_settings_parity.py
Exits 1 if any value differs, 2 if either side can't be reached.
"""
import os
import sys

import psycopg

SETTINGS = ["max_connections", "statement_timeout"]

# Provider-managed roles that exist on only one side; their overrides aren't drift.
MANAGED_ROLES = {"rdsadmin", "rds_superuser", "cloudsqladmin", "cloudsqlsuperuser", "cloudsqlagent"}


def fetch(dsn):
    with psycopg.connect(dsn, connect_timeout=10) as conn:
        settings = {
            name: (setting, unit, source)
            for name, setting, unit, source in conn.execute(
                "SELECT name, setting, unit, source FROM pg_settings WHERE name = ANY(%s)",
                (SETTINGS,),
            )
        }
        overrides = {
            (role, db, cfg)
            for role, db, cfg in conn.execute(
                """
                SELECT coalesce(r.rolname, '*'), coalesce(d.datname, '*'), cfg
                FROM pg_db_role_setting s
                LEFT JOIN pg_roles r ON r.oid = s.setrole
                LEFT JOIN pg_database d ON d.oid = s.setdatabase
                CROSS JOIN LATERAL unnest(s.setconfig) AS cfg
                WHERE cfg LIKE 'statement_timeout=%%'
                """
            )
            if role not in MANAGED_ROLES
        }
    return settings, overrides


def main():
    try:
        rds_settings, rds_overrides = fetch(os.environ["RDS_DSN"])
        gcp_settings, gcp_overrides = fetch(os.environ["CLOUDSQL_DSN"])
    except (KeyError, psycopg.Error) as e:
        print(f"ERROR: {e!r}", file=sys.stderr)
        return 2

    failed = False
    print(f"{'setting':<20} {'rds':>12} {'cloudsql':>12}  status")
    for name in SETTINGS:
        rds_val, unit, rds_src = rds_settings[name]
        gcp_val, _, gcp_src = gcp_settings[name]
        ok = int(rds_val) == int(gcp_val)
        failed |= not ok
        suffix = f" {unit}" if unit else ""
        print(
            f"{name:<20} {rds_val + suffix:>12} {gcp_val + suffix:>12}  "
            f"{'OK' if ok else 'MISMATCH'}  (source: rds={rds_src}, cloudsql={gcp_src})"
        )

    for label, only in (("RDS only", rds_overrides - gcp_overrides),
                        ("Cloud SQL only", gcp_overrides - rds_overrides)):
        for role, db, cfg in sorted(only):
            failed = True
            print(f"OVERRIDE MISMATCH ({label}): role={role} db={db} {cfg}")

    print("FAIL" if failed else "PASS")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
```

- **Requirements:** `psycopg` (v3) and a login on each instance. Any login works, because `pg_settings` and `pg_db_role_setting` can be read without superuser.
- **Session effects:** if the role you connect with has its own `statement_timeout` override, the value shown includes it. In that case the `source` column says `user` or `database` instead of `configuration file`. Use a role with no overrides to see the server default.
- **`max_connections` usually differs during a migration** because the instance sizes are different. If that difference is expected, change that row to warn instead of fail.

If you already have a parity-check suite, tell me which repo and pattern to follow and I'll fit this into it.