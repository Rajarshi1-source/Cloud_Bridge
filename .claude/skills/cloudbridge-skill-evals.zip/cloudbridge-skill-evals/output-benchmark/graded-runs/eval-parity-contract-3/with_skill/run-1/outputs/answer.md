I couldn't write any files. This workspace only contains the `.claude/skills/` docs, with no `parity/`, `control-plane/` or `evals/` directories, and this session has no tool for writing files. So nothing has been run. Below is the full change for you to apply. It follows the skill's four-step "Adding a check" process and builds on its starter code.

## Design

- **Two separate checks, not one.** Each gets its own finding and can have its own exception, and the contract and engine stay as they are.
- **Weight 3 for both,** the same as `hpa.max`. Both decide whether the surviving cell can take all the traffic during an evacuation:
  - If `max_connections` differs, roughly twice the pods can run out of connections on one cloud but not the other.
  - If `statement_timeout` differs, the same slow query fails on one cloud and keeps running on the other.
- **Read the live values over SQL, not from the RDS or Cloud SQL APIs.** The cloud APIs give misleading answers here:
  - RDS reports `max_connections` as a formula, `{DBInstanceClassMemory/9531392}`, not a number.
  - Cloud SQL only reports flags someone has explicitly set.
  - Comparing those would show a difference even when the actual settings are the same. Reading `pg_settings` gives the value Postgres is actually using.
  - Because the code goes in `BaseFacts`, it also works for the k3s budget cells.
- **`statement_timeout` is checked for each app role** (`order_svc` and `inventory_svc`), applying Postgres's own override order. A per-role setting overrides the server value, so that is what the services actually get.
  - If the parity user has its own timeout override, the server value is hidden from it. In that case the check returns `unknown` rather than guessing.
- **Both settings come out of `pg_params_allowlist`** so they aren't counted twice.

## 1. `parity/contract.yaml` (and `contract-budget.yaml`)

```yaml
checks:
  # ... existing checks ...
  - { id: pg.max_connections,   source: database.max_connections,      weight: 3 }
  - { id: pg.statement_timeout, source: database.statement_timeout_ms, weight: 3 }
pg_app_roles: [order_svc, inventory_svc]
pg_params_allowlist: [idle_in_transaction_session_timeout, work_mem, shared_preload_libraries]
```
Add both checks to the budget contract as well. Unlike `pg.params`, they don't depend on the managed-database APIs.

## 2. `control-plane/parity-checker/parity/facts.py`: add to `BaseFacts`

```python
import re   # add to the imports

_PG_TIME_UNITS_MS = {"us": 0.001, "ms": 1, "s": 1_000, "min": 60_000, "h": 3_600_000, "d": 86_400_000}
_PG_SERVER_SOURCES = {"default", "configuration file"}

def pg_duration_ms(raw: str) -> int:
    """'30s', '30000', '1.5min', '500 ms' → milliseconds. A bare number is ms (statement_timeout's base unit)."""
    m = re.fullmatch(r"([0-9]+(?:\.[0-9]+)?)\s*([a-z]*)", raw.strip().strip("'\"").lower())
    if not m or m.group(2) not in _PG_TIME_UNITS_MS | {"": 1}:
        raise ValueError(f"unparseable duration {raw!r}")
    return round(float(m.group(1)) * _PG_TIME_UNITS_MS.get(m.group(2), 1))

class BaseFacts:
    # ... existing code ...

    # ---- Postgres limits: live values over SQL, same path for RDS, Cloud SQL and k3s ----
    def fact_database_max_connections(self) -> int:
        import psycopg
        with psycopg.connect(self.dsn, connect_timeout=5) as c:
            return int(c.execute("select setting from pg_settings where name = 'max_connections'").fetchone()[0])

    def fact_database_statement_timeout_ms(self) -> dict[str, int]:
        """Effective statement_timeout per app role: role+db > role > db > server (Postgres precedence)."""
        import psycopg
        out: dict[str, int] = {}
        with psycopg.connect(self.dsn, connect_timeout=5) as c:
            setting, source = c.execute(
                "select setting, source from pg_settings where name = 'statement_timeout'").fetchone()
            for role in self.contract["pg_app_roles"]:
                if c.execute("select 1 from pg_roles where rolname = %s", (role,)).fetchone() is None:
                    raise FactUnavailable(f"app role {role} not found")
                row = c.execute("""
                    select split_part(cfg, '=', 2)
                    from pg_db_role_setting s, unnest(s.setconfig) as cfg
                    where s.setrole in (0, (select oid from pg_roles where rolname = %(role)s))
                      and s.setdatabase in (0, (select oid from pg_database where datname = current_database()))
                      and not (s.setrole = 0 and s.setdatabase = 0)
                      and split_part(cfg, '=', 1) = 'statement_timeout'
                    order by 2 * (s.setrole <> 0)::int + (s.setdatabase <> 0)::int desc
                    limit 1""", {"role": role}).fetchone()
                if row:
                    out[role] = pg_duration_ms(row[0])
                elif source in _PG_SERVER_SOURCES:
                    out[role] = int(setting)                     # pg_settings reports ms
                else:
                    # parity_reader's own session override hides the server value — don't guess
                    raise FactUnavailable(f"statement_timeout source={source} for parity user; server value not visible")
        return out
```
These use the existing `parity_reader` user and `dsn`. All Postgres users can read `pg_settings` and `pg_db_role_setting`, so no new grants are needed. A unit it can't parse raises `ValueError`, which `get()` already turns into `unknown`.

## 3. Eval fixtures: append to `evals/parity/cases.yaml`

```yaml
- name: pg-limits-match
  now: "2026-10-08T10:00:00Z"
  facts:
    cb-aws-prod: &pglim
      database.max_connections: 400
      database.statement_timeout_ms: { order_svc: 30000, inventory_svc: 30000 }
    cb-gcp-prod: *pglim
  expect: { pg.max_connections: match, pg.statement_timeout: match }

- name: pg-max-connections-memory-default-differs   # RDS and Cloud SQL derive the default from RAM differently
  now: "2026-10-08T10:00:00Z"
  facts:
    cb-aws-prod: { database.max_connections: 410 }
    cb-gcp-prod: { database.max_connections: 400 }
  expect: { pg.max_connections: diverged }

- name: pg-statement-timeout-role-override-one-cell
  now: "2026-10-08T10:00:00Z"
  facts:
    cb-aws-prod: { database.statement_timeout_ms: { order_svc: 30000, inventory_svc: 30000 } }
    cb-gcp-prod: { database.statement_timeout_ms: { order_svc: 30000, inventory_svc: 0 } }
  expect: { pg.statement_timeout: diverged }

- name: pg-statement-timeout-unreadable
  now: "2026-10-08T10:00:00Z"
  facts:
    cb-aws-prod: { database.statement_timeout_ms: { order_svc: 30000, inventory_svc: 30000 } }
    cb-gcp-prod: { database.statement_timeout_ms: "!unavailable" }
  expect: { pg.statement_timeout: unknown }
```

The eval's fake adapters skip the real readers, so the unit parsing needs its own test, `control-plane/parity-checker/tests/test_pg_limits.py`:

```python
import pytest
from parity.facts import pg_duration_ms

@pytest.mark.parametrize("raw,ms", [("30000", 30000), ("30s", 30000), ("30 s", 30000),
                                    ("1.5min", 90000), ("500ms", 500), ("'1h'", 3_600_000), ("0", 0)])
def test_units_normalise(raw, ms):
    assert pg_duration_ms(raw) == ms

def test_unknown_unit_raises():
    with pytest.raises(ValueError):
        pg_duration_ms("30 fortnights")
```

## Before you merge

- **`max_connections` will probably fail on the first run.** If neither database sets it explicitly, each cloud works out its own default from instance memory using a different formula. The fix is to set the same explicit value on both clouds in the Terraform cell module, through the RDS parameter group and the Cloud SQL `database_flags`. Don't add an exception for it, because the two values aren't meant to differ.
- **No `docs/leaky-abstractions.md` allowlist rule is needed,** since neither setting should legitimately differ between clouds. It's still worth one line there noting that RDS reports `max_connections` as a formula, which is why this check reads the value over SQL.
- **The new weights change scores.** The total weight goes from 36 to 42, so earlier snapshot scores aren't directly comparable with new ones.