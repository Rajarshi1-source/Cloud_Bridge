I couldn't make the fix: the recommender code isn't in this directory. `/tmp/cbout-4uj999xc` only holds `.claude/skills/`. There's no `control-plane/steering/recommender.py`, no weekly job and no `evals/steering/`. The skill does include reference code for the recommender, and reading it turned up likely causes. **Where does the steering code live?** Send me the path or repo and I'll make the change there.

The reference has three guards meant to stop this kind of week-to-week flip-flopping. In each one, the guard can exist in the code and still never run because it isn't given its inputs:

1. **Significance test (2σ): probably not getting its inputs.** It only works if each `CellModel` gets `marginal_se` from `fit_cost`. If that isn't passed, it defaults to `0.0`, so any tiny cost difference counts as real and noise moves traffic. Check that the weekly job passes `se` through.

2. **Reversal hysteresis: broken in the reference code itself.** `last_direction()` in the weekly job (`starter-code.md` §6b) needs two rows in `traffic_changes` with `source = 'recommender'`. The original 70/30 wasn't set by the recommender, so after its first move to 50/50 there is only one such row. The function then returns `0`, and the higher bar for reversing last week's move is skipped. That is exactly when 50 → 70 gets through. The fix is to compare the latest recommender change with the weight in effect just before it, from any source:
   ```python
   def last_direction(conn) -> int:
       """Direction of the last *recommender* change, relative to whatever weight preceded it."""
       row = conn.execute("""
           SELECT (r.weights->>'aws')::int,
                  (SELECT (p.weights->>'aws')::int FROM traffic_changes p
                    WHERE p.applied_at < r.applied_at ORDER BY p.applied_at DESC LIMIT 1)
             FROM traffic_changes r
            WHERE r.source = 'recommender'
            ORDER BY r.applied_at DESC LIMIT 1""").fetchone()
       if not row or row[1] is None:
           return 0
       return (row[0] > row[1]) - (row[0] < row[1])
   ```

3. **Maximum weekly step: too large.** A 20-point jump means the limit is still 0.20, so the cap for when latency data is thin isn't kicking in. Either `distinct_shares` isn't passed (if it's missing, the code falls back to 0.20) or the fit already covers three or more shares. Set the limit to 0.10 outright until the latency fit covers more shares.

I'd also add a regression test so this can't come back. The backtest reference already has a scenario for this, `small-gap-near-noise-no-oscillation`, which expects zero reversals. It only catches the bug in item 2 if it feeds `last_direction` the same way production does. Right now the backtest tracks the direction in memory, so it passes while production still oscillates. It should start from a 70/30 change made by someone other than the recommender and call the real `last_direction()`.