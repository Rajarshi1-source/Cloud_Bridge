I couldn't find the steering recommender's code. `/tmp/cbout-q4dq1abo` is empty, and nothing else on this machine looks like the service. So I haven't changed anything yet. Send me the repo path or paste the decision function and I'll put the fix in.

Until then, here's what's most likely wrong and how I'd fix it.

## Why it flips every week

A recommendation that swings 70/30 → 50/50 → 70/30 means the recommender has no damping. Usually it's several of these together:

1. **It reacts to its own changes.** Moving traffic changes the costs it measures next week. For example, at 50/50 your committed-use discount on provider A goes underused, so A's cost per unit looks worse and it recommends 70/30 again. At 70/30, B looks cheaper and it recommends 50/50.
2. **It acts on any improvement.** If 50/50 is projected to be 0.3% cheaper, it recommends the switch, even when that saving is smaller than week-to-week noise or the cost of switching (egress, cache warm-up, risk).
3. **It looks at one week of noisy data.** A single week's numbers bounce enough to cross the decision point back and forth.
4. **It jumps straight to the new split** instead of moving gradually.

## The fix: add hysteresis to the decision

```python
from dataclasses import dataclass

@dataclass
class SteeringPolicy:
    min_savings_pct: float = 0.03      # need ≥3% projected savings to act...
    min_savings_abs: float = 500.0     # ...and at least $500/week
    switch_cost: float = 200.0         # egress/cache warm-up cost of moving traffic
    min_dwell_weeks: int = 4           # hold a split this long before changing it
    max_step_pp: int = 10              # move at most 10 points per cycle
    ewma_alpha: float = 0.3            # smooth weekly cost inputs

def recommend(current_split, candidate_split, history, weeks_since_change, policy):
    # 1. Smooth inputs instead of using last week raw
    unit_cost = ewma(history, policy.ewma_alpha)

    # 2. Price both splits with the same model, including commit/tier effects,
    #    so the side that just lost traffic isn't penalized for unused commitment
    cost_now  = project_cost(current_split, unit_cost)
    cost_cand = project_cost(candidate_split, unit_cost)
    savings = cost_now - cost_cand - policy.switch_cost

    # 3. Deadband: ignore changes that are too small to matter
    if savings < max(policy.min_savings_abs, policy.min_savings_pct * cost_now):
        return current_split

    # 4. Minimum dwell time
    if weeks_since_change < policy.min_dwell_weeks:
        return current_split

    # 5. Step limit: move toward the target gradually
    delta = candidate_split - current_split
    step = max(-policy.max_step_pp, min(policy.max_step_pp, delta))
    return current_split + step
```

What matters most, in order:
- **The deadband plus `switch_cost`** stops it from chasing small savings.
- **`project_cost` modeling the committed-use discount and pricing tiers** fixes the root cause. If the model only multiplies observed cost per unit by volume, the system keeps oscillating, and the deadband only hides it.
- **The minimum hold time and step limit** stop it flipping even when the signal really is close to even.

## How to check it worked

Replay the last 8–12 weeks of cost data through the old and new logic. With the old logic you should see the 70/30 ↔ 50/50 alternation. With the new logic the split should settle and stay put. It's also worth adding a regression test with alternating inputs that asserts the split changes at most once in N weeks.

The threshold numbers above are placeholders. Set them from your actual weekly spend and egress costs.