I wrote this as five files under `ansible/playbooks/`. The repo has no `ansible/` directory yet, and I can't write files in this session, so you'll need to add them yourself. I haven't run any of it, not even `ansible-lint` or a `--syntax-check`.

The drill takes about 25 minutes:
1. **Checks before touching traffic.** It stops if any of these fail: someone approved the run (for prod), the starting weights look right, the live weights match Git, no other drill is open, and GCP is healthy.
2. **Capacity.** It scales GCP up if needed and refuses to continue if GCP still can't take the load.
3. **Moves traffic in steps.** AWS's share goes from 50% to 25% to 0%. After each step it waits 150 s and checks GCP's error rate (burn rate) and p95 latency.
4. **Holds at 100% GCP for 10 minutes**, checking every 60 s, then confirms that Cloudflare actually sent at least 90% of requests to GCP.
5. **Fails back in two steps**, checking AWS as it takes load again.

**What "stops if things go bad" means here:** if any check, query or apply fails, the `rescue` section puts the original weights back through Terraform. If Terraform also fails, it uses the Cloudflare API script instead. It shrinks GCP back down only after traffic has returned, then marks the drill `rolled_back` and fails the run. A missing or `NaN` metric counts as a failed check, never a pass.

### `ansible/playbooks/drill.yml`
```yaml
# Weekly DR drill: shift 100% of traffic from from_cell to to_cell in SLO-gated steps,
# hold under watch, then fail back. Any failed gate, query or apply restores the
# recorded weights (Terraform, falling back to the Cloudflare API) and fails the run.
# terraform.tfvars.json is never edited, so Git keeps describing the restore target.
- name: DR drill — evacuate, hold, fail back
  hosts: localhost
  connection: local
  gather_facts: false
  vars:
    from_cell: aws
    to_cell: gcp
    cb_env: prod
    approved_by: ""            # required in prod; the workflow fills it from the environment approval
    steps: [50, 25, 0]         # from_cell share after each step
    step_wait_s: 150           # >= 2 x Cloudflare monitor interval + session drain
    hold_minutes: 10
    hold_check_s: 60
    burn_abort: 6.0
    p95_abort_ms: 600
    min_capacity_ratio: 1.2
    min_observed_share: 0.9    # at 100%, to_cell must actually serve >= 90% of edge requests
    break_glass: false
    cell_from: "cb-{{ from_cell }}-{{ cb_env }}"
    cell_to: "cb-{{ to_cell }}-{{ cb_env }}"
    kubeconfig_to: "{{ lookup('ansible.builtin.env', 'KUBECONFIG_' ~ (to_cell | upper)) }}"
    prom: "{{ lookup('ansible.builtin.env', 'CB_PROM_URL') }}"
    cp_api: "{{ lookup('ansible.builtin.env', 'CB_CP_API') }}"
    cp_headers:
      Authorization: "Bearer {{ lookup('ansible.builtin.env', 'CB_CP_TOKEN') }}"
    traffic_stack: "{{ playbook_dir }}/../../infra/live/global/30-traffic"
  tasks:
    # ---------- Preflight: nothing here changes traffic ----------
    - name: Prod traffic only moves with a named human approver
      ansible.builtin.assert:
        that: cb_env != 'prod' or approved_by | length > 0
        fail_msg: "Refusing prod drill without -e approved_by=<github user> (traffic-prod environment approval)."

    - name: Read current weights (the restore target)
      ansible.builtin.slurp:
        src: "{{ traffic_stack }}/terraform.tfvars.json"
      register: tfvars_raw

    - name: Remember original weights
      ansible.builtin.set_fact:
        original_weights: "{{ (tfvars_raw.content | b64decode | from_json).weights }}"

    - name: Starting point is sane
      ansible.builtin.assert:
        that:
          - from_cell != to_cell
          - from_cell in original_weights and to_cell in original_weights
          - original_weights.values() | map('int') | sum == 100
          - original_weights[from_cell] | int > 0
        fail_msg: "Unexpected starting weights {{ original_weights }} — is an evacuation already in effect?"

    - name: Read live weights from the control plane
      ansible.builtin.uri:
        url: "{{ cp_api }}/traffic-changes/latest"
        headers: "{{ cp_headers }}"
        return_content: true
      register: live

    - name: Live weights match Git (no unreconciled break-glass change)
      ansible.builtin.assert:
        that: live.json.weights == original_weights
        fail_msg: "Git says {{ original_weights }}, live is {{ live.json.weights }} — reconcile before drilling."

    - name: No other drill or evacuation in flight
      ansible.builtin.uri:
        url: "{{ cp_api }}/drills?status=open"
        headers: "{{ cp_headers }}"
        return_content: true
      register: open_drills
      failed_when: open_drills.json | length > 0

    - name: Receiving cell is healthy before we start
      ansible.builtin.include_tasks: tasks/slo_gate.yml
      vars:
        phase: preflight
        gate_cell: "{{ cell_to }}"

    - name: Open drill record
      ansible.builtin.uri:
        url: "{{ cp_api }}/drills"
        method: POST
        headers: "{{ cp_headers }}"
        body_format: json
        body:
          from_cell: "{{ cell_from }}"
          to_cell: "{{ cell_to }}"
          mode: drill
          original_weights: "{{ original_weights }}"
          approved_by: "{{ approved_by }}"
        status_code: 201
      register: drill

    - name: Remember drill id
      ansible.builtin.set_fact:
        drill_id: "{{ drill.json.id }}"

    # ---------- The saga: everything below is compensated ----------
    - name: Evacuate, hold, fail back
      block:
        - name: Capacity on receiving cell
          ansible.builtin.uri:
            url: "{{ cp_api }}/capacity/{{ cell_to }}"
            headers: "{{ cp_headers }}"
            return_content: true
          register: cap

        - name: Pre-warm when current replicas cannot absorb the load
          when: cap.json.capacity_ratio_at_current_replicas < min_capacity_ratio | float
          block:
            - name: Snapshot HPA minReplicas so compensation can undo the pre-warm
              kubernetes.core.k8s_info:
                kubeconfig: "{{ kubeconfig_to }}"
                api_version: autoscaling/v2
                kind: HorizontalPodAutoscaler
                namespace: cb-app
              register: hpa_snapshot

            - name: Remember pre-drill minReplicas
              ansible.builtin.set_fact:
                hpa_before: >-
                  {{ dict(hpa_snapshot.resources | map(attribute='metadata.name')
                     | zip(hpa_snapshot.resources | map(attribute='spec.minReplicas', default=1))) }}

            - name: Pre-warm
              ansible.builtin.include_tasks: tasks/prewarm.yml

        - name: Re-check capacity
          ansible.builtin.uri:
            url: "{{ cp_api }}/capacity/{{ cell_to }}"
            headers: "{{ cp_headers }}"
            return_content: true
          register: cap2

        - name: Refuse to evacuate into an undersized cell
          ansible.builtin.fail:
            msg: "Capacity ratio {{ cap2.json.capacity_ratio }} < {{ min_capacity_ratio }} — evacuating would cascade."
          when: cap2.json.capacity_ratio < min_capacity_ratio | float

        - name: Shift traffic off {{ from_cell }} in steps
          ansible.builtin.include_tasks: tasks/move_step.yml
          loop: "{{ steps }}"
          loop_control:
            loop_var: from_share
            index_var: seq
          vars:
            phase: evacuate
            gate_cell: "{{ cell_to }}"
            target_weights: "{{ {from_cell: from_share | int, to_cell: 100 - from_share | int} }}"

        - name: Hold at 100% on {{ to_cell }} under watch
          ansible.builtin.include_tasks: tasks/hold_check.yml
          loop: "{{ range(1, ((hold_minutes | int) * 60) // (hold_check_s | int) + 1) | list }}"
          loop_control:
            index_var: seq
          vars:
            phase: hold
            gate_cell: "{{ cell_to }}"

        - name: Measure the split Cloudflare actually served
          ansible.builtin.uri:
            url: "{{ prom }}/api/v1/query"
            method: POST
            body_format: form-urlencoded
            body:
              query: >-
                sum(rate(cb_cf_pool_requests_total{pool="{{ cell_to }}"}[5m]))
                / sum(rate(cb_cf_pool_requests_total[5m]))
            return_content: true
          register: observed

        - name: All traffic really moved
          ansible.builtin.assert:
            that: _share | float >= min_observed_share | float
            fail_msg: "Configured {{ to_cell }}=100 but observed share is {{ _share }} — sticky sessions or origin weights?"
          vars:
            _share: "{{ (observed.json.data.result | first | default({'value': [0, '0']})).value[1] }}"

        - name: Compute half-way failback share (contract: 0 or >= 10)
          ansible.builtin.set_fact:
            halfway_from: "{{ [original_weights[from_cell] | int // 2, 10] | max }}"

        - name: Fail back in two moves, gating {{ from_cell }} as it takes load again
          ansible.builtin.include_tasks: tasks/move_step.yml
          loop:
            - "{{ {from_cell: halfway_from | int, to_cell: 100 - halfway_from | int} }}"
            - "{{ original_weights }}"
          loop_control:
            loop_var: target_weights
            index_var: seq
          vars:
            phase: failback
            gate_cell: "{{ cell_from }}"

        - name: Undo pre-warm
          ansible.builtin.include_tasks: tasks/hpa_reset.yml
          when: hpa_before is defined

        - name: Close drill and render report
          ansible.builtin.uri:
            url: "{{ cp_api }}/drills/{{ drill_id }}/complete"
            method: POST
            headers: "{{ cp_headers }}"
            status_code: [200, 201]

      rescue:
        - name: Remember why we stopped
          ansible.builtin.set_fact:
            abort_reason: "{{ ansible_failed_task.name | default('?') }}: {{ ansible_failed_result.msg | default('no message') }}"

        - name: Restore original weights
          block:
            - name: Restore via Terraform (or break-glass if already in use)
              ansible.builtin.include_tasks: tasks/apply_weights.yml
              vars:
                weights: "{{ original_weights }}"
                reason: "drill {{ drill_id }} compensation"
          rescue:
            - name: Terraform restore failed — restore through the Cloudflare API
              ansible.builtin.include_tasks: tasks/apply_weights.yml
              vars:
                weights: "{{ original_weights }}"
                reason: "drill {{ drill_id }} compensation (terraform restore failed)"
                force_break_glass: true

        # Shrinking to_cell before traffic has left it would cause the outage the drill rehearses.
        - name: Let traffic drain back before shrinking {{ to_cell }}
          ansible.builtin.pause:
            seconds: "{{ step_wait_s }}"
          when: hpa_before is defined

        - name: Undo pre-warm
          ansible.builtin.include_tasks: tasks/hpa_reset.yml
          when: hpa_before is defined

        - name: Mark drill rolled back
          ansible.builtin.uri:
            url: "{{ cp_api }}/drills/{{ drill_id }}"
            method: PATCH
            headers: "{{ cp_headers }}"
            body_format: json
            body:
              outcome: rolled_back
              reason: "{{ abort_reason }}"

        - name: Fail loudly
          ansible.builtin.fail:
            msg: "Drill {{ drill_id }} aborted and rolled back to {{ original_weights }}. Cause — {{ abort_reason }}"
```

### `ansible/playbooks/tasks/move_step.yml`
```yaml
# One traffic move: apply target_weights, let monitors and sessions drain, then gate gate_cell.
- name: Apply {{ target_weights }}
  ansible.builtin.include_tasks: apply_weights.yml
  vars:
    weights: "{{ target_weights }}"
    reason: "drill {{ drill_id }} {{ phase }} step {{ seq }}"

- name: Wait for health checks and session drain
  ansible.builtin.pause:
    seconds: "{{ step_wait_s }}"

- name: Gate {{ gate_cell }}
  ansible.builtin.include_tasks: slo_gate.yml
```

### `ansible/playbooks/tasks/hold_check.yml`
```yaml
- name: Hold tick
  ansible.builtin.pause:
    seconds: "{{ hold_check_s }}"

- name: Gate {{ gate_cell }}
  ansible.builtin.include_tasks: slo_gate.yml
```

### `ansible/playbooks/tasks/slo_gate.yml`
```yaml
# Gate gate_cell on 5m burn rate (99.5% SLO) and p95. Records the result against the
# drill when one is open and fails on breach. Missing or NaN data is a breach: a cell
# that reports nothing has not proven it is healthy.
- name: Query burn rate and p95 on {{ gate_cell }}
  ansible.builtin.uri:
    url: "{{ prom }}/api/v1/query"
    method: POST
    body_format: form-urlencoded
    body:
      query: "{{ item }}"
    return_content: true
  loop:
    - >-
      ((sum(rate(http_server_requests_seconds_count{cb_cell="{{ gate_cell }}",service="api-gateway",status=~"5.."}[5m])) or vector(0))
      / sum(rate(http_server_requests_seconds_count{cb_cell="{{ gate_cell }}",service="api-gateway"}[5m]))) / 0.005
    - 'cb:latency_p95:5m{cb_cell="{{ gate_cell }}",service="api-gateway"} * 1000'
  loop_control:
    label: "{{ gate_cell }}"
  register: slo_q

- name: Extract values
  ansible.builtin.set_fact:
    burn_now: "{{ _burn[0].value[1] | float if (_burn and _burn[0].value[1] != 'NaN') else none }}"
    p95_now: "{{ _p95[0].value[1] | float if (_p95 and _p95[0].value[1] != 'NaN') else none }}"
  vars:
    _burn: "{{ slo_q.results[0].json.data.result }}"
    _p95: "{{ slo_q.results[1].json.data.result }}"

- name: Decide
  ansible.builtin.set_fact:
    gate_breach: >-
      {{ burn_now is none or p95_now is none
         or burn_now > burn_abort | float or p95_now > p95_abort_ms | float }}

- name: Record gate result
  ansible.builtin.uri:
    url: "{{ cp_api }}/drills/{{ drill_id }}/steps"
    method: POST
    headers: "{{ cp_headers }}"
    body_format: json
    body:
      phase: "{{ phase }}"
      seq: "{{ seq | default(0) }}"
      cell: "{{ gate_cell }}"
      weights: "{{ target_weights | default({}) }}"
      burn_rate: "{{ burn_now }}"
      p95_ms: "{{ p95_now }}"
      decision: "{{ 'abort' if gate_breach else 'advance' }}"
    status_code: 201
  when: drill_id is defined

- name: SLO gate on {{ gate_cell }}
  ansible.builtin.fail:
    msg: "{{ phase }}: {{ gate_cell }} burn={{ burn_now }} (max {{ burn_abort }}) p95={{ p95_now }}ms (max {{ p95_abort_ms }})"
  when: gate_breach
```

### `ansible/playbooks/tasks/apply_weights.yml`
```yaml
# Apply `weights` via Terraform, or the Cloudflare API when break-glass is on, and
# record the change. cf_break_glass.py records its own change with source=break_glass.
- name: Weights obey the traffic contract (sum 100, each 0 or >= 10)
  ansible.builtin.assert:
    that:
      - weights.values() | map('int') | sum == 100
      - weights.values() | map('int') | select('gt', 0) | select('lt', 10) | list | length == 0
    fail_msg: "Refusing weights {{ weights }}"

- name: Apply weights (Terraform)
  community.general.terraform:
    project_path: "{{ traffic_stack }}"
    state: present
    force_init: true
    complex_vars: true
    variables:
      weights: "{{ weights }}"
  when: not (break_glass | bool or force_break_glass | default(false) | bool)

- name: Record traffic change
  ansible.builtin.uri:
    url: "{{ cp_api }}/traffic-changes"
    method: POST
    headers: "{{ cp_headers }}"
    body_format: json
    body:
      weights: "{{ weights }}"
      source: drill
      reason: "{{ reason }}"
      drill_id: "{{ drill_id }}"
    status_code: 201
  when: not (break_glass | bool or force_break_glass | default(false) | bool)

- name: Apply weights (break-glass Cloudflare API)
  ansible.builtin.command:
    argv:
      - python3
      - "{{ playbook_dir }}/../../tools/cf_break_glass.py"
      - --weights
      - "{{ weights.items() | map('join', '=') | join(',') }}"
      - --reason
      - "{{ reason }}"
  changed_when: true
  when: break_glass | bool or force_break_glass | default(false) | bool
```

### `ansible/playbooks/tasks/hpa_reset.yml`
```yaml
- name: Restore pre-drill HPA minReplicas on {{ cell_to }}
  kubernetes.core.k8s:
    kubeconfig: "{{ kubeconfig_to }}"
    state: patched
    api_version: autoscaling/v2
    kind: HorizontalPodAutoscaler
    namespace: cb-app
    name: "{{ item.key }}"
    definition:
      spec:
        minReplicas: "{{ item.value | int }}"
  loop: "{{ hpa_before | dict2items }}"
```

### Changes to `.github/workflows/drill.yml`
```yaml
permissions:
  contents: write
  id-token: write
  actions: read                      # read the environment approval
jobs:
  drill:
    runs-on: ubuntu-24.04
    environment: traffic-prod        # required reviewers: the Sunday run waits for a human
    concurrency: { group: traffic, cancel-in-progress: false }
    timeout-minutes: 75
    steps:
      # ...checkout, setup-terraform, gcp auth, ansible install as before...
      - name: Who approved this run
        id: approver
        env: { GH_TOKEN: "${{ github.token }}" }
        run: echo "login=$(gh api repos/${{ github.repository }}/actions/runs/${{ github.run_id }}/approvals --jq '.[0].user.login')" >> "$GITHUB_OUTPUT"
      - name: Run drill
        working-directory: ansible
        timeout-minutes: 50          # leaves the job time for the restore step below
        env: { CLOUDFLARE_API_TOKEN: ..., CB_CP_API: ..., CB_CP_TOKEN: ..., CB_PROM_URL: ..., KUBECONFIG_GCP: ... }
        run: ansible-playbook playbooks/drill.yml -e from_cell=aws -e to_cell=gcp -e approved_by=${{ steps.approver.outputs.login }}
      - name: Last-resort restore if the playbook was killed mid-drill
        if: failure() || cancelled()
        run: |
          terraform -chdir=infra/live/global/30-traffic init -input=false
          terraform -chdir=infra/live/global/30-traffic apply -auto-approve -input=false
```

### Decisions you should check
- **A person must approve before any prod traffic moves.** The CloudBridge rules say prod traffic never shifts on its own. The existing workflow ran on a schedule against prod cells under `traffic-dev`, which breaks that rule. With `traffic-prod` the Sunday 03:00 IST run now waits for someone to approve it. The playbook also refuses to run without `approved_by`. If you'd rather drills move traffic unattended, they need to run against a non-prod traffic stack.
- **The whole run is protected, not only the traffic moves.** The starter `evacuate.yml` only undid its traffic moves. Here a problem during the 10-minute hold or the failback also restores the original weights.
- **Last-resort restore in the workflow.** If the runner kills Ansible partway, its cleanup can't run. Because the drill never edits `terraform.tfvars.json`, a plain `terraform apply` afterwards restores the original weights. If the playbook already restored them, the extra apply changes nothing.
- **No-data handling in the error check.** The query adds `or vector(0)` to the error count. Without it, a minute with zero 5xx errors returns no data and would wrongly stop the drill.

### Assumptions to confirm
- The control-plane endpoints `/traffic-changes`, `/traffic-changes/latest` and `/drills?status=open` are assumed. The starter code doesn't define them.
- The `pool` label in `cb_cf_pool_requests_total` is assumed to equal the cell name (e.g. `cb-gcp-prod`).
- `tasks/prewarm.yml` is used unchanged from the starter code. It hardcodes `-prod` in its control-plane URL, so it only works when `cb_env=prod`.
- Values passed with `-e` arrive as strings. Pass `steps` as JSON, e.g. `-e '{"steps":[60,30,0]}'`.