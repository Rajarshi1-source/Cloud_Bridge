I couldn't write files in this session, so the full playbook is below. Save the four files with the paths shown. I haven't run it or checked it with a linter.

I didn't know your setup, so I assumed traffic is split with **Route 53 weighted DNS records**, with your AWS load balancer on one record and the GCP load balancer's IP on the other. If you switch traffic another way (Cloudflare, a global load balancer, Cloud DNS), tell me and I'll rewrite it for that.

**How it works:**
1. **Pre-flight checks:**
   - It reads the current weights and refuses to start unless AWS is serving traffic. This catches a previous drill that never finished.
   - It runs the health checks against GCP before any traffic moves.
   - It asks you to confirm before starting.
2. **Moving traffic in steps:** GCP gets 10% → 25% → 50% → 100% of traffic. At each step it raises GCP before lowering AWS, so both weights are never 0 at once. It then waits out the DNS cache time plus a settling period, then runs the health checks.
3. **Health checks** (any failure stops the drill):
   - All GCP backends report healthy.
   - Test requests sent straight to the GCP load balancer mostly succeed and respond quickly enough.
   - Optional: the GCP error rate from Prometheus is under your limit.
   - Optional: database replication lag into GCP is under your limit.
4. **Automatic rollback:** any failure at any step resets both DNS weights to what they were at the start, then stops the run with a message saying which check failed.

### `dr_failover.yml`
```yaml
---
# Weekly DR drill: shift all traffic for dr_record_name from AWS to GCP via
# Route 53 weighted records. Each stage waits TTL + soak, then runs a health
# gate. Any failure restores the original weights and fails the play.
#
#   ansible-playbook dr_failover.yml -e @vars/dr.yml
#   ansible-playbook dr_failover.yml -e @vars/dr.yml -e dr_skip_confirm=true   # scheduled
#   ansible-playbook dr_failover.yml -e @vars/dr.yml --check                  # no DNS changes

- name: DR drill - fail traffic over from AWS to GCP
  hosts: localhost
  connection: local
  gather_facts: false

  vars:
    dr_skip_confirm: false

  tasks:
    # ---------------------------------------------------------------- preflight
    - name: Validate stage configuration
      ansible.builtin.assert:
        that:
          - dr_steps | length > 0
          - dr_steps[-1] == 100
          - dr_steps | select('gt', 100) | list | length == 0
          - dr_steps == (dr_steps | sort)
        fail_msg: "dr_steps must be ascending, <= 100, and end at 100"

    - name: Read current Route 53 weighted records
      amazon.aws.route53_info:
        query: record_sets
        hosted_zone_id: "{{ dr_hosted_zone_id }}"
        start_record_name: "{{ dr_record_name }}"
        type: "{{ dr_record_type }}"
        max_items: "10"
      register: r53_current

    - name: Capture original weights for rollback
      vars:
        _sets: >-
          {{ r53_current.resource_record_sets
             | selectattr('name', 'equalto', dr_record_name ~ '.')
             | selectattr('set_identifier', 'defined') | list }}
      ansible.builtin.set_fact:
        dr_original_aws_weight: "{{ _sets | selectattr('set_identifier', 'equalto', dr_aws_record.identifier) | map(attribute='weight') | first | default(-1) | int }}"
        dr_original_gcp_weight: "{{ _sets | selectattr('set_identifier', 'equalto', dr_gcp_record.identifier) | map(attribute='weight') | first | default(-1) | int }}"

    - name: Refuse to start unless in normal (AWS-primary) state
      ansible.builtin.assert:
        that:
          - dr_original_aws_weight | int > 0
          - dr_original_gcp_weight | int >= 0
        fail_msg: >-
          Unexpected starting state (aws={{ dr_original_aws_weight }},
          gcp={{ dr_original_gcp_weight }}). Both weighted records must exist and
          AWS must be serving traffic. Is a previous drill still in progress?

    - name: Pre-flight health gate on GCP
      ansible.builtin.include_tasks: tasks/health_gate.yml
      vars:
        gate_label: preflight
        gate_check_error_rate: false   # GCP has no real traffic yet

    - name: Confirm drill start
      ansible.builtin.pause:
        prompt: |
          Shifting {{ dr_record_name }} to GCP in stages {{ dr_steps }}.
          Current weights: AWS={{ dr_original_aws_weight }} GCP={{ dr_original_gcp_weight }}.
          ENTER to continue, Ctrl+C then A to abort
      when: not (dr_skip_confirm | bool)

    # ---------------------------------------------------------------- shift
    - name: Staged traffic shift with automatic rollback
      block:
        - name: Shift traffic stage by stage
          ansible.builtin.include_tasks: tasks/shift_step.yml
          loop: "{{ dr_steps }}"
          loop_control:
            loop_var: gcp_weight
            label: "GCP {{ gcp_weight }}%"

        - name: Drill complete
          ansible.builtin.debug:
            msg: >-
              All traffic for {{ dr_record_name }} is on GCP. Original weights:
              AWS={{ dr_original_aws_weight }} GCP={{ dr_original_gcp_weight }}.

      rescue:
        - name: ROLLBACK - restore AWS weight
          amazon.aws.route53:
            state: present
            zone: "{{ dr_zone }}"
            record: "{{ dr_record_name }}"
            type: "{{ dr_record_type }}"
            ttl: "{{ omit if dr_aws_record.alias | default(false) else dr_ttl }}"
            identifier: "{{ dr_aws_record.identifier }}"
            weight: "{{ dr_original_aws_weight | int }}"
            value: "{{ dr_aws_record.value }}"
            alias: "{{ dr_aws_record.alias | default(false) }}"
            alias_hosted_zone_id: "{{ dr_aws_record.alias_hosted_zone_id | default(omit) }}"
            alias_evaluate_target_health: "{{ dr_aws_record.alias_evaluate_target_health | default(omit) }}"
            overwrite: true
            wait: true

        - name: ROLLBACK - restore GCP weight
          amazon.aws.route53:
            state: present
            zone: "{{ dr_zone }}"
            record: "{{ dr_record_name }}"
            type: "{{ dr_record_type }}"
            ttl: "{{ dr_ttl }}"
            identifier: "{{ dr_gcp_record.identifier }}"
            weight: "{{ dr_original_gcp_weight | int }}"
            value: "{{ dr_gcp_record.value }}"
            overwrite: true
            wait: true

        - name: Abort drill
          ansible.builtin.fail:
            msg: >-
              DR drill ABORTED at "{{ ansible_failed_task.name | default('unknown') }}":
              {{ ansible_failed_result.msg | default('see output above') }}.
              Weights restored to AWS={{ dr_original_aws_weight }} GCP={{ dr_original_gcp_weight }};
              clients may take up to {{ dr_ttl }}s to follow.
```

### `tasks/shift_step.yml`
```yaml
---
# One stage. Loop var: gcp_weight (0-100). Raise GCP before lowering AWS so
# both weights are never 0 at the same time.

- name: "Set GCP weight to {{ gcp_weight }}"
  amazon.aws.route53:
    state: present
    zone: "{{ dr_zone }}"
    record: "{{ dr_record_name }}"
    type: "{{ dr_record_type }}"
    ttl: "{{ dr_ttl }}"
    identifier: "{{ dr_gcp_record.identifier }}"
    weight: "{{ gcp_weight | int }}"
    value: "{{ dr_gcp_record.value }}"
    overwrite: true
    wait: true

- name: "Set AWS weight to {{ 100 - gcp_weight | int }}"
  amazon.aws.route53:
    state: present
    zone: "{{ dr_zone }}"
    record: "{{ dr_record_name }}"
    type: "{{ dr_record_type }}"
    ttl: "{{ omit if dr_aws_record.alias | default(false) else dr_ttl }}"
    identifier: "{{ dr_aws_record.identifier }}"
    weight: "{{ 100 - gcp_weight | int }}"
    value: "{{ dr_aws_record.value }}"
    alias: "{{ dr_aws_record.alias | default(false) }}"
    alias_hosted_zone_id: "{{ dr_aws_record.alias_hosted_zone_id | default(omit) }}"
    alias_evaluate_target_health: "{{ dr_aws_record.alias_evaluate_target_health | default(omit) }}"
    overwrite: true
    wait: true

- name: "Soak at GCP {{ gcp_weight }}% ({{ dr_ttl }}s TTL + {{ dr_soak_seconds }}s)"
  ansible.builtin.wait_for:
    timeout: "{{ dr_ttl | int + dr_soak_seconds | int }}"
  when: not ansible_check_mode

- name: "Health gate at GCP {{ gcp_weight }}%"
  ansible.builtin.include_tasks: health_gate.yml
  vars:
    gate_label: "GCP {{ gcp_weight }}%"
```

### `tasks/health_gate.yml`
```yaml
---
# Any failed assert fails the stage -> rollback.

# 1. GCP backend health
- name: "[{{ gate_label }}] Get GCP backend service health"
  ansible.builtin.command:
    argv: [gcloud, compute, backend-services, get-health, "{{ item }}",
           --global, "--project={{ dr_gcp_project }}", --format=json]
  loop: "{{ dr_gcp_backend_services }}"
  register: gcp_backend_health
  changed_when: false
  check_mode: false

- name: "[{{ gate_label }}] Assert GCP backends healthy"
  vars:
    _states: >-
      {{ gcp_backend_health.results
         | map(attribute='stdout') | map('from_json') | flatten
         | map(attribute='status') | map(attribute='healthStatus', default=[]) | flatten
         | map(attribute='healthState') | list }}
    _healthy: "{{ _states | select('equalto', 'HEALTHY') | list | length }}"
  ansible.builtin.assert:
    that:
      - _states | length > 0
      - (_healthy | int) / (_states | length) >= dr_min_healthy_ratio
    fail_msg: "GCP backends unhealthy: {{ _healthy }}/{{ _states | length }} HEALTHY"
    quiet: true

# 2. Synthetic probes straight at the GCP LB
- name: "[{{ gate_label }}] Probe GCP endpoint"
  ansible.builtin.uri:
    url: "{{ dr_probe_url }}"
    headers:
      Host: "{{ dr_record_name }}"
    validate_certs: false   # hitting LB by IP
    timeout: 10
  loop: "{{ range(dr_probe_count) | list }}"
  loop_control:
    label: "probe {{ item + 1 }}/{{ dr_probe_count }}"
  register: gcp_probes
  failed_when: false
  check_mode: false

- name: "[{{ gate_label }}] Assert probe success rate and latency"
  vars:
    _ok: "{{ gcp_probes.results | selectattr('status', 'defined') | selectattr('status', 'equalto', 200) | list }}"
    _max_ms: "{{ ((_ok | map(attribute='elapsed') | max | default(999)) * 1000) | int }}"
  ansible.builtin.assert:
    that:
      - (_ok | length) / dr_probe_count >= dr_min_probe_success_ratio
      - _max_ms | int <= dr_max_probe_latency_ms
    fail_msg: "Probes: {{ _ok | length }}/{{ dr_probe_count }} OK, slowest {{ _max_ms }}ms"
    quiet: true

# 3. Real-traffic error rate (optional)
- name: "[{{ gate_label }}] Query GCP 5xx ratio"
  ansible.builtin.uri:
    url: "{{ dr_prometheus_url }}/api/v1/query?query={{ dr_error_rate_query | urlencode }}"
    return_content: true
  register: prom_error_rate
  check_mode: false
  when:
    - gate_check_error_rate | default(true)
    - dr_prometheus_url | default('') | length > 0

- name: "[{{ gate_label }}] Assert error rate under threshold"
  vars:
    _r: "{{ prom_error_rate.json.data.result }}"
    _rate: "{{ (_r[0].value[1] | float) if _r | length > 0 else 0.0 }}"
  ansible.builtin.assert:
    that: _rate | float <= dr_max_error_rate
    fail_msg: "GCP 5xx ratio {{ (_rate | float * 100) | round(2) }}% > {{ dr_max_error_rate * 100 }}%"
    quiet: true
  when: prom_error_rate is not skipped

# 4. Replication lag (optional)
- name: "[{{ gate_label }}] Check DB replication lag"
  ansible.builtin.command: "{{ dr_replication_lag_cmd }}"
  register: repl_lag
  changed_when: false
  check_mode: false
  when: dr_replication_lag_cmd | default('') | length > 0

- name: "[{{ gate_label }}] Assert replication lag acceptable"
  ansible.builtin.assert:
    that: repl_lag.stdout | trim | float <= dr_max_replication_lag_seconds
    fail_msg: "Replication lag {{ repl_lag.stdout | trim }}s > {{ dr_max_replication_lag_seconds }}s"
    quiet: true
  when: repl_lag is not skipped
```

### `vars/dr.yml`
```yaml
---
dr_zone: example.com
dr_hosted_zone_id: Z0123456789ABCDEFGHIJ
dr_record_name: app.example.com
dr_record_type: A
dr_ttl: 60

dr_aws_record:
  identifier: aws-primary
  alias: true
  value: my-alb-123456.us-east-1.elb.amazonaws.com
  alias_hosted_zone_id: Z35SXDOTRQ7X7K     # ALB hosted zone for your region
  alias_evaluate_target_health: true

dr_gcp_record:
  identifier: gcp-dr
  value: 203.0.113.10                      # GCP external LB IP

dr_steps: [10, 25, 50, 100]
dr_soak_seconds: 300

dr_gcp_project: my-dr-project
dr_gcp_backend_services: [app-backend]
dr_min_healthy_ratio: 1.0

dr_probe_url: "https://203.0.113.10/healthz"
dr_probe_count: 20
dr_min_probe_success_ratio: 0.95
dr_max_probe_latency_ms: 1500

dr_prometheus_url: ""                      # empty = skip error-rate gate
dr_error_rate_query: >-
  sum(rate(http_requests_total{cloud="gcp",code=~"5.."}[5m]))
  / sum(rate(http_requests_total{cloud="gcp"}[5m]))
dr_max_error_rate: 0.01

dr_replication_lag_cmd: ""                 # must print seconds; empty = skip
dr_max_replication_lag_seconds: 30
```

You also need the AWS Ansible add-on: `ansible-galaxy collection install amazon.aws`. The machine running it needs AWS credentials and a logged-in `gcloud`.

**Before relying on it:**
- **Test it first:** run it with `--check` to see what it would change without changing DNS. Then do a real run against a test DNS record before using your production hostname.
- **Field names:** the step that reads the current weights assumes `route53_info` returns snake_case field names (`set_identifier`, `weight`), which recent `amazon.aws` versions do. Check this against your installed version.
- **Rollback limits:** rollback only resets DNS. If the AWS DNS service itself is failing, the rollback fails too, and you have to restore the weights by hand. The original weights are printed in the output.
- **Putting traffic back on AWS:** the playbook stops with everything on GCP. I can add a failback playbook that reverses the steps.