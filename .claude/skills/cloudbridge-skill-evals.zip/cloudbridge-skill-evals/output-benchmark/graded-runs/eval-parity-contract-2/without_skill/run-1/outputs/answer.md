I couldn't add the exception because `/tmp/cbout-7hagr3gt` is empty. It isn't a git repo, and I found no parity job, config or CI files there.

To make the change, I need one of these:
- **The repo:** a path or clone URL for the repo that holds the parity job, or
- **The files:** the job definition (a CI workflow, CronJob or script) and the allowlist or config file where exceptions go, pasted here.

Unless your existing exception format says otherwise, this is the exception I'd add:
- **What it covers:** only `1.36.4` on GKE against `1.36.2` on EKS. Different minor versions would still fail.
- **Expiry:** it stops applying on a set date, around 30 days out. That way it can't quietly hide future drift.
- **Note:** a short line saying the GKE cluster was auto-upgraded and EKS is behind.

If the drift is expected to keep happening, I could instead change the check so patch-level differences are allowed but logged. Let me know which you want once I can see the code.

The real fix is upgrading EKS to 1.36.4, or pinning GKE's release channel or adding a maintenance exclusion so it stops upgrading on its own.