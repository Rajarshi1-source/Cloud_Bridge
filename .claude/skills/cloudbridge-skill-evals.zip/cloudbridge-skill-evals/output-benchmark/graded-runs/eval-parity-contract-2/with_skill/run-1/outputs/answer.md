I couldn't add the exception: this working directory has no `parity/` folder, only the `.claude/skills` definitions. I didn't create a new `parity/exceptions.yaml` because, in your real repo, a new file would replace the existing exceptions instead of adding to them. Add this entry to your existing `parity/exceptions.yaml`:

```yaml
- check: k8s.minor
  scope: patch-only            # only applies while both clusters are on 1.36
  reason: "GKE auto-upgraded to 1.36.4; EKS still on 1.36.2. Patch-level difference only, minors are equal."
  owner: <your-handle>         # required; the checker won't accept the entry without it
  expires: 2026-11-08          # 30 days; gives time for EKS to reach 1.36.4
```

- **Why `patch-only`:** the checker checks the versions itself instead of taking the exception on trust. If either cluster moves to 1.37, the minor versions differ, the exception no longer applies and the nightly job fails again. A patch difference can't hide a minor one.
- **Why it expires:** the parity checker accepts an exception without an expiry only when its scope limits it in time, and `patch-only` doesn't. When the date passes, the check fails again.
- **Owner:** I left a placeholder because I don't know who should own this. Fill it in with whoever is tracking the EKS upgrade.

If EKS is still on 1.36.2 when this expires, renew it deliberately rather than pushing the date out. To make this less frequent, you could pin GKE to a maintenance window or move it to a slower release channel. GKE patch auto-upgrades will otherwise keep opening this gap.

Once it's merged, run `parity check --env prod` to confirm the score is back to 1.0 before tonight's job. Do the same for `--env budget` if that env failed too.