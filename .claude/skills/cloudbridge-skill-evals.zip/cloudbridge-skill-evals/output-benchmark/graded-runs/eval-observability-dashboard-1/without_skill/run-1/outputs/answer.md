**Short answer: no, don't federate.** Federation is built to pull a small set of *pre-aggregated* series up to a higher-level Prometheus. Using it to copy everything from one cloud into another causes problems: big `/federate` scrapes that time out, cross-cloud egress costs, one Prometheus that becomes a single point of failure, and staleness gaps whenever the link between the clouds drops.

The working directory is empty, so I don't know your setup yet. The usual choice comes down to one question.

### Do you need to query across clouds (for example, "total error rate across AWS and GCP")?

**No → connect Grafana to both Prometheus servers directly (simplest, and usually enough)**

Each Prometheus keeps scraping and alerting locally. Grafana gets two data sources, and a dashboard variable lets you switch between them. Grafana's "Mixed" data source can also put both clouds on one panel.

```yaml
# grafana/provisioning/datasources/prometheus.yaml
apiVersion: 1
datasources:
  - name: prom-aws
    type: prometheus
    access: proxy
    url: https://prometheus.aws.internal:9090
    jsonData: { timeInterval: 30s }
  - name: prom-gcp
    type: prometheus
    access: proxy
    url: https://prometheus.gcp.internal:9090
    jsonData: { timeInterval: 30s }
```

Then add a dashboard variable `ds` of type *Data source* (Prometheus), and set panels to use `${ds}`.

**Yes → have both send their data to one central store**

Either Prometheus pushes its data (`remote_write`) to Mimir, VictoriaMetrics or Thanos Receive, or you use Thanos sidecars with a Thanos Querier (the data stays where it is and queries fan out). Grafana then talks to a single data source. You also get long retention and deduplication across replicas.

```yaml
# prometheus.yml (each cloud)
global:
  external_labels:
    cloud: aws          # or gcp
    cluster: prod-use1
remote_write:
  - url: https://mimir.example.internal/api/v1/push
    queue_config: { max_samples_per_send: 5000 }
```

### Do these either way
- **Set `external_labels`** (`cloud`, `region`, `cluster`) on each Prometheus now. This costs nothing and makes a later move to a central store painless.
- **Keep alerting local.** Each cloud should run its own Prometheus rules and Alertmanager, so a broken link between clouds can't hide alerts.
- **Have each cloud watch the other.** For example, each one scrapes or probes the other's Prometheus, and you alert on `up == 0` or `absent()`. Otherwise "no data" looks the same as "healthy."
- **Lock down the connection** to Grafana or the central store with mTLS or a private link, not public endpoints.

**My recommendation:** start with two data sources plus `external_labels`. Move to Mimir or Thanos only when you actually need cross-cloud queries, longer retention or HA. Neither option needs federation.

If you tell me which clouds you're on and how Prometheus runs (kube-prometheus-stack, a VM, or managed), I can write the actual config files.