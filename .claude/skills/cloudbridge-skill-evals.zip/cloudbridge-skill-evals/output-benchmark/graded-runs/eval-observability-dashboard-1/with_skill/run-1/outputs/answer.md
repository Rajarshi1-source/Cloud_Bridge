**Don't federate them.** Have each cell push its metrics out to one central Prometheus, and point the single Grafana at that.

## Why not federation

Federation means the central Prometheus has to reach into each cell and scrape its `/federate` endpoint. That causes three problems:

- **Both cells need an open inbound port.** You'd expose an endpoint on AWS and on GCP to the internet, or build cross-cloud networking just to carry metrics. Pushing needs nothing open on either cell.
- **Gaps you can't fill.** If the link to AWS drops for 10 minutes during a scrape, that data is lost for good. With pushing, the cell keeps unsent samples in a local log (the WAL) and sends them when the link is back.
- **Dashboards wait on the slowest cloud.** Each federation scrape is a big pull across the internet, so one slow cell slows every dashboard.

The layout instead:

```
AWS cell: Prometheus (agent) ─┐  remote_write over HTTPS, outbound only,
                              ├─ Cloudflare Access service token ─▶ control plane (GCP VM):
GCP cell: Prometheus (agent) ─┘                                     Prometheus 3.14 receiver → rules → Alertmanager
                                                                    Grafana 13.2 (one instance)
```

Each cell attaches its own labels (`cb_cell`, `cb_cloud`, `cb_env`, `cb_profile`) before sending. Grafana then compares the clouds with ordinary `by (cb_cell)` queries, and you don't need a separate datasource for each cloud.

## The pieces

**1. In each cell: an agent that only sends** (`gitops/charts/platform-addons/files/prometheus-agent.yml`)
```yaml
global:
  scrape_interval: 15s
  external_labels: { cb_cell: ${CB_CELL}, cb_cloud: ${CB_CLOUD}, cb_env: ${CB_ENV}, cb_profile: ${CB_PROFILE} }
# scrape_configs: apps (pod annotations in cb-app), kube-state-metrics, opencost, argocd
remote_write:
  - url: https://metrics.cp.<domain>/api/v1/write
    headers:
      CF-Access-Client-Id: ${CF_ACCESS_CLIENT_ID}
      CF-Access-Client-Secret: ${CF_ACCESS_CLIENT_SECRET}
    write_relabel_configs:
      - { source_labels: [__name__], regex: "go_.*|process_.*|jvm_gc_pause_seconds_bucket", action: drop }
```
Prometheus doesn't fill in `${VAR}` values itself, so the Helm chart has to render them (with an `envsubst` initContainer or Helm templating). The Access token values come from the secret that External Secrets Operator (ESO) manages.

**2. Central receiver** (`observability/prometheus/prometheus.yml`). Start it with `--web.enable-remote-write-receiver`. It also scrapes the blackbox probe of `https://app.<domain>/healthz/cell`, which goes through Cloudflare like a real user, and the Cloudflare exporter for the observed traffic split.

**3. One Grafana** (`observability/grafana/provisioning/datasources/ds.yml`). It has two datasources:
- **Prometheus**: `http://prometheus:9090`, for all metrics from both clouds.
- **ControlPlane Postgres**, using the read-only `cp_reader` user. This holds the configured weights, cost ledger, parity results and drills, so none of that gets copied into Prometheus.

The five dashboards are overview (configured vs observed split), cost per request, parity, drills and delivery. Every panel shows how old its data is. Grafana is published through Cloudflare Access, with no open ports.

## Two bugs to fix in the starter rules

The starter files in this repo's monitoring skill (`references/starter-code.md`) have two problems worth fixing as you copy them:

1. **The alerts drop the labels the automation routes on.** The rules use `sum by (cb_cell, ...)`, which strips `cb_cloud` and `cb_env`. The Event-Driven Ansible rulebook routes `CellSLOBurnFast` on `cb_env` (prod → proposal only), so those labels must survive. Use `by (cb_cell, cb_cloud, cb_env, service)` in every recording rule and alert.
2. **`RemoteWriteSilent` misses a single silent cell.** `absent_over_time(up{job="apps"}[10m])` only fires when *both* cells stop sending. Check each cell instead:
   ```yaml
   - alert: RemoteWriteSilent
     expr: |
       group by (cb_cell, cb_cloud, cb_env) (up{job="apps"} offset 30m)
         unless on (cb_cell) group by (cb_cell) (up{job="apps"})
     for: 10m
     labels: { severity: ticket }
   ```

## One decision you need to make

Agent mode can't answer queries, but the Argo Rollouts canary analysis needs a Prometheus to query. **My recommendation:** run Prometheus in each cell as a normal server with 6-hour retention that also does `remote_write`. That one process replaces the agent. Canary checks then still work when the control plane is down, which matters because the control plane is meant to stay off the request and delivery paths. The cost is a bit more memory on the 2 GiB budget VMs. Whichever you choose, write it down.

**Scaling later:** if one receiver gets past about 1M active series or you need more than 30 days of retention, swap it for Mimir or Thanos Receive. They use the same `remote_write` protocol, so the cells don't change.

---

I haven't created any of these files. The working directory has no `observability/` or `gitops/` folder yet (only the skill definitions), and I can't write files in this session. The full configs are in `.claude/skills/cloudbridge-observability-dashboard/references/starter-code.md`. If you can give me write access, I can lay them out with the two fixes above.