I couldn't write or test these files. Your working directory is empty and I have no file-writing or shell tools in this session, so the code is below to paste in. I matched it to the CloudBridge module fragments from an earlier session's scratchpad. Nothing has been through `terraform validate` or `terraform test`.

There was already a `gcp-memorystore` draft in those fragments, marked "verify argument names". That draft wouldn't have worked:

1. **No PSC policy.** Memorystore for Valkey only allows private connections through Private Service Connect (PSC), Google's private-endpoint feature. It can't create those endpoints until a "service connection policy" for `gcp-memorystore` exists in that network and region. Without one, the first apply fails.
2. **Picked the endpoint by position.** `endpoints[0].connections[0]` doesn't reliably point at the primary node. The new code looks for `CONNECTION_TYPE_PRIMARY` instead.
3. **Apps can't verify TLS.** Memorystore signs its TLS certificate with Google's own certificate authority (CA), which clients don't trust by default. ElastiCache's certificate is trusted by default, so AWS never needed this. The `cache` output now includes the CA certificate.

### `infra/modules/cache/gcp-memorystore/main.tf` (new, replaces the draft)

```hcl
# infra/modules/cache/gcp-memorystore/main.tf
variable "name" {
  type = string
}

variable "project_id" {
  type = string
}

variable "region" {
  type = string
}

variable "network" {
  type = string
}

variable "subnetwork" {
  type        = string
  description = "Subnet the PSC endpoint IPs are allocated from."
}

variable "engine_version" {
  type = string
}

variable "labels" {
  type = map(string)
}

# Memorystore for Valkey is reachable only through PSC endpoints, and it can't auto-create them
# without a gcp-memorystore service connection policy in this network + region.
resource "google_network_connectivity_service_connection_policy" "memorystore" {
  project       = var.project_id
  name          = "${var.name}-memorystore"
  location      = var.region
  service_class = "gcp-memorystore"
  network       = var.network

  psc_config {
    subnetworks = [var.subnetwork]
  }
}

resource "google_memorystore_instance" "this" {
  project                     = var.project_id
  instance_id                 = var.name
  location                    = var.region
  engine_version              = var.engine_version
  mode                        = "CLUSTER_DISABLED"
  shard_count                 = 1
  replica_count               = 0
  node_type                   = "SHARED_CORE_NANO" # closest match to cache.t4g.micro
  authorization_mode          = "AUTH_DISABLED"    # parity with ElastiCache (no AUTH token)
  transit_encryption_mode     = "SERVER_AUTHENTICATION"
  deletion_protection_enabled = true
  labels                      = var.labels

  desired_auto_created_endpoints {
    network    = var.network
    project_id = var.project_id
  }

  depends_on = [google_network_connectivity_service_connection_policy.memorystore]

  lifecycle {
    prevent_destroy = true
  }
}

locals {
  # Select the primary endpoint by type; list order isn't guaranteed.
  primary = one(flatten([
    for e in google_memorystore_instance.this.endpoints : [
      for c in e.connections : [
        for p in c.psc_auto_connection : p if p.connection_type == "CONNECTION_TYPE_PRIMARY"
      ]
    ]
  ]))
}

output "cache" {
  value = {
    host           = local.primary.ip_address
    port           = local.primary.port
    tls            = true
    ca_certificate = join("\n", google_memorystore_instance.this.managed_server_ca[0].ca_certs[0].certificates)
  }
}
```

### Facade: `infra/modules/cell/main.tf`

Replace the `cache_gcp` block. If your copy doesn't have it yet, add the block and the `cache` local as well:

```hcl
module "cache_gcp" {
  source         = "../cache/gcp-memorystore"
  count          = var.cloud == "gcp" && local.managed && var.managed_cache ? 1 : 0
  name           = local.name
  project_id     = var.gcp_project_id
  region         = var.region
  network        = local.net.network_id
  subnetwork     = local.net.private_subnet_ids[0]
  engine_version = "VALKEY_9_0"
  labels         = local.labels
}

locals {
  database = one(concat(module.db_aws[*].database, module.db_gcp[*].database))
  cache    = one(concat(module.cache_aws[*].cache, module.cache_gcp[*].cache))
}
```

`outputs.tf` doesn't change, because `output "cache"` already passes through `local.cache`.

### Keep the contract identical: `infra/modules/cache/aws-elasticache/main.tf`

Add one key to the AWS output so both clouds return the same fields:

```hcl
output "cache" {
  value = {
    host           = aws_elasticache_replication_group.this.primary_endpoint_address
    port           = 6379
    tls            = true
    ca_certificate = null # Amazon-issued cert; system trust store verifies it
  }
}
```

### Tests: `infra/modules/cell/tests/contract.tftest.hcl`

The mock needs values for every attribute the module filters or indexes:

```hcl
  mock_resource "google_memorystore_instance" {
    defaults = {
      endpoints = [{ connections = [{ psc_auto_connection = [{ ip_address = "10.0.0.5", port = 6379, connection_type = "CONNECTION_TYPE_PRIMARY" }] }] }]
      managed_server_ca = [{ ca_certs = [{ certificates = ["-----BEGIN CERTIFICATE-----\nMIIB\n-----END CERTIFICATE-----"] }] }]
    }
  }
```

Add this assertion to both `aws_managed_contract` and `gcp_managed_contract`:

```hcl
  assert {
    condition     = alltrue([for k in ["host", "port", "tls", "ca_certificate"] : contains(keys(output.cache), k)])
    error_message = "Managed cache contract keys missing."
  }
```

Add this one to `gcp_managed_contract` only:

```hcl
  assert {
    condition     = output.cache.host == "10.0.0.5" && output.cache.tls && output.cache.ca_certificate != null
    error_message = "GCP cache must expose the primary PSC endpoint and its CA."
  }
```

### Check before applying
- **Things I couldn't confirm against the google 7.x provider:** that `VALKEY_9_0` is an engine version Memorystore offers in `asia-south1`, and the exact names of `managed_server_ca` and `psc_auto_connection.connection_type`. Running `terraform validate` plus `terraform test` will catch any naming mistakes.
- **APIs to enable:** none of the GCP modules turn on APIs, so make sure the `memorystore`, `networkconnectivity` and `serviceconsumermanagement` APIs are enabled in the gcp-prod project.
- **Apps must use the CA:** whatever reads the `cache` output into the cluster has to give `ca_certificate` to the apps as their TLS trust root. Otherwise connections fail on gcp-prod.
- **Not a full match with AWS:**
  - **Access:** on AWS, port 6379 is open only to the node security group. On GCP the endpoint is reachable from anywhere in the cell's network. If you want it tighter, switch to `authorization_mode = "IAM_AUTH"`.
  - **Zone:** the instance may end up in a different zone from the GKE cluster, which runs in one zone (`-a`). That adds a little latency and cross-zone traffic cost. A `zone_distribution_config` block can pin it to the same zone.