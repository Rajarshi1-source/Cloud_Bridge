I couldn't create files in this session because the Write tool is disabled. This workspace also has no `infra/` tree, only the `.claude/skills/` folder. So the complete files are below for you to paste in. I haven't run `terraform validate` or the contract test on any of it.

## What the facade needs

1. **A subnetwork for the cache.** Memorystore for Valkey is reached through a Private Service Connect address in your own subnet. The cache module now creates a "service connection policy" (`google_network_connectivity_service_connection_policy`), which needs a subnet, so the facade passes one in.
2. **A CA certificate in the cache output.** ElastiCache certificates are signed by Amazon's public CA, so clients already trust them. Memorystore signs with a CA unique to each instance, so a client using the current `{host, port, tls}` output would fail the TLS handshake on GCP only. I added `ca_certificate` to the `cache` output for both clouds; AWS returns `null`.

## `infra/modules/cache/gcp-memorystore/variables.tf`

```hcl
variable "name" {
  type = string
}

variable "env" {
  type = string
}

variable "project_id" {
  type = string
}

variable "region" {
  type = string
}

variable "network" {
  type        = string
  description = "VPC id: projects/<p>/global/networks/<n>."
}

variable "subnetwork" {
  type        = string
  description = "Subnet the PSC endpoint IP is allocated from: projects/<p>/regions/<r>/subnetworks/<s>."
}

variable "engine_version" {
  type = string
}

variable "labels" {
  type = map(string)
}
```

## `infra/modules/cache/gcp-memorystore/main.tf`

```hcl
# Memorystore for Valkey (verify argument names against the google ~> 7.0 version in the lock file).
# It is reached via Private Service Connect, not VPC peering. The service connection policy lets
# Memorystore create the PSC endpoint in this cell's subnet. The policy is unique per
# network x region x service class; every cell has its own VPC, so the cell owns it.
resource "google_network_connectivity_service_connection_policy" "memorystore" {
  project       = var.project_id
  name          = "${var.name}-memorystore"
  location      = var.region
  service_class = "gcp-memorystore"
  network       = var.network
  description   = "PSC for CloudBridge cell cache"
  labels        = var.labels

  psc_config {
    subnetworks = [var.subnetwork]
  }
}

resource "google_memorystore_instance" "this" {
  project        = var.project_id
  instance_id    = var.name
  location       = var.region
  engine_version = var.engine_version
  mode           = "CLUSTER_DISABLED"
  shard_count    = 1
  # Matches aws-elasticache (num_cache_clusters = 1). Prod HA must change on both clouds in one PR.
  replica_count               = 0
  node_type                   = "SHARED_CORE_NANO"
  transit_encryption_mode     = "SERVER_AUTHENTICATION"
  authorization_mode          = "AUTH_DISABLED" # matches ElastiCache: TLS, no AUTH token
  deletion_protection_enabled = var.env == "prod"
  labels                      = var.labels

  desired_auto_created_endpoints {
    network    = var.network
    project_id = var.project_id
  }

  depends_on = [google_network_connectivity_service_connection_policy.memorystore]

  lifecycle {
    prevent_destroy = true
  }
}

# Memorystore signs its TLS cert with a per-instance CA, unlike ElastiCache (public Amazon CA).
data "google_memorystore_instance_certificate_authority" "this" {
  project  = var.project_id
  location = var.region
  instance = google_memorystore_instance.this.instance_id
}

locals {
  # Pick the endpoint by type, not list order: a READER connection appears once replicas exist.
  primary = one([
    for c in flatten([for e in google_memorystore_instance.this.endpoints : e.connections]) :
    c.psc_auto_connection[0] if c.psc_auto_connection[0].connection_type == "CONNECTION_TYPE_PRIMARY"
  ])

  ca_pem = join("\n", flatten([
    for ca in data.google_memorystore_instance_certificate_authority.this.managed_server_ca :
    [for chain in ca.ca_certs : chain.certificates]
  ]))
}
```

## `infra/modules/cache/gcp-memorystore/outputs.tf`

```hcl
output "cache" {
  value = {
    host           = local.primary.ip_address
    port           = local.primary.port
    tls            = true
    ca_certificate = local.ca_pem # PEM; null on AWS, where the system trust store already covers it
  }
}
```

## Facade: `infra/modules/cell/main.tf`

Replace the `cache_gcp` block. The `locals { cache = one(concat(...)) }` selector stays as it is.

```hcl
module "cache_gcp" {
  source         = "../cache/gcp-memorystore"
  count          = var.cloud == "gcp" && local.managed && var.managed_cache ? 1 : 0
  name           = local.name
  env            = var.env
  project_id     = var.gcp_project_id
  region         = var.region
  network        = local.net.network_id
  subnetwork     = local.net.private_subnet_ids[0]
  engine_version = "VALKEY_9_0"
  labels         = local.labels
}
```

## AWS side: `infra/modules/cache/aws-elasticache/main.tf`

Add one key so both clouds return the same output keys:

```hcl
output "cache" {
  value = {
    host           = aws_elasticache_replication_group.this.primary_endpoint_address
    port           = 6379
    tls            = true
    ca_certificate = null # Amazon-issued cert, trusted by the JVM's default trust store
  }
}
```

## Contract test: `infra/modules/cell/tests/contract.tftest.hcl`

Replace the `google_memorystore_instance` mock inside `mock_provider "google"` and add the CA data mock:

```hcl
  mock_resource "google_memorystore_instance" {
    defaults = {
      endpoints = [{ connections = [{ psc_auto_connection = [{ ip_address = "10.30.0.5", port = 6379, connection_type = "CONNECTION_TYPE_PRIMARY" }] }] }]
    }
  }
  mock_data "google_memorystore_instance_certificate_authority" {
    defaults = {
      managed_server_ca = [{ ca_certs = [{ certificates = ["-----BEGIN CERTIFICATE-----\nMIIB\n-----END CERTIFICATE-----"] }] }]
    }
  }
```

Then add this run block after `gcp_managed_contract`:

```hcl
run "gcp_managed_cache_contract" {
  command = apply
  variables {
    cloud   = "gcp"
    profile = "managed"
    region  = "asia-south1"
  }
  assert {
    condition     = output.cache != null && keys(output.cache) == keys(run.aws_managed_contract.cache)
    error_message = "GCP cache must expose the same keys as the AWS cache."
  }
  assert {
    condition     = output.cache.tls && output.cache.ca_certificate != null
    error_message = "Memorystore needs TLS and its server CA in the contract."
  }
}
```

## Before the first apply

- **Check these against your lock file.** The `google_memorystore_instance_certificate_authority` data source and its `managed_server_ca` path are written from memory and may differ. So may the `endpoints` → `psc_auto_connection` path. After the first apply, read them with `terraform console`. Also confirm Memorystore offers `VALKEY_9_0` in `asia-south1`; if it doesn't, the Valkey 9 pin breaks parity.
- **APIs:** enable `memorystore.googleapis.com`, `networkconnectivity.googleapis.com` and `serviceconsumermanagement.googleapis.com` on the prod project.
- **Network access:** VPC firewall rules don't filter traffic to a PSC address the way ElastiCache's security group does. In the GKE cell, Valkey access is limited only by a Kubernetes NetworkPolicy (NetworkPolicy is enforced there). Its egress rules have to allow the endpoint IP on port 6379.
- **Consumers:** Spring's Valkey client has to load `ca_certificate` into its trust store when the value isn't null. That belongs in `20-bootstrap` (as a Secret) and in the services.
- **Not a perfect match:** Memorystore's smallest node, `SHARED_CORE_NANO` (about 1.4 GB), is bigger than `cache.t4g.micro` (0.5 GB). Neither cloud has HA in prod yet, which goes against the "regional HA in prod" rule. Changing that is a decision for both clouds together.
- **Docs to update:** add rows to `docs/leaky-abstractions.md` for PSC vs security groups, the instance-specific CA, and the node size difference.