I don't have a file-writing tool in this session, so the chart is below for you to paste into `gitops/charts/inventory-service/`. Your workspace only has the CloudBridge skill references, not the repo, so I based it on the reference order-service chart and adapted it for inventory: port 8082, 200m/384Mi, and an allowance for 2 inventory calls per gateway request.

**I couldn't set `maxReplicas` to a real number.** Per-pod requests per second (RPS) for inventory-service hasn't been measured yet: `capacity.yaml` still has `inventory-service: 0`. The formula and how to fill it in are under the YAML. Until then, `max: 10` is a placeholder and doesn't prove the GCP cell can take all traffic.

### `Chart.yaml`
```yaml
apiVersion: v2
name: inventory-service
description: CloudBridge inventory-service (escrow leases) — one chart, every cell
type: application
version: 0.1.0
# No appVersion: the image is pinned by digest in gitops/releases/<ring>.yaml
```

### `values.yaml`
```yaml
service: inventory-service
port: 8082
replicas:
  min: 2
  # Must let THIS cell serve 100% of traffic on its own.
  # maxReplicas = ceil(1.2 × peak_gateway_rps_all_cells × fanout / per_pod_rps)
  #   fanout(inventory) = 2   (from gitops/cells/<cell>/capacity.yaml)
  # TODO(capacity): per_pod_rps for inventory-service is not measured yet (capacity.yaml = 0).
  #   Run the k6 test (p95 < 300 ms, errors < 0.5%), put the result in capacity.yaml,
  #   then replace this placeholder and show the arithmetic in the PR.
  max: 10           # PLACEHOLDER — NOT sized for evacuation yet
hpa:
  cpuTargetPercent: 65
  requestRate:
    enabled: false              # turn on once per_pod_rps is measured AND prometheus-adapter serves the metric
    metricName: http_server_requests_per_second
    targetPerPod: ""            # = 0.65 × per_pod_rps, same headroom as the CPU target
resources:
  requests: { cpu: 200m, memory: 384Mi }
  limits: { cpu: "1", memory: 576Mi }
cell: ""            # from gitops/cells/<cell>/values.yaml
cloud: ""
imageRegistryMirror: ""
secretStore: ""
images: {}          # from gitops/releases/<ring>.yaml
```

### `templates/rollout.yaml`
```yaml
apiVersion: argoproj.io/v1alpha1
kind: Rollout
metadata:
  name: {{ .Values.service }}
  labels: { app: {{ .Values.service }}, cb-cell: {{ .Values.cell }} }
spec:
  # no spec.replicas: the HPA owns the replica count
  revisionHistoryLimit: 3
  selector:
    matchLabels: { app: {{ .Values.service }} }
  strategy:
    canary:
      steps:
        - setWeight: 10
        - analysis:
            templates: [{ templateName: cb-canary-health, clusterScope: true }]
            args: [{ name: service, value: {{ .Values.service }} }, { name: cell, value: {{ .Values.cell }} }]
        - setWeight: 50
        - pause: { duration: 5m }
        - setWeight: 100
  template:
    metadata:
      labels: { app: {{ .Values.service }}, cb-cell: {{ .Values.cell }} }
      annotations:
        prometheus.io/scrape: "true"
        prometheus.io/path: /actuator/prometheus
        prometheus.io/port: "{{ .Values.port }}"
    spec:
      automountServiceAccountToken: false
      securityContext:
        runAsNonRoot: true
        runAsUser: 10001
        seccompProfile: { type: RuntimeDefault }
      topologySpreadConstraints:
        - maxSkew: 1
          topologyKey: topology.kubernetes.io/zone
          whenUnsatisfiable: ScheduleAnyway
          labelSelector:
            matchLabels: { app: {{ .Values.service }} }
      containers:
        - name: app
          image: "{{ .Values.imageRegistryMirror }}/{{ required "images.inventory-service missing from ring file" (index .Values.images .Values.service) }}"
          ports: [{ name: http, containerPort: {{ .Values.port }} }]
          env:
            - { name: CB_CELL, value: {{ .Values.cell | quote }} }
            - { name: SERVER_PORT, value: {{ .Values.port | quote }} }
            - { name: SPRING_DATASOURCE_URL, valueFrom: { secretKeyRef: { name: cell-db, key: jdbcUrl } } }
            - { name: SPRING_DATASOURCE_USERNAME, valueFrom: { secretKeyRef: { name: cell-db, key: username } } }
            - { name: SPRING_DATASOURCE_PASSWORD, valueFrom: { secretKeyRef: { name: cell-db, key: password } } }
            - { name: VALKEY_URL, valueFrom: { secretKeyRef: { name: cell-cache, key: url } } }
          resources: {{- toYaml .Values.resources | nindent 12 }}
          securityContext:
            allowPrivilegeEscalation: false
            readOnlyRootFilesystem: true
            capabilities: { drop: [ALL] }
          volumeMounts: [{ name: tmp, mountPath: /tmp }]
          startupProbe:
            httpGet: { path: /actuator/health/liveness, port: http }
            periodSeconds: 2
            failureThreshold: 30
          livenessProbe:
            httpGet: { path: /actuator/health/liveness, port: http }
            periodSeconds: 10
          readinessProbe:
            httpGet: { path: /actuator/health/readiness, port: http }
            periodSeconds: 5
      volumes: [{ name: tmp, emptyDir: {} }]
```
`clusterScope: true` matches the `ClusterAnalysisTemplate` in platform-addons.

### `templates/service.yaml`
```yaml
apiVersion: v1
kind: Service
metadata:
  name: {{ .Values.service }}
  labels: { app: {{ .Values.service }} }
spec:
  selector: { app: {{ .Values.service }} }
  ports:
    - { name: http, port: {{ .Values.port }}, targetPort: http }
```

### `templates/hpa.yaml`
```yaml
{{- if lt (int .Values.replicas.max) (int .Values.replicas.min) }}
{{- fail "replicas.max must be >= replicas.min" }}
{{- end }}
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: {{ .Values.service }}
spec:
  scaleTargetRef:
    apiVersion: argoproj.io/v1alpha1
    kind: Rollout
    name: {{ .Values.service }}
  minReplicas: {{ .Values.replicas.min }}   # pre-warm raises this at runtime; Argo ignores the diff
  maxReplicas: {{ .Values.replicas.max }}   # evacuation ceiling — see values.yaml arithmetic
  metrics:
    - type: Resource
      resource:
        name: cpu
        target: { type: Utilization, averageUtilization: {{ .Values.hpa.cpuTargetPercent }} }
    {{- if .Values.hpa.requestRate.enabled }}
    - type: Pods
      pods:
        metric: { name: {{ .Values.hpa.requestRate.metricName }} }
        target: { type: AverageValue, averageValue: {{ required "hpa.requestRate.targetPerPod (0.65 × measured per_pod_rps)" .Values.hpa.requestRate.targetPerPod | quote }} }
    {{- end }}
  behavior:
    scaleUp:
      stabilizationWindowSeconds: 0
      selectPolicy: Max
      policies:
        - { type: Percent, value: 100, periodSeconds: 30 }
        - { type: Pods, value: 4, periodSeconds: 30 }   # don't crawl 2→4→8 when a failover hits a cold cell
    scaleDown:
      stabilizationWindowSeconds: 300
```

### `templates/pdb.yaml`
```yaml
apiVersion: policy/v1
kind: PodDisruptionBudget
metadata:
  name: {{ .Values.service }}
spec:
  minAvailable: 1
  selector:
    matchLabels: { app: {{ .Values.service }} }
```

### Stopping Argo from undoing pre-warm (`gitops/bootstrap/applicationset.yaml.tftpl`)
Before a failover, `prewarm.yml` raises `minReplicas` on the GCP cell. Without the setting below, Argo's `selfHeal` would immediately set it back:
```yaml
      ignoreDifferences:
        - group: autoscaling
          kind: HorizontalPodAutoscaler
          jsonPointers:
            - /spec/minReplicas
      syncPolicy:
        automated: { prune: true, selfHeal: true }
        syncOptions:
          - CreateNamespace=true
          - ServerSideApply=true
          - RespectIgnoreDifferences=true   # without this, a sync still writes minReplicas back
```
`maxReplicas` is deliberately not ignored. Changing it should go through a reviewed PR.

### Sizing `maxReplicas` for a full failover
```
maxReplicas = ceil(1.2 × peak_gateway_rps_all_cells × 2 / per_pod_rps_inventory)
```
- **`peak_gateway_rps_all_cells`**: the highest gateway traffic across both clouds combined, not just GCP's 30%. Take the 7-day peak of `sum(rate(http_server_requests_seconds_count{service="api-gateway"}[5m]))` across all cells.
- **`× 2`**: the fan-out. Each gateway request makes 2 inventory calls, so inventory needs twice the gateway's request rate.
- **`per_pod_rps_inventory`**: the highest RPS one pod handles at 200m CPU with p95 latency under 300 ms. Measure it with k6 and record it in `gitops/cells/cb-gcp-prod/capacity.yaml`.

Once you have that number:
1. Replace the placeholder `max`.
2. Show the arithmetic in the PR.
3. Set `hpa.requestRate.targetPerPod` to 0.65 × per-pod RPS.
4. Turn on `requestRate` once prometheus-adapter serves the metric. I assumed the metric name, so check it against your adapter rules.

### What to check before you rely on it
- **Node capacity:** the GKE node pool's autoscaler limit must fit `maxReplicas × 200m` on top of everything else. That limit is in the Terraform cell config, not this chart. A high `maxReplicas` with too few nodes just leaves pods stuck in Pending.
- **Run a drill:** the capacity check uses the same formula and needs a ratio of at least 1.2 to proceed. Running it shows whether the GCP cell can take all traffic.
- **Lease endpoint (`/admin/leases`):** it should only be reachable from the control plane. That network policy belongs in platform-addons, not this chart, so check it exists there.