I didn't find an existing chart or service code in the working directory, and this session can't write files or run `helm`. So the chart is below as files to paste, and it hasn't been through `helm lint` or `helm template`. Swap in your own numbers where noted.

**How it handles failover:** the GCP cell's HPA ceiling (`maxReplicas`) is **calculated from total traffic across all cells** rather than set by hand. The render fails if anyone sets a ceiling below that. The CPU target is also kept low enough that when load suddenly doubles, pods are slow but not overloaded while the HPA adds replicas.

### `inventory-service/Chart.yaml`
```yaml
apiVersion: v2
name: inventory-service
description: Inventory service, sized so a single cell can absorb all traffic on failover
type: application
version: 0.1.0
appVersion: "1.0.0"
```

### `inventory-service/values.yaml`
```yaml
nameOverride: ""
fullnameOverride: ""

replicaCount: 3            # only used when autoscaling.enabled=false

image:
  repository: REGISTRY/inventory-service
  tag: ""                  # defaults to .Chart.AppVersion
  pullPolicy: IfNotPresent
imagePullSecrets: []

serviceAccount:
  create: true
  name: ""
  annotations: {}          # e.g. iam.gke.io/gcp-service-account for Workload Identity

podAnnotations: {}
podLabels: {}
priorityClassName: ""

containerPort: 8080
service:
  type: ClusterIP
  port: 80

probes:
  readinessPath: /ready
  livenessPath: /healthz

env: []

# HPA scales on CPU utilization, so requests must be set.
# No CPU limit on purpose: throttling during a failover surge makes things worse.
resources:
  requests:
    cpu: 500m
    memory: 512Mi
  limits:
    memory: 1Gi

# ---- Failover sizing --------------------------------------------------------
# maxReplicas = ceil(globalPeakRps * (1 + headroom) / perPodRps)
capacity:
  globalPeakRps: 4000      # peak RPS across ALL cells combined, not just this one
  perPodRps: 100           # RPS one pod sustains at autoscaling.targetCPUUtilizationPercentage (load-test this)
  headroom: 0.25           # margin above observed peak

autoscaling:
  enabled: true
  minReplicas: 6
  maxReplicas: null        # null = computed from capacity; an explicit value below the computed one fails the render
  failoverMode: false      # true = raise minReplicas to the full-failover count (pre-scale on a declared failover)
  # With 2 cells, keep this at or below ~1/2 of the CPU% where latency degrades.
  # When the other cell drops, per-pod load roughly doubles instantly; at 45% that
  # lands near 90% instead of saturating while the HPA catches up.
  targetCPUUtilizationPercentage: 45
  behavior:
    scaleUp:
      stabilizationWindowSeconds: 0
      selectPolicy: Max
      policies:
        - type: Percent
          value: 100
          periodSeconds: 15
        - type: Pods
          value: 10
          periodSeconds: 15
    scaleDown:
      # Slow scale-down so a flapping failover/failback doesn't strip capacity
      stabilizationWindowSeconds: 600
      selectPolicy: Min
      policies:
        - type: Percent
          value: 10
          periodSeconds: 60

podDisruptionBudget:
  enabled: true
  maxUnavailable: 10%
```

### `inventory-service/values-gcp.yaml`
```yaml
# GCP cell. capacity.globalPeakRps must be the WHOLE fleet's peak, since this
# cell has to carry everything when the other cell is out.
capacity:
  globalPeakRps: 4000
  perPodRps: 100
  headroom: 0.25

autoscaling:
  minReplicas: 6
  targetCPUUtilizationPercentage: 45

serviceAccount:
  annotations:
    iam.gke.io/gcp-service-account: inventory-service@PROJECT_ID.iam.gserviceaccount.com
```

### `inventory-service/templates/_helpers.tpl`
```yaml
{{- define "inventory-service.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "inventory-service.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "inventory-service.selectorLabels" -}}
app.kubernetes.io/name: {{ include "inventory-service.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "inventory-service.labels" -}}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{ include "inventory-service.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "inventory-service.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "inventory-service.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/* Replicas needed for this cell to carry 100% of global traffic. */}}
{{- define "inventory-service.failoverReplicas" -}}
{{- $c := .Values.capacity -}}
{{- $perPod := float64 (required "capacity.perPodRps is required" $c.perPodRps) -}}
{{- $peak := float64 (required "capacity.globalPeakRps is required" $c.globalPeakRps) -}}
{{- $need := divf (mulf $peak (addf 1.0 (float64 $c.headroom))) $perPod -}}
{{- ceil $need | int -}}
{{- end }}
```

### `inventory-service/templates/hpa.yaml`
```yaml
{{- if .Values.autoscaling.enabled }}
{{- $failover := include "inventory-service.failoverReplicas" . | atoi }}
{{- $max := $failover }}
{{- with .Values.autoscaling.maxReplicas }}
{{- $max = int . }}
{{- end }}
{{- if lt $max $failover }}
{{- fail (printf "autoscaling.maxReplicas=%d is below the %d replicas needed to carry all traffic during failover" $max $failover) }}
{{- end }}
{{- $min := int .Values.autoscaling.minReplicas }}
{{- if .Values.autoscaling.failoverMode }}
{{- $min = $failover }}
{{- end }}
{{- if gt $min $max }}
{{- fail (printf "minReplicas (%d) exceeds maxReplicas (%d)" $min $max) }}
{{- end }}
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: {{ include "inventory-service.fullname" . }}
  labels:
    {{- include "inventory-service.labels" . | nindent 4 }}
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: {{ include "inventory-service.fullname" . }}
  minReplicas: {{ $min }}
  maxReplicas: {{ $max }}
  metrics:
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: {{ .Values.autoscaling.targetCPUUtilizationPercentage }}
  behavior:
    {{- toYaml .Values.autoscaling.behavior | nindent 4 }}
{{- end }}
```

### `inventory-service/templates/deployment.yaml`
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ include "inventory-service.fullname" . }}
  labels:
    {{- include "inventory-service.labels" . | nindent 4 }}
spec:
  {{- if not .Values.autoscaling.enabled }}
  replicas: {{ .Values.replicaCount }}
  {{- end }}
  revisionHistoryLimit: 5
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxSurge: 25%
      maxUnavailable: 0
  selector:
    matchLabels:
      {{- include "inventory-service.selectorLabels" . | nindent 6 }}
  template:
    metadata:
      {{- with .Values.podAnnotations }}
      annotations:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      labels:
        {{- include "inventory-service.labels" . | nindent 8 }}
        {{- with .Values.podLabels }}
        {{- toYaml . | nindent 8 }}
        {{- end }}
    spec:
      {{- with .Values.imagePullSecrets }}
      imagePullSecrets:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      serviceAccountName: {{ include "inventory-service.serviceAccountName" . }}
      {{- with .Values.priorityClassName }}
      priorityClassName: {{ . }}
      {{- end }}
      terminationGracePeriodSeconds: 30
      topologySpreadConstraints:
        - maxSkew: 1
          topologyKey: topology.kubernetes.io/zone
          whenUnsatisfiable: ScheduleAnyway
          labelSelector:
            matchLabels:
              {{- include "inventory-service.selectorLabels" . | nindent 14 }}
      containers:
        - name: {{ .Chart.Name }}
          image: "{{ .Values.image.repository }}:{{ .Values.image.tag | default .Chart.AppVersion }}"
          imagePullPolicy: {{ .Values.image.pullPolicy }}
          ports:
            - name: http
              containerPort: {{ .Values.containerPort }}
              protocol: TCP
          {{- with .Values.env }}
          env:
            {{- toYaml . | nindent 12 }}
          {{- end }}
          startupProbe:
            httpGet:
              path: {{ .Values.probes.readinessPath }}
              port: http
            periodSeconds: 5
            failureThreshold: 24
          readinessProbe:
            httpGet:
              path: {{ .Values.probes.readinessPath }}
              port: http
            periodSeconds: 5
            failureThreshold: 3
          livenessProbe:
            httpGet:
              path: {{ .Values.probes.livenessPath }}
              port: http
            periodSeconds: 10
            failureThreshold: 3
          lifecycle:
            preStop:
              sleep:
                seconds: 10
          resources:
            {{- toYaml .Values.resources | nindent 12 }}
```

### `inventory-service/templates/service.yaml`
```yaml
apiVersion: v1
kind: Service
metadata:
  name: {{ include "inventory-service.fullname" . }}
  labels:
    {{- include "inventory-service.labels" . | nindent 4 }}
spec:
  type: {{ .Values.service.type }}
  ports:
    - port: {{ .Values.service.port }}
      targetPort: http
      protocol: TCP
      name: http
  selector:
    {{- include "inventory-service.selectorLabels" . | nindent 4 }}
```

### `inventory-service/templates/pdb.yaml`
```yaml
{{- if .Values.podDisruptionBudget.enabled }}
apiVersion: policy/v1
kind: PodDisruptionBudget
metadata:
  name: {{ include "inventory-service.fullname" . }}
  labels:
    {{- include "inventory-service.labels" . | nindent 4 }}
spec:
  maxUnavailable: {{ .Values.podDisruptionBudget.maxUnavailable }}
  selector:
    matchLabels:
      {{- include "inventory-service.selectorLabels" . | nindent 6 }}
{{- end }}
```

### `inventory-service/templates/serviceaccount.yaml`
```yaml
{{- if .Values.serviceAccount.create }}
apiVersion: v1
kind: ServiceAccount
metadata:
  name: {{ include "inventory-service.serviceAccountName" . }}
  labels:
    {{- include "inventory-service.labels" . | nindent 4 }}
  {{- with .Values.serviceAccount.annotations }}
  annotations:
    {{- toYaml . | nindent 4 }}
  {{- end }}
{{- end }}
```

### `inventory-service/templates/NOTES.txt`
```
inventory-service deployed.
{{- if .Values.autoscaling.enabled }}
Failover capacity: {{ include "inventory-service.failoverReplicas" . }} replicas
  ({{ .Values.capacity.globalPeakRps }} global peak RPS x {{ add1 0 | mulf (addf 1.0 (float64 .Values.capacity.headroom)) }} / {{ .Values.capacity.perPodRps }} RPS per pod)
failoverMode: {{ .Values.autoscaling.failoverMode }}
{{- end }}
```

### Usage
```bash
helm upgrade --install inventory-service ./inventory-service -f inventory-service/values-gcp.yaml

# Declared failover: raise the replica floor right away instead of waiting for the HPA
helm upgrade inventory-service ./inventory-service -f inventory-service/values-gcp.yaml --set autoscaling.failoverMode=true
```

With the example numbers, the GCP cell runs at 6–50 replicas: 4000 × 1.25 / 100 = 50.

### Before you rely on it
- **Measure `perPodRps` and `globalPeakRps`.** The numbers above are placeholders. `perPodRps` must be measured at the same CPU target (45%), or the replica math is off.
- **The cluster has to be able to fit 50 pods.** At 50 × 500m that's 25 vCPU. Check the GKE node pool's autoscaler maximum and the regional CPU quota, or the HPA will create pods that sit Pending. Adding new nodes takes minutes, so for a sudden unplanned failover, consider reserving spare capacity with low-priority placeholder pods.
- **The database has to handle 50 pods' connections.** 50 × the per-pod connection pool size must fit within the database's connection limit. This is a common reason failovers break.
- **Check the cluster version for the shutdown delay.** The deployment uses Kubernetes' built-in pre-shutdown sleep, which needs Kubernetes 1.30 or later. On older clusters, replace it with `exec: ["sh","-c","sleep 10"]`.