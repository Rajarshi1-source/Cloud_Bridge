I couldn't save any files because writing is turned off in this session, and your working directory is empty. So the config is below to copy in. Nothing here has been run through `promtool` or `ansible-rulebook`.

I had no existing config to go on, so I assumed the following. Change them to match your setup:
- **SLO:** 99.9% availability per cell over 30 days, so the error budget is 0.1%.
- **SLI metric:** `http_requests_total{job="api", code, cell}`, with 5xx responses counted as errors.
- **Drill:** an existing AAP job template called `"Cell burn drill"` that takes a `cell` variable.

## 1. Prometheus rules (`slo-cell-error-budget.rules.yml`)

This uses alerts that check several time windows at different burn speeds. "Burn rate" means how fast the error budget is being used, and 14.4× would use up the 30-day budget in about 2 days. Only the fast-burn alert has the `eda_action` label, so only it starts the drill. The slow burn just opens a ticket.

```yaml
groups:
  - name: slo-cell-availability-recording
    interval: 30s
    rules:
      - record: cell:slo_requests:rate5m
        expr: sum by (cell) (rate(http_requests_total{job="api"}[5m]))
      - record: cell:slo_errors:ratio_rate5m
        expr: sum by (cell) (rate(http_requests_total{job="api",code=~"5.."}[5m])) / sum by (cell) (rate(http_requests_total{job="api"}[5m]))
      - record: cell:slo_errors:ratio_rate30m
        expr: sum by (cell) (rate(http_requests_total{job="api",code=~"5.."}[30m])) / sum by (cell) (rate(http_requests_total{job="api"}[30m]))
      - record: cell:slo_errors:ratio_rate1h
        expr: sum by (cell) (rate(http_requests_total{job="api",code=~"5.."}[1h])) / sum by (cell) (rate(http_requests_total{job="api"}[1h]))
      - record: cell:slo_errors:ratio_rate2h
        expr: sum by (cell) (rate(http_requests_total{job="api",code=~"5.."}[2h])) / sum by (cell) (rate(http_requests_total{job="api"}[2h]))
      - record: cell:slo_errors:ratio_rate6h
        expr: sum by (cell) (rate(http_requests_total{job="api",code=~"5.."}[6h])) / sum by (cell) (rate(http_requests_total{job="api"}[6h]))
      - record: cell:slo_errors:ratio_rate1d
        expr: sum by (cell) (rate(http_requests_total{job="api",code=~"5.."}[1d])) / sum by (cell) (rate(http_requests_total{job="api"}[1d]))
      - record: cell:slo_errors:ratio_rate3d
        expr: sum by (cell) (rate(http_requests_total{job="api",code=~"5.."}[3d])) / sum by (cell) (rate(http_requests_total{job="api"}[3d]))

  - name: slo-cell-availability-alerts
    rules:
      # Fast burn: pages a human AND triggers the Ansible EDA cell drill.
      - alert: CellErrorBudgetFastBurn
        expr: |
          (
            (cell:slo_errors:ratio_rate1h > (14.4 * 0.001) and cell:slo_errors:ratio_rate5m  > (14.4 * 0.001))
            or
            (cell:slo_errors:ratio_rate6h > (6 * 0.001)    and cell:slo_errors:ratio_rate30m > (6 * 0.001))
          )
          # Ignore near-idle cells so a handful of 5xx can't kick off a drill.
          and on (cell) cell:slo_requests:rate5m > 1
        for: 2m
        labels:
          severity: page
          slo: cell-availability
          eda_action: cell_burn_drill
        annotations:
          summary: "Cell {{ $labels.cell }} is burning error budget fast"
          description: >-
            Cell {{ $labels.cell }} error ratio is {{ $value | humanizePercentage }}
            (SLO allows 0.1%). 30d budget gone in well under 3 days at this rate.
            Ansible EDA cell drill triggered.
          runbook_url: "https://runbooks.example.internal/slo/cell-error-budget-burn"

      # Slow burn: ticket only, no automation.
      - alert: CellErrorBudgetSlowBurn
        expr: |
          (
            (cell:slo_errors:ratio_rate1d > (3 * 0.001) and cell:slo_errors:ratio_rate2h > (3 * 0.001))
            or
            (cell:slo_errors:ratio_rate3d > (1 * 0.001) and cell:slo_errors:ratio_rate6h > (1 * 0.001))
          )
          and on (cell) cell:slo_requests:rate5m > 1
        for: 15m
        labels:
          severity: ticket
          slo: cell-availability
        annotations:
          summary: "Cell {{ $labels.cell }} is steadily burning error budget"
          runbook_url: "https://runbooks.example.internal/slo/cell-error-budget-burn"
```

## 2. Alertmanager route to EDA (merge into `alertmanager.yml`)

```yaml
route:
  routes:
    - matchers: [eda_action="cell_burn_drill"]
      receiver: ansible-eda
      group_by: [alertname, cell]
      group_wait: 30s
      group_interval: 5m
      repeat_interval: 4h
      continue: true          # still falls through to the normal paging route

receivers:
  - name: ansible-eda
    webhook_configs:
      - url: "http://eda-controller.internal:5000/endpoint"
        send_resolved: true

inhibit_rules:
  - source_matchers: [alertname="CellErrorBudgetFastBurn"]
    target_matchers: [alertname="CellErrorBudgetSlowBurn"]
    equal: [cell]
```

## 3. EDA rulebook

```yaml
---
- name: Cell error budget burn drill
  hosts: all
  sources:
    - ansible.eda.alertmanager:
        host: 0.0.0.0
        port: 5000
        data_alerts_path: alerts
        data_host_path: ""      # cell alerts have no `instance` label
  rules:
    - name: Start drill when a cell is burning budget fast
      condition: >-
        event.alert.status == "firing"
        and event.alert.labels.eda_action == "cell_burn_drill"
      throttle:                 # Alertmanager re-sends; run once per cell per hour
        once_within: 1 hour
        group_by_attributes:
          - event.alert.labels.cell
      action:
        run_job_template:
          name: "Cell burn drill"
          organization: Default
          job_args:
            extra_vars:
              cell: "{{ event.alert.labels.cell }}"
              alert_name: "{{ event.alert.labels.alertname }}"
              fingerprint: "{{ event.alert.fingerprint }}"
```

**Settings worth checking:**
- **What triggers the drill:** Rulebook, Alertmanager and alert are tied together by the `eda_action` label, not by the alert name. To have other alerts start the drill later, give them the same label.
- **`continue: true`:** this setting both starts the drill and pages a person. Remove it if the drill should replace the page.
- **Traffic floor (`> 1` req/s):** this stops a few errors in a quiet cell from starting the drill. Set it to suit your lowest-traffic cell.
- **Retries:** the 1-hour `throttle` stops the drill from running again on every Alertmanager resend (`repeat_interval`). If the drill takes longer than an hour, make the throttle longer.
- **Not using AAP:** if you run `ansible-rulebook` on its own without AAP, change `run_job_template` to `run_playbook: { name: playbooks/cell_drill.yml, extra_vars: {...} }`.

If you send me your real metric names, `cell` label and SLO target, I'll update the rules to match.