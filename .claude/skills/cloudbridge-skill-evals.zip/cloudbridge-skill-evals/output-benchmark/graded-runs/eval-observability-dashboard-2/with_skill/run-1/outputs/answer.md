I've written it below as text, because this session has no file-write tool and the working directory only has the skill references (no `observability/` tree). Paste it into `observability/prometheus/rules/` and `alertmanager.yml`.

**The existing `CellSLOBurnFast` can't route the drill correctly.** Every rule behind it groups `by (cb_cell)` only, so the alert arrives at EDA with no `cb_cloud` and no `cb_env`. The rulebook then has nothing to work out `from_cell` and `to_cell` from. Its prod guard is `cb_env != "prod"`, and that check depends on a label the alert never has. The version below keeps those labels through every step and refuses to trigger a drill when they're missing.

### `observability/prometheus/rules/slo-cell.yml`

```yaml
# Per-cell availability SLO: 99.5% / 28d, so the error budget is 0.005.
# Fast burn = 14.4x, which uses 2% of the 28d budget in 1h.
# Every rule keeps cb_cell, cb_cloud and cb_env (Prometheus agent external_labels).
# The EDA rulebook routes on these labels, so don't drop them.
groups:
  - name: cb-slo-cell-burn
    rules:
      - record: cb:gateway_requests:rate5m
        expr: sum by (cb_cell, cb_cloud, cb_env) (rate(http_server_requests_seconds_count{service="api-gateway", uri!~"/actuator.*|/healthz.*"}[5m]))
      - record: cb:gateway_requests:rate1h
        expr: sum by (cb_cell, cb_cloud, cb_env) (rate(http_server_requests_seconds_count{service="api-gateway", uri!~"/actuator.*|/healthz.*"}[1h]))

      - record: cb:error_ratio:rate5m
        expr: |
          sum by (cb_cell, cb_cloud, cb_env) (rate(http_server_requests_seconds_count{service="api-gateway", status=~"5..", uri!~"/actuator.*|/healthz.*"}[5m]))
          / cb:gateway_requests:rate5m
      - record: cb:error_ratio:rate30m
        expr: |
          sum by (cb_cell, cb_cloud, cb_env) (rate(http_server_requests_seconds_count{service="api-gateway", status=~"5..", uri!~"/actuator.*|/healthz.*"}[30m]))
          / sum by (cb_cell, cb_cloud, cb_env) (rate(http_server_requests_seconds_count{service="api-gateway", uri!~"/actuator.*|/healthz.*"}[30m]))
      - record: cb:error_ratio:rate1h
        expr: |
          sum by (cb_cell, cb_cloud, cb_env) (rate(http_server_requests_seconds_count{service="api-gateway", status=~"5..", uri!~"/actuator.*|/healthz.*"}[1h]))
          / cb:gateway_requests:rate1h
      - record: cb:error_ratio:rate6h
        expr: |
          sum by (cb_cell, cb_cloud, cb_env) (rate(http_server_requests_seconds_count{service="api-gateway", status=~"5..", uri!~"/actuator.*|/healthz.*"}[6h]))
          / sum by (cb_cell, cb_cloud, cb_env) (rate(http_server_requests_seconds_count{service="api-gateway", uri!~"/actuator.*|/healthz.*"}[6h]))
      - record: cb:availability:ratio_rate1h
        expr: 1 - cb:error_ratio:rate1h

  - name: cb-slo-cell-alerts
    rules:
      - alert: CellSLOBurnFast
        # Both windows must be burning: the 1h window shows the burn is real, the 5m window shows it is still happening.
        # The traffic floor stops a few 5xx on a quiet cell from starting a drill. 0.5 rps is a starting value, so tune it.
        expr: |
          cb:error_ratio:rate1h > (14.4 * 0.005)
          and cb:error_ratio:rate5m > (14.4 * 0.005)
          and cb:gateway_requests:rate1h > 0.5
        for: 2m
        labels:
          severity: page
          slo: cell-availability
          eda: evacuate
        annotations:
          summary: "{{ $labels.cb_cell }} ({{ $labels.cb_cloud }}/{{ $labels.cb_env }}) burning error budget at {{ $value | humanizePercentage }} 5xx (>14.4x)"
          description: "Gateway 5xx ratio exceeds 14.4x budget over 1h and 5m. Non-prod: EDA runs evacuate.yml mode=drill. Prod: EDA opens an evacuation proposal only."
          dashboard: "/d/cb-overview?var-cell={{ $labels.cb_cell }}"

      - alert: CellSLOBurnSlow
        expr: |
          cb:error_ratio:rate6h > (6 * 0.005)
          and cb:error_ratio:rate30m > (6 * 0.005)
          and cb:gateway_requests:rate1h > 0.5
        for: 15m
        labels:
          severity: ticket
          slo: cell-availability
```

The `and` operators have no `on (...)`, so all three labels have to match on both sides. One environment's numbers can't mix with another's.

### `alertmanager.yml`: send to EDA only when the alert can be routed

```yaml
route:
  receiver: slack
  group_by: [alertname, cb_cell, cb_env]
  routes:
    # Send to EDA only when it can tell the cloud and env. Otherwise page only (route below).
    - matchers:
        - alertname="CellSLOBurnFast"
        - cb_cloud=~"aws|gcp"
        - cb_env=~".+"
      receiver: slack-and-eda
      group_wait: 0s
      repeat_interval: 30m       # matches the rulebook throttle
    - matchers: [alertname="CellSLOBurnFast"]
      receiver: slack            # labels missing: a person looks, no automation
```

`slack-and-eda` stays as it is in the starter (`http://eda:5000/endpoint`, `send_resolved: true`).

### Change the rulebook condition too (`rulebooks/cell-degraded.yml`)

At the moment the non-prod branch fires on `cb_env != "prod"`. Make it require the labels to be present, so the condition fails safe:

```yaml
condition: >-
  event.alert.labels.alertname == "CellSLOBurnFast" and
  event.alert.status == "firing" and
  event.alert.labels.cb_cloud is defined and
  event.alert.labels.cb_env is defined and
  event.alert.labels.cb_env != "prod"
```

### Still open
- **Drills can trigger each other.** A drill pushes all traffic into the other cell. If that cell starts burning, its own `CellSLOBurnFast` fires, and EDA starts a drill in the opposite direction. The throttle is grouped by `cb_cell`, so it doesn't stop this. Neither skill's playbooks have a lock for a drill that's already running. The fix is either an `in_progress` check in `evacuate.yml` against `/drills`, or an inhibit rule driven by a "drill active" gauge from the control-plane API. I can add whichever you prefer.
- **Some numbers are starting guesses.** The `0.5` rps traffic floor and the `for: 2m` delay aren't based on your measured traffic. Check them against `cb:gateway_requests:rate1h` from a quiet period before relying on them.
- **The rule changes add labels.** Grafana panels or Rollouts queries that read these series with `by (cb_cell)` will still work. Anything that compares series one-to-one using only `cb_cell` should get a quick check.