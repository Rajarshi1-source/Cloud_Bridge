I couldn't write the files to disk because this session has no file-write or shell tool. Here is the full stack to put under `infra/live/global/30-traffic/`. I haven't run `terraform validate` or `terraform test` on it, so run both before opening the PR.

The 3% rule is `gcp_min` in `variables.tf`: each cell's weight must be 0 (drained) or at least 10. It's checked before Terraform reads anything else, so `{ "aws": 97, "gcp": 3 }` fails at plan time and nothing is changed.

### `versions.tf`
```hcl
terraform {
  required_version = ">= 1.15.0, < 2.0.0"
  required_providers {
    cloudflare = { source = "cloudflare/cloudflare", version = "~> 5.22" }
  }
  # GCS, not S3: this stack must stay applyable when AWS is the failing cloud.
  backend "gcs" {
    bucket = "cb-tfstate-gcp"
    prefix = "global/traffic"
  }
}

provider "cloudflare" {
  # CLOUDFLARE_API_TOKEN from the traffic-prod GitHub environment.
  # Scope: Zone > Load Balancers: Edit, Account > Load Balancing: Monitors And Pools: Edit.
}
```

### `variables.tf`
```hcl
variable "zone_id" {
  type = string
}

variable "account_id" {
  type = string
}

variable "hostname" {
  type        = string
  description = "Public hostname, e.g. app.example.dev"
}

variable "weights" {
  type        = map(number)
  description = "Percent of traffic per cell. Lives only in terraform.tfvars.json; changed via PR, recommender PR, or the evacuation playbook."

  validation {
    condition     = length(setsubtract(keys(var.weights), ["aws", "gcp"])) == 0
    error_message = "Unknown cell key; allowed: aws, gcp."
  }

  validation {
    condition     = alltrue([for w in values(var.weights) : floor(w) == w])
    error_message = "Weights are whole percentages."
  }

  validation {
    condition     = sum(values(var.weights)) == 100
    error_message = "Weights must sum to 100."
  }

  # Warm floor: a cell at 3% has cold caches, un-JITed code and a scaled-in
  # node pool, so it fails as soon as it gets real traffic.
  # A cell is either warm (>= 10) or deliberately drained (0).
  validation {
    condition     = alltrue([for w in values(var.weights) : w == 0 || w >= 10])
    error_message = "Each cell must be 0 (drained) or >= 10 (warm floor). To move everything off a cell, run ansible/playbooks/evacuate.yml."
  }
}

variable "fallback_cell" {
  type    = string
  default = "gcp"

  validation {
    condition     = contains(["aws", "gcp"], var.fallback_cell)
    error_message = "fallback_cell must be aws or gcp."
  }
}

variable "aws_origin_stack" {
  type        = string
  default     = "aws-prod/20-bootstrap.tfstate"
  description = "Managed AWS origin is the ALB created in 20-bootstrap; the budget profile uses 10-foundation."
}
```

### `terraform.tfvars.json`
This is the only place weights are set. Replace the IDs with your real ones.
```json
{
  "zone_id": "0123456789abcdef0123456789abcdef",
  "account_id": "fedcba9876543210fedcba9876543210",
  "hostname": "app.example.dev",
  "weights": { "aws": 70, "gcp": 30 }
}
```

### `main.tf`
```hcl
data "terraform_remote_state" "aws" {
  backend = "s3"
  config = {
    bucket = "cb-tfstate-aws"
    key    = var.aws_origin_stack
    region = "ap-south-1"
  }
}

data "terraform_remote_state" "gcp" {
  backend = "gcs"
  config = {
    bucket = "cb-tfstate-gcp"
    prefix = "gcp-prod/10-foundation"
  }
}

locals {
  origins = {
    aws = data.terraform_remote_state.aws.outputs.cell.origin
    gcp = data.terraform_remote_state.gcp.outputs.cell.origin
  }
}

check "origins_known" {
  assert {
    condition     = alltrue([for o in values(local.origins) : o != null && o != ""])
    error_message = "A cell origin is empty. For AWS managed, apply 20-bootstrap first so the ALB exists."
  }
}

# /healthz/cell = gateway + order-service ready + cell DB reachable. Cache deliberately excluded.
# Detection is about 2-3 minutes (60 s interval x 2 retries), so failover is not instant.
resource "cloudflare_load_balancer_monitor" "cell" {
  account_id     = var.account_id
  type           = "https"
  method         = "GET"
  path           = "/healthz/cell"
  expected_codes = "200"
  interval       = 60
  retries        = 2
  timeout        = 5
  header         = { "Host" = [var.hostname] }
  description    = "CloudBridge cell health"
}

resource "cloudflare_load_balancer_pool" "cell" {
  for_each   = local.origins
  account_id = var.account_id
  name       = "cb-${each.key}-prod"
  monitor    = cloudflare_load_balancer_monitor.cell.id

  # One origin per pool, so origin weight does nothing. The split comes from pool weights below.
  origins = [{
    name    = "${each.key}-ingress"
    address = each.value
    enabled = true
    header  = { host = [var.hostname] }
  }]
  minimum_origins = 1

  # Probe from South Asia and Southeast Asia, near the Mumbai origins.
  check_regions = ["SAS", "SEAS"]
}

resource "cloudflare_load_balancer" "app" {
  zone_id         = var.zone_id
  name            = var.hostname
  proxied         = true
  default_pools   = [for k in sort(keys(local.origins)) : cloudflare_load_balancer_pool.cell[k].id]
  fallback_pool   = cloudflare_load_balancer_pool.cell[var.fallback_cell].id
  steering_policy = "random"

  random_steering = {
    default_weight = 0
    pool_weights   = { for k, pct in var.weights : cloudflare_load_balancer_pool.cell[k].id => pct / 100 }
  }

  # Each cell owns its own DB, so the cookie pins a user to a home cell (read-your-writes).
  session_affinity     = "cookie"
  session_affinity_ttl = 82800
  session_affinity_attributes = {
    samesite               = "Lax"
    secure                 = "Always"
    drain_duration         = 60
    zero_downtime_failover = "sticky"
  }
}
```

### `outputs.tf`
```hcl
output "pool_ids" {
  value = { for k, p in cloudflare_load_balancer_pool.cell : k => p.id }
}

output "lb_id" {
  value = cloudflare_load_balancer.app.id
}

output "weights" {
  value = var.weights
}
```

### `tests/weights.tftest.hcl` — tests for the 3% rule
```hcl
mock_provider "cloudflare" {}

override_data {
  target = data.terraform_remote_state.aws
  values = { outputs = { cell = { origin = "aws-alb.example.dev" } } }
}

override_data {
  target = data.terraform_remote_state.gcp
  values = { outputs = { cell = { origin = "203.0.113.10" } } }
}

variables {
  zone_id    = "0123456789abcdef0123456789abcdef"
  account_id = "fedcba9876543210fedcba9876543210"
  hostname   = "app.example.dev"
  weights    = { aws = 70, gcp = 30 }
}

run "accepts_70_30_as_pool_weights" {
  command = apply
  assert {
    condition     = toset(values(cloudflare_load_balancer.app.random_steering.pool_weights)) == toset([0.7, 0.3])
    error_message = "70/30 must land on pool weights as 0.7/0.3."
  }
  assert {
    condition     = toset(cloudflare_load_balancer_pool.cell["aws"].check_regions) == toset(["SAS", "SEAS"])
    error_message = "Health checks must run from India / South-East Asia."
  }
}

run "rejects_gcp_3" {
  command   = plan
  variables { weights = { aws = 97, gcp = 3 } }
  expect_failures = [var.weights]
}

run "rejects_aws_3" {
  command   = plan
  variables { weights = { aws = 3, gcp = 97 } }
  expect_failures = [var.weights]
}

run "rejects_fractional_sneak" {
  command   = plan
  variables { weights = { aws = 90.5, gcp = 9.5 } }
  expect_failures = [var.weights]
}

run "allows_drain" {
  command   = plan
  variables { weights = { aws = 0, gcp = 100 } }
}

run "rejects_unknown_cell" {
  command   = plan
  variables { weights = { aws = 70, azure = 30 } }
  expect_failures = [var.weights]
}
```

### Things to know
- **The other path to 3%.** The break-glass script (`tools/cf_break_glass.py`) changes weights directly through the Cloudflare API, so Terraform's check doesn't apply there. The script already rejects any weight that is neither 0 nor at least 10. Keep that check in the script so neither path can set 3%.
- **0/100 is valid but shouldn't be a plain PR.** Moving everything to one cell is an evacuation. Use `ansible/playbooks/evacuate.yml`, which checks capacity first.
- **Possible problem when AWS is down.** The state is in GCS so this stack can be applied when AWS is the failing cloud. But `data.terraform_remote_state.aws` still reads from S3, so if S3 in `ap-south-1` is unreachable, the plan fails. At that point your options are break-glass, or keeping a copy of the AWS origin address in GCS or in the tfvars. Tell me if you want me to wire up either one.
- **Cost.** Cloudflare Load Balancing is a paid add-on, starting around US$5 a month.