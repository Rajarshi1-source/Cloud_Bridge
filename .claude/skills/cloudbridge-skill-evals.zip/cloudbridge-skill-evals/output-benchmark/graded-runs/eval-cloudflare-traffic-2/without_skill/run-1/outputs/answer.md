The working directory is empty, so I had no existing setup to match. I made these assumptions; tell me if any are wrong:

- **Traffic layer:** Cloudflare Load Balancing. I chose it because it can run health checks from India. Route 53 and GCP uptime checks can't (their closest checker regions are Singapore and "Asia Pacific").
- **The split:** AWS gets 70% and GCP gets 30%. It's driven by one variable, `gcp_weight_percent`.
- **"Nobody can set GCP to 3%":** I read this as a guard against typos like 3 for 30 or 0.3 for 30. The weight must be a whole number and either `0` (fully drained) or 10–100 in steps of 5. Anything else fails at `terraform plan`.

I couldn't run `terraform validate` here (no shell or write tools), so the code is untested. It's written against Cloudflare provider v5.

### `versions.tf`
```hcl
terraform {
  required_version = ">= 1.5"
  required_providers {
    cloudflare = {
      source  = "cloudflare/cloudflare"
      version = "~> 5.0"
    }
  }
}

provider "cloudflare" {} # reads CLOUDFLARE_API_TOKEN
```

### `variables.tf`
```hcl
variable "account_id" { type = string }
variable "zone_id"    { type = string }

variable "hostname" {
  type        = string
  description = "Public hostname served by the load balancer, e.g. app.example.com"
}

variable "aws_origin" {
  type        = string
  description = "AWS entry point (ALB/NLB DNS name or IP)"
}

variable "gcp_origin" {
  type        = string
  description = "GCP entry point (global LB IP or hostname)"
}

variable "health_path" {
  type    = string
  default = "/healthz"
}

variable "gcp_weight_percent" {
  type        = number
  default     = 30
  description = "Share of traffic sent to GCP, in whole percent. AWS gets the remainder."

  validation {
    condition     = floor(var.gcp_weight_percent) == var.gcp_weight_percent
    error_message = "gcp_weight_percent must be a whole percent (30, not 0.3)."
  }

  # Typo guard: 3 (meant 30), 7 (meant 70) and similar values are rejected.
  # 0 drains GCP on purpose; otherwise use a deliberate step of 5 between 10 and 100.
  validation {
    condition = var.gcp_weight_percent == 0 || (
      var.gcp_weight_percent >= 10 &&
      var.gcp_weight_percent <= 100 &&
      var.gcp_weight_percent % 5 == 0
    )
    error_message = "gcp_weight_percent must be 0 or 10-100 in steps of 5. Got ${var.gcp_weight_percent}; did you mean ${var.gcp_weight_percent * 10}?"
  }
}
```

### `main.tf`
```hcl
locals {
  gcp_weight = var.gcp_weight_percent / 100
  aws_weight = (100 - var.gcp_weight_percent) / 100

  # SAS = Cloudflare's Southern Asia check region (India).
  check_regions = ["SAS"]
}

resource "cloudflare_load_balancer_monitor" "app" {
  account_id       = var.account_id
  description      = "${var.hostname} health"
  type             = "https"
  method           = "GET"
  path             = var.health_path
  port             = 443
  expected_codes   = "200"
  interval         = 60
  timeout          = 5
  retries          = 2
  follow_redirects = false
  allow_insecure   = false
  header = {
    Host = [var.hostname]
  }
}

resource "cloudflare_load_balancer_pool" "aws" {
  account_id      = var.account_id
  name            = "aws-primary"
  enabled         = true
  minimum_origins = 1
  monitor         = cloudflare_load_balancer_monitor.app.id
  check_regions   = local.check_regions
  origins = [{
    name    = "aws"
    address = var.aws_origin
    enabled = true
    weight  = 1
  }]
}

resource "cloudflare_load_balancer_pool" "gcp" {
  account_id      = var.account_id
  name            = "gcp-secondary"
  enabled         = true
  minimum_origins = 1
  monitor         = cloudflare_load_balancer_monitor.app.id
  check_regions   = local.check_regions
  origins = [{
    name    = "gcp"
    address = var.gcp_origin
    enabled = true
    weight  = 1
  }]
}

resource "cloudflare_load_balancer" "app" {
  zone_id          = var.zone_id
  name             = var.hostname
  proxied          = true
  steering_policy  = "random"
  session_affinity = "none"

  default_pools = [
    cloudflare_load_balancer_pool.aws.id,
    cloudflare_load_balancer_pool.gcp.id,
  ]
  fallback_pool = cloudflare_load_balancer_pool.aws.id

  random_steering = {
    default_weight = 0
    pool_weights = {
      (cloudflare_load_balancer_pool.aws.id) = local.aws_weight
      (cloudflare_load_balancer_pool.gcp.id) = local.gcp_weight
    }
  }

  lifecycle {
    # Backstop in case someone edits the locals instead of the variable.
    precondition {
      condition     = abs(local.aws_weight + local.gcp_weight - 1) < 0.0001
      error_message = "Pool weights must sum to 1."
    }
    precondition {
      condition     = local.gcp_weight == 0 || local.gcp_weight >= 0.10
      error_message = "GCP weight ${local.gcp_weight} is below the 10% floor."
    }
  }
}
```

### `outputs.tf` and `terraform.tfvars.example`
```hcl
output "split" {
  value = "aws=${100 - var.gcp_weight_percent}% gcp=${var.gcp_weight_percent}%"
}
```
```hcl
account_id         = "..."
zone_id            = "..."
hostname           = "app.example.com"
aws_origin         = "my-alb-123.us-east-1.elb.amazonaws.com"
gcp_origin         = "34.120.0.1"
gcp_weight_percent = 30
```

### Things to know before applying
1. **The guard only covers Terraform.** Someone could still set 3% in the Cloudflare dashboard or through the API. To catch that, run `terraform plan -detailed-exitcode` on a schedule in CI so any manual change shows up as drift. To prevent it outright, limit who has Load Balancing edit rights.
2. **India's health checks decide for everyone.** Cloudflare marks a pool healthy or unhealthy everywhere, not per region. If the network path from India to one cloud breaks, all users worldwide lose that pool. If you want India as one region among several, use `["SAS", "WEU", "ENAM"]`.
3. **Your Cloudflare plan matters.** It needs the Load Balancing add-on, and the plan sets the shortest allowed check interval (60s works on all plans).
4. **Failover is automatic.** If a pool fails its checks, its share of traffic moves to the healthy pool, and AWS is the fallback if both fail.

If you meant a different setup, like Route 53, NS1, or GCP on the 70% side, tell me and I'll switch it.