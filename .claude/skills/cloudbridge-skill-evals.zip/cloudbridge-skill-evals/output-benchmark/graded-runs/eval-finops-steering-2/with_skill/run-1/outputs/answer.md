Say you don't know yet, then explain how you'll find out. Interviewers trust that answer more than a number you haven't measured.

**What to say (about 30 seconds):**

> "Honestly, I don't know yet, and I've built the system so it won't pretend to know. I have less than a month of billing data. My recommender needs at least 21 days of history and fits over 28 days, so right now it would say 'not enough data.' Here's how I'll answer it.
>
> I compare **cost per 1,000 requests**, not total bills. AWS carries 70% of the traffic, so its total will be higher whatever the prices are. Totals measure the traffic split. Cost per request measures the cloud.
>
> The comparison is set up to be fair. Both clouds get the same machine sizes, the same region (Mumbai), the same date range and real usage charges only, with free credits left out. Both exports use the FOCUS standard format, so the line items match up."

**If they push: "But what do you *expect*?"**

You can say where the costs will differ. Don't name a winner:
- AWS charges a monthly fee for the EKS control plane. GCP gives a management credit that covers one zonal GKE cluster.
- NAT gateway data-processing charges.
- Load balancer hourly fees plus capacity-unit charges.
- Data transfer out to Cloudflare.

> "Those are the line items I'm watching. Which ones dominate depends on traffic, so I'll wait for the ledger."

**If they ask what happens once you have data:**

> "Each cloud has a fixed cost per day plus a cost per request. I fit that separately for each cloud. The recommender only proposes a weight change if the difference in per-request cost is statistically significant (more than two standard errors). Early on, the right answer will usually be 'not significant.' Even when it does act, it only opens a pull request. It never shifts traffic itself, and a human merges it. It's also limited by capacity headroom, a latency limit, a 10% minimum per cloud, and at most a 20-point change per week."

**One thing not to do:** don't quote partial numbers like "GCP looks about 20% cheaper so far." That's the exact mistake your first version made. It compared unequal totals on mismatched machine sizes. If they ask for your current figures, give the per-1k-request cost with its date range and say plainly that the difference isn't significant yet.