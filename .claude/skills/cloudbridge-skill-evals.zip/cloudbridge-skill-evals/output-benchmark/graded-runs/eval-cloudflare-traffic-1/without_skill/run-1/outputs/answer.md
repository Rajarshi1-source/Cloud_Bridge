**You set the weights at the wrong level.** Origin weights only split traffic between origins inside the same pool. Your AWS pool and GCP pool each have one origin, so each origin always gets 100% of its pool's traffic and the 0.7/0.3 values change nothing.

With `steering_policy = "random"`, the load balancer picks a **pool**. Pool weights go in a `random_steering` block on the load balancer. You don't have one, so both pools get the default weight of 1, which gives you 50/50.

### Fix: add pool weights to the load balancer

Cloudflare provider v4 syntax:

```hcl
resource "cloudflare_load_balancer" "lb" {
  # ...
  steering_policy = "random"
  default_pool_ids = [cloudflare_load_balancer_pool.aws.id, cloudflare_load_balancer_pool.gcp.id]
  fallback_pool_id = cloudflare_load_balancer_pool.gcp.id

  random_steering {
    default_weight = 0.5
    pool_weights = {
      (cloudflare_load_balancer_pool.aws.id) = 0.7
      (cloudflare_load_balancer_pool.gcp.id) = 0.3
    }
  }
}
```

In provider v5, `random_steering` is an attribute rather than a block, so you write `random_steering = { default_weight = 0.5, pool_weights = { ... } }`. The parentheses around the map keys are required so Terraform reads them as expressions instead of literal strings.

You can now remove the origin `weight` values, or leave them; they have no effect on single-origin pools.

### Other option
Put both origins in **one** pool with `weight = 0.7` and `0.3`, using the default random origin steering. That also gives you 70/30, but you lose failover and health checks per cloud at the pool level. Keeping two pools with `random_steering` is usually better.

### Other things that can skew the split
- **Session affinity:** with `session_affinity = "cookie"` or `"ip_cookie"`, a few heavy clients can stay on one pool and pull the ratio off target.
- **Health:** if a pool goes unhealthy, its share moves to the other pool.
- **Low traffic:** with only a few hundred requests, random selection can drift noticeably from 70/30.