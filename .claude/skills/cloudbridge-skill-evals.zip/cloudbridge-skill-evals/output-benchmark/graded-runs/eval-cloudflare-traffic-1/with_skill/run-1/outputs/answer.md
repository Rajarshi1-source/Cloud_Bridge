Your weights are on the wrong level. In Cloudflare, an origin `weight` only splits traffic between origins inside the same pool. Each of your pools has a single origin, so there's nothing for that weight to divide: AWS gets 100% of the AWS pool and GCP gets 100% of the GCP pool. That leaves `steering_policy = "random"` with no pool weights, so it picks between the two pools evenly, which is the 50/50 you're seeing.

**Fix:** put the weights on the pools with `random_steering.pool_weights`, and leave the origin weights at their default.

```hcl
# infra/live/global/30-traffic/terraform.tfvars.json
# { "weights": { "aws": 70, "gcp": 30 } }

resource "cloudflare_load_balancer" "app" {
  # ...
  steering_policy = "random"
  default_pools   = [cloudflare_load_balancer_pool.cell["aws"].id,
                     cloudflare_load_balancer_pool.cell["gcp"].id]
  fallback_pool   = cloudflare_load_balancer_pool.cell["gcp"].id

  random_steering = {
    pool_weights = {
      for k, pct in var.weights :
      cloudflare_load_balancer_pool.cell[k].id => pct / 100
    }
    default_weight = 0
  }

  session_affinity = "cookie"
  session_affinity_attributes = {
    zero_downtime_failover = "sticky"
    drain_duration         = 60
  }
}
```

Pool weights are fractions from 0 to 1, so `pct / 100` turns 70 and 30 into 0.7 and 0.3. Keep the percentages only in `terraform.tfvars.json`. They must add up to 100, and each cell must be either 0 (drained) or at least 10. Below 10%, a cell runs with cold caches and scaled-in nodes, so it breaks when real traffic arrives. After the change, `terraform plan` should show only `random_steering` changing, apart from removing the origin weights.

**Checking the result:** once it's applied, use the "configured vs observed" dashboard panel. It compares the latest weights recorded in `traffic_changes` with the split Cloudflare actually sends to each pool (`cb:split:observed`, built from `cb_cf_pool_requests_total{pool=...}`). It should settle near 70/30. A few points of drift is normal at low traffic, because random steering plus cookie affinity pins each session to the cell where it started. If it stays at 50/50, the weights still aren't reaching `pool_weights`.

**Session affinity:** keep it on. Each cell has its own database, so without it a user could place an order on AWS and then not find it after a refresh lands them on GCP.

I couldn't find the traffic stack in this working directory, so this is based on the snippet you pasted. If you point me at the repo, I can make the edit there.