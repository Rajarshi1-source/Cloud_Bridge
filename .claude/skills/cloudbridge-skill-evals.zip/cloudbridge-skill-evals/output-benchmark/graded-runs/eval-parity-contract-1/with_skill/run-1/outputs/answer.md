Argo's "Synced" only tells you that each cluster matches Git. It doesn't tell you the AWS cell matches the GCP cell. Both can show green while they differ, because:

- **Per-cell values are allowed to differ in Git.** If the AWS values file pins a different image digest, HPA max or config value than the GCP one, both cells are still "synced".
- **Some things aren't in Git at all.** That includes the managed Kubernetes patch version (GKE upgrades it on its own), RDS or Cloud SQL parameters changed in the console, the Postgres and Valkey major versions, and how far Flyway migrations have run in each database.
- **Terraform drift detection has the same gap.** It compares one stack to its own code, never one cloud to the other.

So you need a check that compares the two cells directly. In CloudBridge that's the parity contract.

## What to run

```bash
parity check --env prod      # or --env budget
```

It reads live facts from both cells: Terraform outputs, the Kubernetes API through a read-only account, the cloud database APIs, and `flyway_schema_history`. It compares them check by check, each with a weight for how much a mismatch would hurt a failover:

| Weight | What it compares |
|---|---|
| 5 | image digests, Flyway schema version |
| 4 | rendered config hash (per-cell keys like `CB_CELL`, `CLOUD`, `*_MIRROR` and `SECRET_STORE` removed first) |
| 3 | Kubernetes minor version, chart versions, HPA **max** replicas, Postgres major version |
| 2 | resource requests, NetworkPolicy count, Postgres parameter allowlist, Valkey major version, shape class |

**How to read the result:**
- **Pass means a score of exactly 1.0.** Anything lower comes with a list of the specific checks that differ.
- **A check it can't read is reported as "unknown", never as a match.** If the checker can't see something (missing permissions, an API timeout), it doesn't quietly pass. Treat "unknown" as "you don't know yet", not "same".
- **Some known differences are excused, but only for a limited time.** Each excuse in `parity/exceptions.yaml` has an owner and an expiry. Two common ones are "GKE moved the patch version" (allowed only while the minor versions still match) and "canary in progress" (image digests may differ for up to 120 minutes). An expired excuse counts as a divergence again.

## Where else it runs, so you don't have to run it by hand
- After every Argo CD sync of either cell, as a commit status on the release PR.
- Nightly at 03:00 IST for `prod` and `budget`, opening an issue and posting to Slack on failure.
- On infra PRs, as a warning when a change touches only one cloud.

The checker only reports and never changes a cell. Fixing a divergence is a normal Terraform, Argo or Ansible PR.

I couldn't find a `parity/` directory here, so I haven't run it and can't tell you whether your cells match right now. If the parity setup isn't in your repo yet, I can create the contract, the exceptions file, the checker with its AWS, GCP and k3s readers, and the nightly workflow. Or point me at the repo and I'll run the check against your current cells.