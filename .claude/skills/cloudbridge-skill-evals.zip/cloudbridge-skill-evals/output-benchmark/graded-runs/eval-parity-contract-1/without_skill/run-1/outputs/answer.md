**"Synced" doesn't tell you the two cells match.** Argo checks each Application against its own source: "the live objects I manage match what I rendered for this app, at this revision, after my ignore rules." It never compares the AWS cell to the GCP cell. Both can show green and still differ.

## How two "Synced" cells can still differ

1. **Different commits.** Each app may track a branch or `HEAD` that resolved to a different commit, or the two apps point at different tags.
2. **Different rendered input.** Per-cell values files, Kustomize overlays and ApplicationSet generator parameters all change what gets rendered. Some of that is on purpose, but drift hides there too.
3. **Same tag, different image.** A tag like `:latest` or `:v1.2` can point to a different image in each cell. The manifests match, but the running code doesn't.
4. **`ignoreDifferences` and normalization.** Anything those rules ignore is invisible to Argo, as are fields changed by webhooks, Horizontal Pod Autoscalers (HPAs) and other controllers.
5. **Rollout not finished.** "Synced" is not "Healthy." The new ReplicaSet can exist while the old pods are still serving traffic.
6. **Resources Argo doesn't manage.** Things applied by hand with `kubectl`, objects created by operators, and different versions of Custom Resource Definitions (CRDs) or operators.
7. **Stale status.** Argo caches rendered manifests and refreshes on a timer, so the status can be out of date.
8. **Things outside Kubernetes.** Secret values (an External Secret can be "synced" while AWS Secrets Manager and GCP Secret Manager hold different values), Identity and Access Management (IAM) settings, managed databases, DNS, and Kubernetes or node versions.

## How to check (strongest checks first)

```bash
APP_A=myapp-aws APP_B=myapp-gcp
CTX_A=aws-cell  CTX_B=gcp-cell

# 0. Force a fresh render so you're not reading a cached status
argocd app get $APP_A --hard-refresh >/dev/null
argocd app get $APP_B --hard-refresh >/dev/null

# 1. Same commit? (use .status.sync.revisions if an app has multiple sources)
for a in $APP_A $APP_B; do
  argocd app get $a -o json | jq -r '"\(.metadata.name) \(.status.sync.revision) \(.status.sync.status)/\(.status.health.status)"'
done

# 2. Same desired state? Every line of this diff should be a difference you meant to have
argocd app manifests $APP_A --source git > a-desired.yaml
argocd app manifests $APP_B --source git > b-desired.yaml
diff <(yq -P 'sort_keys(..)' a-desired.yaml) <(yq -P 'sort_keys(..)' b-desired.yaml)

# 3. Same code actually running? Compare image digests, not tags
for ctx in $CTX_A $CTX_B; do
  kubectl --context $ctx get pods -A -o json | jq -r '
    .items[] | .metadata.namespace as $ns | .status.containerStatuses[]? |
    "\($ns) \(.name) \(.imageID)"' | sort -u > digests-$ctx.txt
done
diff digests-$CTX_A.txt digests-$CTX_B.txt

# 4. What is Argo set to ignore?
for a in $APP_A $APP_B; do argocd app get $a -o json | jq '.spec.ignoreDifferences'; done
```

Also check:
- **Orphaned resources.** Turn on `orphanedResources` monitoring in the AppProject, then run `argocd app resources $APP --orphaned` to list objects in the namespace that Argo doesn't manage.
- **Platform versions.** Run `kubectl version` against each context and compare the CRD and operator versions too.
- **Secrets.** Compare a hash of each secret's value in both clouds, never the plaintext.
- **Infrastructure.** Run `terraform plan` (or whatever manages your infrastructure) in each cell and confirm it shows no changes.

## Making it stay true

- **Pin images by digest** (`image@sha256:…`). This removes the most common silent difference.
- **Point both apps at the same immutable revision**, such as a tag or a commit SHA, not a branch.
- **Keep per-cell differences in one small overlay**, and run checks 1–3 as a scheduled CI job. Have the job fail on any difference that isn't in an allowlist of expected ones. Then "the cells match" becomes something you've tested.

If you tell me how your apps are set up (one ApplicationSet with a cluster generator, or two separate Applications, and Helm or Kustomize), I can turn this into a drift-check script for your setup.