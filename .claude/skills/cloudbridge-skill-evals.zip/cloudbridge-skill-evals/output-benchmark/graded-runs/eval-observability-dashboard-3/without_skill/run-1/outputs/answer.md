I couldn't create any files. The working directory is empty and this session has no tool for writing files or running a shell. So the code below hasn't been run or type-checked, and you'll need to paste it into the repo yourself. I followed the CloudBridge observability skill's conventions (control-plane API, `traffic_changes`, `cb_cf_pool_requests_5m`, Next.js Server Components, IST timestamps).

**What the page answers:** the split can break at four points, and the page checks each one.

1. **Git:** the weights in `terraform.tfvars.json`.
2. **Applied:** the latest `traffic_changes` row.
3. **Cloudflare:** how many requests each pool actually got.
4. **Origins:** the api-gateway request rate in each cell.

The answer at the top uses the last hour, and falls back to the last 5 minutes if the weights changed during that hour.

**How I decide whether 70/30 is "on target":**
- **Tolerance:** the larger of 2 points or a 99% interval. That interval treats requests as less independent than they look, by a factor of 4 (`CB_SPLIT_DESIGN_EFFECT`). Cookie affinity routes whole sessions rather than single requests, and Cloudflare's analytics are sampled.
- **Low traffic:** below 1,000 requests the page says "too little traffic to tell" rather than guessing.
- **After a weight change:** affinity cookies last 23 h, so the split shifts slowly. If the observed share is between the old and new weights, the page says "converging" instead of "off target".
- **About 50/50 when the target isn't:** the page says "looks unweighted" and points at weights set on origins instead of pools.

**Two bugs in the existing cf-exporter make it give wrong answers. Please apply this patch too:**
- **Drained pools keep their old count.** The exporter only updates pools Cloudflare returned. When you drain AWS, its last count stays in Prometheus forever, so the dashboard would show traffic reaching a drained cell.
- **Failed pulls look current.** When a pull fails, the old numbers keep being served as if they were new. The patch adds a last-success timestamp so the page can say how old the Cloudflare numbers are.

```python
# control-plane/cf-exporter/exporter.py — changes only
KNOWN_POOLS = set(os.environ.get("CB_POOLS", "cb-aws-prod,cb-gcp-prod").split(","))
LAST_OK = Gauge("cb_cf_exporter_last_success_timestamp_seconds", "Unix time of the last successful Cloudflare analytics pull")

# end of scrape(): a pool with no requests is absent from the response, so zero it instead of keeping its old value
    for pool in KNOWN_POOLS | seen.keys():
        POOL_REQS.labels(pool=pool).set(seen.get(pool, 0))

# main loop
        try:
            scrape()
            LAST_OK.set_to_current_time()
```

### `control-plane/api/overview.py`

```python
# control-plane/api/overview.py — GET /overview: is the split we configured the split users actually get?
#
# Four layers, each of which can disagree with the next:
#   intended   terraform.tfvars.json in Git
#   applied    latest traffic_changes row (posted after a successful apply, or by break-glass)
#   delivered  Cloudflare per-pool request counts (cf-exporter → cb_cf_pool_requests_5m)
#   received   api-gateway request rate per cell (origins only accept Cloudflare, so this should match)
from __future__ import annotations

import json
import math
import os
import pathlib
import time
from datetime import datetime, timezone
from typing import Any

import httpx
import psycopg
from fastapi import APIRouter

router = APIRouter()
DSN = os.environ["DATABASE_URL"]
PROM = os.environ["CB_PROM_URL"]
REPO = pathlib.Path(os.environ.get("CB_REPO_DIR", "/repo"))
ENV = os.environ.get("CB_ENV", "prod")
TFVARS = REPO / "infra/live/global/30-traffic/terraform.tfvars.json"
CELLS = {"aws": f"cb-aws-{ENV}", "gcp": f"cb-gcp-{ENV}"}      # cell id == Cloudflare pool name
CELL_RE = f"cb-(aws|gcp)-{ENV}"

WINDOWS = (("5m", 300), ("1h", 3600), ("24h", 86400))
MIN_REQUESTS = int(os.environ.get("CB_SPLIT_MIN_REQUESTS", "1000"))
FLOOR_PTS = 2.0            # random steering never lands exactly on the weight
# Cookie affinity steers sessions, not requests, and Cloudflare's adaptive datasets are sampled,
# so requests are not independent draws. Inflate the binomial variance rather than pretend they are.
DESIGN_EFFECT = float(os.environ.get("CB_SPLIT_DESIGN_EFFECT", "4"))
Z99 = 2.576
AFFINITY_TTL_S = int(os.environ.get("CB_AFFINITY_TTL_S", "82800"))   # session_affinity_ttl in 30-traffic
EXPORTER_STALE_S = 600


def _num(v: str) -> float | None:
    f = float(v)
    return None if math.isnan(f) or math.isinf(f) else f


def _prom(expr: str, errors: list[str]) -> list[dict] | None:
    try:
        r = httpx.get(f"{PROM}/api/v1/query", params={"query": expr}, timeout=10)
        r.raise_for_status()
        return r.json()["data"]["result"]
    except (httpx.HTTPError, KeyError, ValueError) as e:
        errors.append(f"prometheus query failed ({expr[:60]}…): {e}")
        return None


def _as_split(w: dict) -> dict[str, int]:
    return {"aws": int(w.get("aws", 0)), "gcp": int(w.get("gcp", 0))}


def _intended(errors: list[str]) -> dict[str, int] | None:
    try:
        return _as_split(json.loads(TFVARS.read_text())["weights"])
    except (OSError, ValueError, KeyError) as e:
        errors.append(f"could not read {TFVARS.name}: {e}")
        return None


def _changes(errors: list[str]) -> list[dict]:
    """Changes in the last 24 h plus the one that was in effect when the window opened."""
    try:
        with psycopg.connect(DSN, autocommit=True) as conn:
            rows = conn.execute("""
                SELECT weights, source, pr_url, applied_at FROM traffic_changes
                WHERE applied_at >= now() - interval '24 hours'
                   OR id = (SELECT id FROM traffic_changes
                            WHERE applied_at < now() - interval '24 hours'
                            ORDER BY applied_at DESC LIMIT 1)
                ORDER BY applied_at""").fetchall()
    except psycopg.Error as e:
        errors.append(f"control-plane db: {e}")
        return []
    return [{"weights": _as_split(w), "source": s, "prUrl": pr, "appliedAt": at} for w, s, pr, at in rows]


def _observed(window: str, seconds: int, errors: list[str]) -> tuple[dict[str, float] | None, float | None]:
    # The gauge holds a rolling 5-minute count, refreshed every minute: its average over W × (W / 5m) ≈ requests in W.
    sel = f'cb_cf_pool_requests_5m{{pool=~"{CELL_RE}"}}'
    rows = _prom(sel if seconds == 300 else f"avg_over_time({sel}[{window}])", errors)
    if not rows:
        return None, None
    counts = {"aws": 0.0, "gcp": 0.0}
    for r in rows:
        v = _num(r["value"][1])
        if v is not None:
            counts[r["metric"]["pool"].split("-")[1]] += v * seconds / 300
    n = sum(counts.values())
    if n == 0:
        return None, 0.0
    return {k: 100 * c / n for k, c in counts.items()}, n


def _judge(expected: int | None, previous: int | None, observed: dict | None, n: float | None,
           window_s: int, change_age_s: float | None, stale: bool) -> dict[str, Any]:
    out: dict[str, Any] = {"expectedAws": expected, "diffPts": None, "tolerancePts": None}
    if expected is None or observed is None or n is None:
        return out | {"state": "no_data"}
    if stale:
        return out | {"state": "stale"}
    if change_age_s is not None and change_age_s < window_s:
        return out | {"state": "mixed"}
    if n < MIN_REQUESTS:
        return out | {"state": "too_little_traffic"}
    p = expected / 100
    tol = max(FLOOR_PTS, Z99 * 100 * math.sqrt(DESIGN_EFFECT * p * (1 - p) / n))
    diff = observed["aws"] - expected
    out |= {"diffPts": round(diff, 2), "tolerancePts": round(tol, 2)}
    if abs(diff) <= tol:
        state = "on_target"
    elif (change_age_s is not None and change_age_s < AFFINITY_TTL_S and previous is not None
          and min(previous, expected) - tol <= observed["aws"] <= max(previous, expected) + tol):
        state = "converging"          # sticky sessions still on their old home cell
    elif expected != 50 and abs(observed["aws"] - 50) <= tol:
        state = "looks_unweighted"    # classic symptom of weights on origins instead of pools
    else:
        state = "off_target"
    return out | {"state": state}


def _history(start: int, end: int, errors: list[str]) -> list[list]:
    expr = (f'100 * (sum(cb_cf_pool_requests_5m{{pool="{CELLS["aws"]}"}}) or vector(0))'
            f' / sum(cb_cf_pool_requests_5m{{pool=~"{CELL_RE}"}})')
    try:
        r = httpx.get(f"{PROM}/api/v1/query_range",
                      params={"query": expr, "start": start, "end": end, "step": 300}, timeout=15)
        r.raise_for_status()
        rows = r.json()["data"]["result"]
    except (httpx.HTTPError, KeyError, ValueError) as e:
        errors.append(f"prometheus range query failed: {e}")
        rows = []
    got = {int(float(t)): _num(v) for t, v in rows[0]["values"]} if rows else {}
    return [[t, got.get(t)] for t in range(start, end + 1, 300)]


def _cells(errors: list[str]) -> list[dict[str, Any]]:
    cells = {c: {"cell": c, "cloud": cloud, "availability": None, "p95Ms": None, "rps": None}
             for cloud, c in CELLS.items()}
    exprs = {
        "availability": f'cb:availability:ratio_rate1h{{cb_cell=~"{CELL_RE}"}}',
        "p95Ms": f'1000 * cb:latency_p95:5m{{cb_cell=~"{CELL_RE}",service="api-gateway"}}',
        "rps": f'cb:requests:rate5m{{cb_cell=~"{CELL_RE}",service="api-gateway"}}',
    }
    for key, expr in exprs.items():
        for r in _prom(expr, errors) or []:
            if (c := r["metric"].get("cb_cell")) in cells:
                cells[c][key] = _num(r["value"][1])
    return list(cells.values())


def _iso(ts: float | None) -> str | None:
    return None if ts is None else datetime.fromtimestamp(ts, timezone.utc).isoformat()


@router.get("/overview")
def overview() -> dict[str, Any]:
    errors: list[str] = []
    now = time.time()
    intended = _intended(errors)
    changes = _changes(errors)
    applied = changes[-1] if changes else None
    previous = changes[-2] if len(changes) > 1 else None
    expected = (applied["weights"] if applied else intended or {}).get("aws")
    change_age = now - applied["appliedAt"].timestamp() if applied else None

    ok = _prom("max(cb_cf_exporter_last_success_timestamp_seconds)", errors)
    last_ok = _num(ok[0]["value"][1]) if ok else None

    windows = []
    for label, seconds in WINDOWS:
        observed, n = _observed(label, seconds, errors)
        stale = seconds == 300 and last_ok is not None and now - last_ok > EXPORTER_STALE_S
        windows.append({"window": label, "observed": observed, "requests": n}
                       | _judge(expected, previous["weights"]["aws"] if previous else None,
                                observed, n, seconds, change_age, stale))

    cells = _cells(errors)
    rps = {c["cloud"]: c["rps"] for c in cells}
    origin_share = None
    if None not in rps.values() and (total := sum(rps.values())) > 0:
        origin_share = {k: 100 * v / total for k, v in rps.items()}

    end = int(now) // 300 * 300
    start = end - 86400
    return {
        "asOf": _iso(now),
        "env": ENV,
        "intended": intended,
        "applied": applied and {**applied, "appliedAt": applied["appliedAt"].isoformat()},
        "expectedFrom": "applied" if applied else ("git" if intended else None),
        "exporterLastSuccess": _iso(last_ok),
        "minRequests": MIN_REQUESTS,
        "affinityTtlS": AFFINITY_TTL_S,
        "windows": windows,
        "originShare": origin_share,
        "history": {
            "start": start,
            "end": end,
            "observedAws": _history(start, end, errors),
            "configured": [{"at": max(int(c["appliedAt"].timestamp()), start), "aws": c["weights"]["aws"],
                            "source": c["source"]} for c in changes],
        },
        "cells": cells,
        "errors": errors,
    }
```

Add to `control-plane/api/main.py`, so the existing bearer check applies:

```python
import overview
app.include_router(overview.router, dependencies=[Depends(auth)])
```

### `control-plane/dashboard/lib/overview.ts`

```ts
export type Cloud = "aws" | "gcp";
export type Split = Record<Cloud, number>;
export type SplitState =
  | "on_target" | "off_target" | "looks_unweighted" | "converging"
  | "mixed" | "stale" | "too_little_traffic" | "no_data";

export type WindowCheck = {
  window: "5m" | "1h" | "24h";
  observed: Split | null;
  requests: number | null;
  expectedAws: number | null;
  state: SplitState;
  diffPts: number | null;
  tolerancePts: number | null;
};

export type TrafficChange = { weights: Split; source: string; prUrl: string | null; appliedAt: string };
export type CellSignals = { cell: string; cloud: Cloud; availability: number | null; p95Ms: number | null; rps: number | null };

export type Overview = {
  asOf: string;
  env: string;
  intended: Split | null;
  applied: TrafficChange | null;
  expectedFrom: "applied" | "git" | null;
  exporterLastSuccess: string | null;
  minRequests: number;
  affinityTtlS: number;
  windows: WindowCheck[];
  originShare: Split | null;
  history: {
    start: number;
    end: number;
    observedAws: [number, number | null][];
    configured: { at: number; aws: number; source: string }[];
  };
  cells: CellSignals[];
  errors: string[];
};

export async function getOverview(): Promise<Overview> {
  const res = await fetch(`${process.env.CP_API_URL}/overview`, {
    cache: "no-store",
    headers: { Authorization: `Bearer ${process.env.CB_CP_TOKEN}` },
  });
  if (!res.ok) throw new Error(`control plane ${res.status}`);
  return res.json();
}
```

### `control-plane/dashboard/app/page.tsx`

```tsx
import { SplitChart } from "@/components/split-chart";
import { getOverview, type Overview, type Split, type SplitState, type WindowCheck } from "@/lib/overview";

type Tone = "good" | "warning" | "critical" | "neutral";

const STATE: Record<SplitState, { tone: Tone; label: string }> = {
  on_target: { tone: "good", label: "Matches configured split" },
  off_target: { tone: "critical", label: "Off target" },
  looks_unweighted: { tone: "critical", label: "Looks unweighted (≈50/50)" },
  converging: { tone: "warning", label: "Converging after a change" },
  mixed: { tone: "neutral", label: "Window spans a weight change" },
  stale: { tone: "warning", label: "Cloudflare counts are stale" },
  too_little_traffic: { tone: "neutral", label: "Too little traffic to tell" },
  no_data: { tone: "neutral", label: "No measurement yet" },
};
const TONE: Record<Tone, string> = {
  good: "text-emerald-700 dark:text-emerald-400",
  warning: "text-amber-700 dark:text-amber-400",
  critical: "text-destructive",
  neutral: "text-muted-foreground",
};
const ICON: Record<Tone, string> = { good: "✓", warning: "!", critical: "✕", neutral: "–" };

const fmtInt = (n: number) => Math.round(n).toLocaleString("en-IN");
const fmtSplit = (s: Split, digits: number) => `AWS ${s.aws.toFixed(digits)}% · GCP ${s.gcp.toFixed(digits)}%`;
const fmtTime = (iso: string) =>
  `${new Date(iso).toLocaleString("en-IN", { timeZone: "Asia/Kolkata", dateStyle: "medium", timeStyle: "short" })} IST`;

function ago(iso: string, now: number): string {
  const s = Math.max(0, (now - Date.parse(iso)) / 1000);
  if (s < 90) return `${Math.round(s)} s`;
  if (s < 5400) return `${Math.round(s / 60)} min`;
  if (s < 172800) return `${(s / 3600).toFixed(1)} h`;
  return `${Math.round(s / 86400)} d`;
}

function headline(w: WindowCheck, o: Overview, now: number): string {
  const exp = w.expectedAws ?? 0;
  const obs = w.observed?.aws.toFixed(1);
  switch (w.state) {
    case "on_target":
      return `Yes. AWS took ${obs}% of ≈${fmtInt(w.requests!)} requests in the last ${w.window}, within ±${w.tolerancePts!.toFixed(1)} pts of the configured ${exp}%.`;
    case "off_target":
      return `No. AWS took ${obs}% in the last ${w.window}, ${Math.abs(w.diffPts!).toFixed(1)} pts ${w.diffPts! > 0 ? "above" : "below"} the configured ${exp}% (tolerance ±${w.tolerancePts!.toFixed(1)}).`;
    case "looks_unweighted":
      return `No. Traffic is landing about 50/50 (${obs}% AWS) instead of ${exp}/${100 - exp}. The weights are probably set on origins rather than pools.`;
    case "converging":
      return `Not yet. AWS is at ${obs}% against ${exp}%. Weights changed ${ago(o.applied!.appliedAt, now)} ago, and affinity cookies keep existing sessions on their home cell for up to ${Math.round(o.affinityTtlS / 3600)} h.`;
    case "mixed":
      return `Can't judge the last ${w.window}: the weights changed inside it.`;
    case "stale":
      return "Can't judge: Cloudflare counts haven't refreshed for over 10 minutes.";
    case "too_little_traffic":
      return `Can't tell yet: only ≈${fmtInt(w.requests ?? 0)} requests in the last ${w.window}; a verdict needs at least ${fmtInt(o.minRequests)}.`;
    case "no_data":
      return w.expectedAws === null
        ? "No configured split found: traffic_changes is empty and Git couldn't be read."
        : "No measurement yet: Cloudflare per-pool counts aren't reaching Prometheus.";
  }
}

function freshness(o: Overview, now: number): string {
  const pulled = o.exporterLastSuccess
    ? `Cloudflare counts pulled ${ago(o.exporterLastSuccess, now)} ago`
    : "cf-exporter doesn't report its last successful pull, so the age of Cloudflare counts is unknown";
  return `${pulled}. Request counts are estimates from Cloudflare's sampled analytics.`;
}

function WindowTile({ w }: { w: WindowCheck }) {
  const s = STATE[w.state];
  return (
    <div className="rounded-md border p-3">
      <div className="flex items-baseline justify-between text-xs text-muted-foreground">
        <span>Last {w.window}</span>
        {w.requests !== null && <span>≈{fmtInt(w.requests)} req</span>}
      </div>
      {w.observed ? (
        <p className="mt-1 text-2xl font-semibold tabular-nums">
          {w.observed.aws.toFixed(1)}% <span className="text-sm font-normal text-muted-foreground">AWS</span>
        </p>
      ) : (
        <p className="mt-1 text-sm text-muted-foreground">No measurement yet</p>
      )}
      <p className={`mt-1 text-xs ${TONE[s.tone]}`}>
        <span aria-hidden>{ICON[s.tone]}</span> {s.label}
        {w.diffPts !== null && w.tolerancePts !== null &&
          ` · ${w.diffPts > 0 ? "+" : ""}${w.diffPts.toFixed(1)} pts (±${w.tolerancePts.toFixed(1)})`}
      </p>
    </div>
  );
}

export default async function Page() {
  const o = await getOverview();
  const now = Date.parse(o.asOf);
  const byWindow = Object.fromEntries(o.windows.map((w) => [w.window, w]));
  const primary: WindowCheck = byWindow["1h"].state === "mixed" ? byWindow["5m"] : byWindow["1h"];
  const exp = primary.expectedAws;
  const verdict = STATE[primary.state];
  const delivered = byWindow["1h"].observed;

  const gitDrift = o.intended && o.applied && o.intended.aws !== o.applied.weights.aws;
  const edgeVsOrigin = delivered && o.originShare ? Math.abs(delivered.aws - o.originShare.aws) : null;

  const layers = [
    { name: "Intended", source: "Git · 30-traffic/terraform.tfvars.json", value: o.intended && fmtSplit(o.intended, 0) },
    {
      name: "Applied",
      source: o.applied ? `traffic_changes · ${o.applied.source} · ${ago(o.applied.appliedAt, now)} ago` : "traffic_changes · nothing recorded",
      value: o.applied && fmtSplit(o.applied.weights, 0),
      href: o.applied?.prUrl ?? undefined,
    },
    { name: "Delivered", source: "Cloudflare requests per pool · last 1h", value: delivered && fmtSplit(delivered, 1) },
    { name: "Received", source: "api-gateway req/s per cell · last 5m", value: o.originShare && fmtSplit(o.originShare, 1) },
  ];

  return (
    <main className="mx-auto max-w-6xl space-y-6 p-4 sm:p-6">
      <header className="flex flex-wrap items-baseline justify-between gap-2">
        <h1 className="text-2xl font-semibold">
          {exp === null ? "Is the configured split happening?" : `Is the ${exp}/${100 - exp} split happening?`}
        </h1>
        <p className="text-sm text-muted-foreground">{o.env} · as of {fmtTime(o.asOf)}</p>
      </header>

      <section className="rounded-lg border p-4 sm:p-6" aria-labelledby="verdict">
        <p id="verdict" className={`text-sm font-medium ${TONE[verdict.tone]}`}>
          <span aria-hidden>{ICON[verdict.tone]}</span> {verdict.label} · last {primary.window}
        </p>
        <p className="mt-2 text-lg sm:text-xl">{headline(primary, o, now)}</p>
        <p className="mt-2 text-xs text-muted-foreground">{freshness(o, now)}</p>
        <div className="mt-4 grid gap-3 sm:grid-cols-3">
          {o.windows.map((w) => <WindowTile key={w.window} w={w} />)}
        </div>
      </section>

      <section className="rounded-lg border p-4" aria-labelledby="layers">
        <h2 id="layers" className="font-medium">Where the split could break</h2>
        <ol className="mt-3 grid gap-3 sm:grid-cols-4">
          {layers.map((l) => (
            <li key={l.name} className="rounded-md border p-3 text-sm">
              <p className="text-xs text-muted-foreground">{l.name}</p>
              <p className="mt-1 font-medium tabular-nums">{l.value ?? "No measurement yet"}</p>
              <p className="mt-1 text-xs text-muted-foreground">
                {l.href ? <a className="underline" href={l.href}>{l.source}</a> : l.source}
              </p>
            </li>
          ))}
        </ol>
        {gitDrift && (
          <p role="alert" className="mt-3 text-sm text-destructive">
            Git and the last applied change disagree: an apply is pending, or a break-glass change hasn't been committed back.
          </p>
        )}
        {edgeVsOrigin !== null && edgeVsOrigin > 5 && (
          <p role="alert" className="mt-3 text-sm text-amber-700 dark:text-amber-400">
            Cloudflare and the origins disagree by {edgeVsOrigin.toFixed(1)} pts. Check that both cells&apos; gateways are reporting metrics.
          </p>
        )}
      </section>

      <section className="rounded-lg border p-4" aria-labelledby="history">
        <h2 id="history" className="font-medium">AWS share, last 24 h</h2>
        <p className="text-xs text-muted-foreground">5-minute Cloudflare samples against the applied weight; short windows are noisy at low traffic.</p>
        <SplitChart {...o.history} />
      </section>

      <section className="grid gap-4 md:grid-cols-2" aria-label="Cells">
        {o.cells.map((c) => (
          <article key={c.cell} className="rounded-lg border p-4">
            <h2 className="font-medium">{c.cell}</h2>
            <dl className="mt-2 grid grid-cols-2 gap-2 text-sm">
              <dt className="text-muted-foreground">Availability (1h)</dt>
              <dd className="tabular-nums">{c.availability === null ? "no measurement yet" : `${(c.availability * 100).toFixed(3)}%`}</dd>
              <dt className="text-muted-foreground">p95 latency (5m)</dt>
              <dd className="tabular-nums">{c.p95Ms === null ? "no measurement yet" : `${Math.round(c.p95Ms)} ms`}</dd>
              <dt className="text-muted-foreground">Gateway req/s (5m)</dt>
              <dd className="tabular-nums">{c.rps === null ? "no measurement yet" : c.rps.toFixed(1)}</dd>
            </dl>
          </article>
        ))}
      </section>

      {o.errors.length > 0 && (
        <section role="alert" className="rounded-lg border border-destructive/40 p-4 text-sm">
          <h2 className="font-medium text-destructive">Some sources didn&apos;t answer</h2>
          <ul className="mt-2 list-disc space-y-1 pl-5 text-muted-foreground">
            {o.errors.map((e) => <li key={e}>{e}</li>)}
          </ul>
        </section>
      )}
    </main>
  );
}
```

### `control-plane/dashboard/components/split-chart.tsx`

```tsx
"use client";

import { useState, type PointerEvent } from "react";

type Point = [number, number | null];
type Change = { at: number; aws: number; source: string };

const W = 720;
const H = 240;
const M = { top: 12, right: 12, bottom: 28, left: 36 };
const PW = W - M.left - M.right;
const PH = H - M.top - M.bottom;
const IST_OFFSET_S = 19800;

const hhmm = (t: number) =>
  new Date(t * 1000).toLocaleTimeString("en-IN", { timeZone: "Asia/Kolkata", hour: "2-digit", minute: "2-digit", hour12: false });

function configuredAt(changes: Change[], t: number): number | null {
  let v: number | null = null;
  for (const c of changes) if (c.at <= t) v = c.aws;
  return v;
}

export function SplitChart({ start, end, observedAws, configured }: {
  start: number; end: number; observedAws: Point[]; configured: Change[];
}) {
  const [hover, setHover] = useState<number | null>(null);
  const seen = observedAws.flatMap(([, v]) => (v === null ? [] : [v]));
  if (seen.length === 0) return <p className="mt-3 text-sm text-muted-foreground">No measurement yet.</p>;

  const all = [...seen, ...configured.map((c) => c.aws)];
  const lo = Math.max(0, Math.floor((Math.min(...all) - 5) / 5) * 5);
  const hi = Math.min(100, Math.ceil((Math.max(...all) + 5) / 5) * 5);
  const x = (t: number) => M.left + ((t - start) / (end - start)) * PW;
  const y = (v: number) => M.top + ((hi - v) / (hi - lo)) * PH;

  const step = hi - lo > 30 ? 10 : 5;
  const yTicks: number[] = [];
  for (let v = lo; v <= hi; v += step) yTicks.push(v);
  const xTicks: number[] = [];
  for (let t = Math.ceil((start + IST_OFFSET_S) / 21600) * 21600 - IST_OFFSET_S; t <= end; t += 21600) xTicks.push(t);

  let observedPath = "";
  let pen = false;
  for (const [t, v] of observedAws) {
    if (v === null) { pen = false; continue; }
    observedPath += `${pen ? "L" : "M"}${x(t).toFixed(1)},${y(v).toFixed(1)}`;
    pen = true;
  }
  let configuredPath = "";
  configured.forEach((c, i) => {
    configuredPath += i === 0 ? `M${x(c.at)},${y(c.aws)}` : `H${x(c.at)}V${y(c.aws)}`;
  });
  if (configured.length) configuredPath += `H${x(end)}`;

  function onMove(e: PointerEvent<SVGSVGElement>) {
    const r = e.currentTarget.getBoundingClientRect();
    const t = start + ((((e.clientX - r.left) / r.width) * W - M.left) / PW) * (end - start);
    let best = 0;
    observedAws.forEach(([pt], i) => {
      if (Math.abs(pt - t) < Math.abs(observedAws[best][0] - t)) best = i;
    });
    setHover(best);
  }

  const hp = hover === null ? null : observedAws[hover];
  const hcfg = hp ? configuredAt(configured, hp[0]) : null;

  return (
    <figure className="mt-3">
      <div className="mb-2 flex flex-wrap gap-4 text-xs text-muted-foreground">
        <span className="flex items-center gap-1.5"><span className="h-0.5 w-4 bg-[#2a78d6] dark:bg-[#3987e5]" />Observed AWS share</span>
        <span className="flex items-center gap-1.5"><span className="w-4 border-t-2 border-dashed border-muted-foreground" />Configured AWS weight</span>
      </div>
      <div className="relative">
        <svg
          viewBox={`0 0 ${W} ${H}`}
          className="w-full touch-none select-none"
          role="img"
          aria-label={`Observed AWS share over the last 24 hours, between ${Math.min(...seen).toFixed(0)}% and ${Math.max(...seen).toFixed(0)}%, against the configured weight.`}
          onPointerMove={onMove}
          onPointerLeave={() => setHover(null)}
        >
          {yTicks.map((v) => (
            <g key={v}>
              <line x1={M.left} x2={W - M.right} y1={y(v)} y2={y(v)} className="stroke-border" strokeWidth={1} />
              <text x={M.left - 6} y={y(v)} dy="0.32em" textAnchor="end" className="fill-muted-foreground text-[11px]">{v}%</text>
            </g>
          ))}
          {xTicks.map((t) => (
            <text key={t} x={x(t)} y={H - 8} textAnchor="middle" className="fill-muted-foreground text-[11px]">{hhmm(t)}</text>
          ))}
          <path d={configuredPath} fill="none" strokeWidth={2} strokeDasharray="4 4" className="stroke-muted-foreground" />
          <path d={observedPath} fill="none" strokeWidth={2} strokeLinejoin="round" className="stroke-[#2a78d6] dark:stroke-[#3987e5]" />
          {hp && (
            <g>
              <line x1={x(hp[0])} x2={x(hp[0])} y1={M.top} y2={H - M.bottom} className="stroke-muted-foreground" strokeWidth={1} />
              {hp[1] !== null && (
                <circle cx={x(hp[0])} cy={y(hp[1])} r={4} strokeWidth={2} className="fill-[#2a78d6] stroke-background dark:fill-[#3987e5]" />
              )}
            </g>
          )}
        </svg>
        {hp && (
          <div
            className="pointer-events-none absolute top-2 whitespace-nowrap rounded-md border bg-popover px-2 py-1 text-xs text-popover-foreground shadow-sm"
            style={{
              left: `${(x(hp[0]) / W) * 100}%`,
              transform: x(hp[0]) > W / 2 ? "translateX(calc(-100% - 8px))" : "translateX(8px)",
            }}
          >
            <div className="text-muted-foreground">{hhmm(hp[0])} IST</div>
            <div>Observed AWS {hp[1] === null ? "no data" : `${hp[1].toFixed(1)}%`}</div>
            <div>Configured AWS {hcfg === null ? "unknown" : `${hcfg}%`}</div>
          </div>
        )}
      </div>
      <details className="mt-2 text-xs">
        <summary className="cursor-pointer text-muted-foreground">Show hourly data</summary>
        <table className="mt-2 w-full tabular-nums">
          <thead><tr className="text-left text-muted-foreground"><th>Time (IST)</th><th>Observed AWS</th><th>Configured AWS</th></tr></thead>
          <tbody>
            {observedAws.filter((_, i) => i % 12 === 0).map(([t, v]) => (
              <tr key={t}>
                <td>{hhmm(t)}</td>
                <td>{v === null ? "no data" : `${v.toFixed(1)}%`}</td>
                <td>{configuredAt(configured, t) ?? "unknown"}{configuredAt(configured, t) !== null && "%"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </details>
    </figure>
  );
}
```

This page replaces the starter `components/split-panel.tsx`, which you can delete.

**Where to look first if it fails:**
- **Pool names:** I assumed the Cloudflare pools are named `cb-aws-prod` and `cb-gcp-prod`, the same as the cells. If they're named differently, change the `CELLS` mapping at the top of `overview.py`.
- **Cloudflare's query schema:** the exporter's Cloudflare analytics query is copied from the skill, which warns that its dataset and field names change from time to time.