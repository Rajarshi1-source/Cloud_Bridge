I couldn't write any files: this session has no write or shell tool. The working directory also has no dashboard code yet, only the `.claude/skills` folder. So all the code is below for you to paste in, and none of it has been built, type-checked or run.

The page answers the question with one verdict. It doesn't just show two numbers side by side. It compares the configured split (the latest `traffic_changes` row) with the split Cloudflare actually delivered, allowing for normal random variation. It also accounts for the 23 h cookie affinity, which means a split lags behind any weight change.

## 1. Control-plane API: add `GET /overview` to `control-plane/api/main.py`

This reuses `auth`, `db`, `prom` and `PROM` from the starter `main.py`.

```python
# ---------- overview: is the configured split actually happening? ----------
import math, re
from datetime import timedelta

CB_ENV = os.environ.get("CB_ENV", "prod")
POOL = re.compile(rf"^cb-(aws|gcp)-{CB_ENV}$")       # pool names and cb_cell share this shape
CLOUDS = ("aws", "gcp")
HISTORY = timedelta(hours=24)

def prom_range(expr: str, start: datetime, end: datetime, step: str = "5m") -> list[dict]:
    r = httpx.get(f"{PROM}/api/v1/query_range", timeout=15,
                  params={"query": expr, "start": start.timestamp(), "end": end.timestamp(), "step": step})
    r.raise_for_status()
    return r.json()["data"]["result"]

def _num(v: Any) -> float | None:
    f = float(v)
    return f if math.isfinite(f) else None              # 0/0 → NaN must become null, not invalid JSON

def _iso(epoch: float) -> str:
    return datetime.fromtimestamp(epoch, timezone.utc).isoformat()

def _scalar(expr: str) -> float | None:
    r = prom(expr)
    return _num(r[0]["value"][1]) if r else None

def _split(results: list[dict], key: str, require_all: bool) -> tuple[dict[str, float], float] | None:
    """Per-pool / per-cell vector → percent share by cloud. None when nothing was measured."""
    totals: dict[str, float] = {}
    for r in results:
        m, v = POOL.match(r["metric"].get(key, "")), _num(r["value"][1])
        if m and v is not None:
            totals[m[1]] = totals.get(m[1], 0.0) + v
    # Cloudflare omits a pool with zero requests (a real 0); a missing cell in the gateway series means no data.
    if require_all and set(totals) != set(CLOUDS):
        return None
    total = sum(totals.values())
    if total <= 0:
        return None
    return {c: 100 * totals.get(c, 0.0) / total for c in CLOUDS}, total

@app.get("/overview", dependencies=[Depends(auth)])
def overview(conn=Depends(db)) -> dict[str, Any]:
    now = datetime.now(timezone.utc)
    start = now - HISTORY

    # The change in force at the window start, plus every change inside the window.
    rows = conn.execute("""
        (SELECT weights, source, pr_url, applied_at FROM traffic_changes
          WHERE applied_at < %(start)s ORDER BY applied_at DESC LIMIT 1)
        UNION ALL
        (SELECT weights, source, pr_url, applied_at FROM traffic_changes WHERE applied_at >= %(start)s)
        ORDER BY applied_at""", {"start": start}).fetchall()
    changes = [{"weights": w, "source": s, "prUrl": p, "appliedAt": a.isoformat()} for w, s, p, a in rows]

    # Freshness = last successful Cloudflare pull, not the query time.
    cf_ok = (_scalar("max(cb_cf_exporter_last_success_timestamp_seconds)")
             or _scalar("min(timestamp(cb_cf_pool_requests_5m))"))
    cf_at = _iso(cf_ok) if cf_ok else None

    o5 = _split(prom("cb_cf_pool_requests_5m"), "pool", require_all=False)
    # Exporter windows overlap, so the 1 h sum is not a request count; only the ratio is meaningful.
    o1h = _split(prom("sum by (pool) (sum_over_time(cb_cf_pool_requests_5m[1h]))"), "pool", require_all=False)

    gw_expr = 'cb:requests:rate5m{service="api-gateway"}'
    g5 = _split(prom(gw_expr), "cb_cell", require_all=True)
    gw_at = _scalar('min(max by (cb_cell) (timestamp(http_server_requests_seconds_count{service="api-gateway"})))')

    # Per-cell health; lastSampleAt is when that cell's gateway samples last arrived over remote_write.
    last = {r["metric"]["cb_cell"]: _num(r["value"][1]) for r in
            prom('max by (cb_cell) (timestamp(http_server_requests_seconds_count{service="api-gateway"}))')}
    def by_cell(expr: str) -> dict[str, float | None]:
        return {r["metric"]["cb_cell"]: _num(r["value"][1]) for r in prom(expr)}
    avail = by_cell("cb:availability:ratio_rate1h")
    p95 = by_cell('cb:latency_p95:5m{service="api-gateway"}')
    rps = by_cell(gw_expr)
    cells = [{"cell": c, "cloud": POOL.match(c)[1],
              "availability": avail.get(c), "p95ms": None if p95.get(c) is None else p95[c] * 1000,
              "rps": rps.get(c), "lastSampleAt": _iso(t) if t else None}
             for c, t in sorted(last.items()) if POOL.match(c)]

    # `or vector(0)` keeps a fully drained AWS pool at 0 % instead of a gap; no traffic at all stays a gap.
    hist = prom_range(f'(sum(cb_cf_pool_requests_5m{{pool="cb-aws-{CB_ENV}"}}) or vector(0))'
                      f' / sum(cb_cf_pool_requests_5m)', start, now)
    observed_aws = [[float(t), 100 * v] for t, s in (hist[0]["values"] if hist else [])
                    if (v := _num(s)) is not None]

    def obs(s: tuple[dict, float] | None, at: str | None, n: bool) -> dict | None:
        return None if s is None or at is None else {"shares": s[0], "requests": s[1] if n else None, "sampledAt": at}

    return {
        "asOf": now.isoformat(),
        "configured": changes[-1] if changes else None,
        "previous": changes[-2] if len(changes) > 1 else None,
        "observed5m": obs(o5, cf_at, n=True),
        "observed1h": obs(o1h, cf_at, n=False),
        "gateway5m": obs(g5, _iso(gw_at) if gw_at else None, n=False),
        "history": {"from": start.timestamp(), "to": now.timestamp(),
                    "observedAws": observed_aws, "changes": changes},
        "cells": cells,
    }
```

## 2. Required fix to `control-plane/cf-exporter/exporter.py`

Without this, the page can say the split looks fine when it doesn't. The starter exporter has two problems:

- **Zero-traffic pools keep their old count.** Prometheus gauge labels stay set, so a pool that drops to zero (for example, during an evacuation) keeps reporting its last non-zero count forever.
- **A failed pull looks fresh.** When a Cloudflare pull fails, the old values are still scraped with new timestamps.

```python
LAST_OK = Gauge("cb_cf_exporter_last_success_timestamp_seconds", "Last successful Cloudflare analytics pull")
# in scrape(), replace the final loop:
    POOL_REQS.clear()                     # a pool with no requests must read 0, not its last non-zero count
    for pool, n in seen.items():
        POOL_REQS.labels(pool=pool).set(n)
    LAST_OK.set_to_current_time()
```

## 3. Next.js dashboard (`control-plane/dashboard/`)

**`lib/control-plane.ts`**
```ts
import "server-only";

export type Cloud = "aws" | "gcp";
export type Split = Record<Cloud, number>; // percentage points
export type TrafficSource = "manual" | "recommender" | "evacuation" | "failback" | "drill" | "break_glass";
export type TrafficChange = { weights: Split; source: TrafficSource; prUrl: string | null; appliedAt: string };
export type ObservedSplit = { shares: Split; requests: number | null; sampledAt: string };
export type CellHealth = {
  cell: string; cloud: Cloud;
  availability: number | null; p95ms: number | null; rps: number | null; lastSampleAt: string | null;
};
export type Overview = {
  asOf: string;
  configured: TrafficChange | null;
  previous: TrafficChange | null;
  observed5m: ObservedSplit | null;
  observed1h: ObservedSplit | null;
  gateway5m: ObservedSplit | null;
  history: { from: number; to: number; observedAws: [number, number][]; changes: TrafficChange[] };
  cells: CellHealth[];
};

export async function getOverview(): Promise<Overview> {
  const res = await fetch(`${process.env.CP_API_URL}/overview`, {
    cache: "no-store",
    headers: { Authorization: `Bearer ${process.env.CB_CP_TOKEN}` },
  });
  if (!res.ok) throw new Error(`control plane ${res.status}`);
  return res.json();
}
```

**`lib/split.ts`**: the verdict logic. Keep it a pure function so it's easy to unit-test.
```ts
import type { Overview, Split } from "./control-plane";

export const AFFINITY_TTL_S = 82_800; // session_affinity_ttl in infra/live/global/30-traffic
export const STALE_AFTER_S = 600;
// Affinity makes sessions, not requests, the independent unit, so the binomial band is optimistic; keep a floor.
export const MIN_TOLERANCE_PTS = 5;

export function tolerancePts(configuredAws: number, requests: number | null): number {
  if (!requests || requests <= 0) return MIN_TOLERANCE_PTS;
  const p = configuredAws / 100;
  return Math.max(MIN_TOLERANCE_PTS, 300 * Math.sqrt((p * (1 - p)) / requests)); // 3σ, in points
}

type Measured = { deviation: number; deviation1h: number | null; tolerance: number; hint: string | null };
export type Verdict =
  | { kind: "unconfigured" }
  | { kind: "unmeasured" }
  | { kind: "stale"; ageS: number }
  | ({ kind: "on_target" | "converging" | "blip" | "off_target" } & Measured);

export function judgeSplit(o: Overview): Verdict {
  const now = Date.parse(o.asOf);
  const cfg = o.configured;
  if (!cfg) return { kind: "unconfigured" };
  const obs = o.observed5m;
  if (!obs) return { kind: "unmeasured" };
  const ageS = (now - Date.parse(obs.sampledAt)) / 1000;
  if (ageS > STALE_AFTER_S) return { kind: "stale", ageS };

  const tolerance = tolerancePts(cfg.weights.aws, obs.requests);
  const deviation = obs.shares.aws - cfg.weights.aws;
  const deviation1h = o.observed1h ? o.observed1h.shares.aws - cfg.weights.aws : null;
  const m = { deviation, deviation1h, tolerance };

  if (Math.abs(deviation) <= tolerance) return { kind: "on_target", ...m, hint: null };

  const sinceChangeS = (now - Date.parse(cfg.appliedAt)) / 1000;
  const prev = o.previous?.weights;
  if (prev && sinceChangeS < AFFINITY_TTL_S && between(obs.shares.aws, prev.aws, cfg.weights.aws)) {
    return {
      kind: "converging", ...m,
      hint: `Weights changed from ${prev.aws}/${prev.gcp} ${duration(sinceChangeS)} ago. Sessions keep their home cell for up to 23 h (cookie affinity), so the observed split moves over gradually.`,
    };
  }
  if (deviation1h !== null && Math.abs(deviation1h) <= tolerance) {
    return { kind: "blip", ...m, hint: "The last hour is on target; the last 5 minutes are not. If it persists, check pool health in Cloudflare." };
  }
  return { kind: "off_target", ...m, hint: diagnose(cfg.weights, obs.shares, tolerance) };
}

function diagnose(cfg: Split, obs: Split, tol: number): string {
  const starved = (["aws", "gcp"] as const).find((c) => cfg[c] > 0 && obs[c] < 1);
  if (starved) {
    return `The ${starved.toUpperCase()} pool is receiving almost nothing. Cloudflare probably marks it unhealthy (/healthz/cell monitor) and is sending its share to the other pool.`;
  }
  if (cfg.aws !== 50 && Math.abs(obs.aws - 50) <= tol) {
    return "Observed is ~50/50 whatever the configured weights say. The weights are probably on origins, not on random_steering.pool_weights.";
  }
  return "Check pool health in Cloudflare, and whether a break-glass change was applied but never committed to terraform.tfvars.json.";
}

/** Cloudflare's count and the cells' own gateway count should agree; if not, one of the metric paths is lying. */
export function sourcesDisagree(o: Overview, tolerance: number): number | null {
  if (!o.observed5m || !o.gateway5m) return null;
  const d = Math.abs(o.observed5m.shares.aws - o.gateway5m.shares.aws);
  return d > tolerance ? d : null;
}

const between = (v: number, a: number, b: number) => v >= Math.min(a, b) && v <= Math.max(a, b);
export function duration(s: number): string {
  if (s < 90) return `${Math.round(s)} s`;
  if (s < 5400) return `${Math.round(s / 60)} min`;
  if (s < 172_800) return `${Math.round(s / 3600)} h`;
  return `${Math.round(s / 86_400)} d`;
}
```

**`lib/format.ts`**
```ts
import { duration } from "./split";
export const ist = (iso: string | number) =>
  new Date(iso).toLocaleString("en-IN", { timeZone: "Asia/Kolkata", dateStyle: "medium", timeStyle: "short" }) + " IST";
export const pct = (v: number) => `${v.toFixed(1)}%`;
export const ago = (fromIso: string, nowIso: string) => `${duration(Math.max(0, (Date.parse(nowIso) - Date.parse(fromIso)) / 1000))} ago`;
```

**`components/as-of.tsx`**: every number shows its source and how old it is.
```tsx
import { ago, ist } from "@/lib/format";

export function AsOf({ source, at, now }: { source: string; at: string | null; now: string }) {
  return (
    <p className="text-xs text-[var(--viz-ink-2)]">
      {source} ·{" "}
      {at ? <time dateTime={at} title={ist(at)}>{ago(at, now)}</time> : <span className="text-[var(--viz-muted)]">no measurement yet</span>}
    </p>
  );
}
```

**`components/split-panel.tsx`**
```tsx
import type { Overview, Split } from "@/lib/control-plane";
import { judgeSplit, sourcesDisagree, type Verdict } from "@/lib/split";
import { AsOf } from "./as-of";
import { pct, ist } from "@/lib/format";

const STATUS: Record<Verdict["kind"], { icon: string; label: string; tone: string }> = {
  on_target:    { icon: "✓", label: "Split is happening",          tone: "var(--status-good)" },
  converging:   { icon: "↻", label: "Converging after a change",   tone: "var(--status-warning)" },
  blip:         { icon: "!", label: "Short-term deviation",        tone: "var(--status-warning)" },
  off_target:   { icon: "✕", label: "Split is not happening",      tone: "var(--status-critical)" },
  stale:        { icon: "?", label: "Cloudflare data is stale",    tone: "var(--viz-muted)" },
  unmeasured:   { icon: "?", label: "No measurement yet",          tone: "var(--viz-muted)" },
  unconfigured: { icon: "?", label: "No recorded traffic change",  tone: "var(--viz-muted)" },
};

export function SplitPanel({ o }: { o: Overview }) {
  const v = judgeSplit(o);
  const s = STATUS[v.kind];
  const cfg = o.configured;
  const disagree = "tolerance" in v ? sourcesDisagree(o, v.tolerance) : null;

  return (
    <section className="space-y-5 rounded-lg border border-[var(--viz-border)] bg-[var(--viz-surface)] p-5">
      <div className="flex items-start gap-3">
        <span aria-hidden className="mt-0.5 grid size-7 place-items-center rounded-full text-sm font-bold text-white" style={{ background: s.tone }}>
          {s.icon}
        </span>
        <div className="space-y-1">
          <h2 className="text-lg font-semibold text-[var(--viz-ink)]">{s.label}</h2>
          <p className="text-sm text-[var(--viz-ink-2)]">{summary(v, o)}</p>
          {"hint" in v && v.hint && <p className="text-sm text-[var(--viz-ink)]">{v.hint}</p>}
          {disagree !== null && (
            <p className="text-sm text-[var(--viz-ink)]">
              Cloudflare and the cells' own gateway counts disagree by {disagree.toFixed(1)} pts. Check whether one cell's Prometheus agent has stopped remote-writing.
            </p>
          )}
        </div>
      </div>

      <div className="space-y-4">
        <SplitRow label="Configured" split={cfg?.weights ?? null} now={o.asOf} at={cfg?.appliedAt ?? null}
          source={cfg ? `traffic_changes · ${cfg.source.replace("_", "-")}${cfg.prUrl ? "" : " · no PR"}` : "traffic_changes"} href={cfg?.prUrl} />
        <SplitRow label="Observed, last 5 min" split={o.observed5m?.shares ?? null} target={cfg?.weights.aws}
          source={`Cloudflare LB analytics${o.observed5m?.requests ? ` · ${Math.round(o.observed5m.requests).toLocaleString("en-IN")} requests` : ""}`}
          at={o.observed5m?.sampledAt ?? null} now={o.asOf} />
        <SplitRow label="Observed, last 1 h" split={o.observed1h?.shares ?? null} target={cfg?.weights.aws}
          source="Cloudflare LB analytics" at={o.observed1h?.sampledAt ?? null} now={o.asOf} />
        <SplitRow label="Cells' own gateway count, 5 min" split={o.gateway5m?.shares ?? null} target={cfg?.weights.aws}
          source="Prometheus cb:requests:rate5m (api-gateway)" at={o.gateway5m?.sampledAt ?? null} now={o.asOf} />
      </div>
    </section>
  );
}

function summary(v: Verdict, o: Overview): string {
  switch (v.kind) {
    case "unconfigured": return "Nothing in traffic_changes. The post-apply step in the 30-traffic workflow records every weight change.";
    case "unmeasured":   return "Cloudflare hasn't reported any load-balancer requests yet.";
    case "stale":        return `The last successful Cloudflare pull was ${Math.round(v.ageS / 60)} min ago. Check cf-exporter before trusting any split.`;
    default: {
      const d1h = v.deviation1h === null ? "" : `; ${sign(v.deviation1h)} pts over 1 h`;
      return `AWS is ${sign(v.deviation)} pts from the configured ${o.configured!.weights.aws}% over 5 min${d1h}. Expected noise is ±${v.tolerance.toFixed(1)} pts.`;
    }
  }
}
const sign = (d: number) => `${d >= 0 ? "+" : "−"}${Math.abs(d).toFixed(1)}`;

function SplitRow({ label, split, source, at, now, target, href }: {
  label: string; split: Split | null; source: string; at: string | null; now: string; target?: number; href?: string | null;
}) {
  return (
    <div className="space-y-1.5">
      <div className="flex flex-wrap items-baseline justify-between gap-x-4 text-sm">
        <span className="font-medium text-[var(--viz-ink)]">{label}</span>
        {split ? (
          <span className="tabular-nums text-[var(--viz-ink-2)]">
            <Swatch c="aws" /> AWS {pct(split.aws)} <span className="mx-1">·</span> <Swatch c="gcp" /> GCP {pct(split.gcp)}
          </span>
        ) : (
          <span className="text-[var(--viz-muted)]">no measurement yet</span>
        )}
      </div>
      {split && (
        <div className="relative">
          <div className="flex h-3 gap-[2px] overflow-hidden rounded-[4px]" role="img" aria-label={`AWS ${pct(split.aws)}, GCP ${pct(split.gcp)}`}>
            {split.aws > 0 && <div className="bg-[var(--viz-aws)]" style={{ flex: `${split.aws} 0 0` }} title={`AWS ${pct(split.aws)}`} />}
            {split.gcp > 0 && <div className="bg-[var(--viz-gcp)]" style={{ flex: `${split.gcp} 0 0` }} title={`GCP ${pct(split.gcp)}`} />}
          </div>
          {target !== undefined && (
            <div className="absolute -top-1 -bottom-1 w-[2px] -translate-x-1/2 rounded bg-[var(--viz-ink)]"
                 style={{ left: `${target}%` }} title={`Configured AWS ${target}%`} />
          )}
        </div>
      )}
      {href ? <a href={href} className="underline-offset-2 hover:underline"><AsOf source={source} at={at} now={now} /></a>
            : <AsOf source={source} at={at} now={now} />}
    </div>
  );
}

const Swatch = ({ c }: { c: "aws" | "gcp" }) => (
  <span aria-hidden className="mr-1 inline-block size-2.5 rounded-[2px] align-baseline" style={{ background: `var(--viz-${c})` }} />
);
```

**`components/split-history-chart.tsx`**: a client component. It's the only client-side part, because the chart responds to hover.
```tsx
"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import { MIN_TOLERANCE_PTS } from "@/lib/split";

type Step = { t: number; aws: number };
const H = 220, M = { t: 12, r: 84, b: 24, l: 40 };
const GAP_S = 900; // > 3 missed 5-min steps → draw a gap, never interpolate missing data

const hhmm = (t: number) =>
  new Date(t * 1000).toLocaleTimeString("en-IN", { timeZone: "Asia/Kolkata", hour: "2-digit", minute: "2-digit", hour12: false });

export function SplitHistoryChart({ from, to, observed, steps }: { from: number; to: number; observed: [number, number][]; steps: Step[] }) {
  const ref = useRef<HTMLDivElement>(null);
  const [w, setW] = useState(640);
  const [hover, setHover] = useState<number | null>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const ro = new ResizeObserver(([e]) => setW(e.contentRect.width));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const iw = Math.max(w - M.l - M.r, 10), ih = H - M.t - M.b;
  const x = (t: number) => M.l + ((t - from) / (to - from)) * iw;
  const y = (p: number) => M.t + (1 - Math.min(Math.max(p, 0), 100) / 100) * ih;
  const configuredAt = (t: number) => {
    let v: number | null = null;
    for (const s of steps) if (s.t <= t) v = s.aws;
    return v;
  };

  const { stepPath, bandPath, obsPath } = useMemo(() => {
    const pts = steps.map((s) => ({ t: Math.max(s.t, from), aws: s.aws }));
    let stepPath = "", upper: string[] = [], lower: string[] = [];
    pts.forEach((s, i) => {
      const x0 = x(s.t), x1 = x(pts[i + 1]?.t ?? to);
      stepPath += `${i ? "V" : "M" + x0}${y(s.aws)}H${x1}`;
      upper.push(`${x0},${y(s.aws + MIN_TOLERANCE_PTS)} ${x1},${y(s.aws + MIN_TOLERANCE_PTS)}`);
      lower.unshift(`${x1},${y(s.aws - MIN_TOLERANCE_PTS)} ${x0},${y(s.aws - MIN_TOLERANCE_PTS)}`);
    });
    const bandPath = pts.length ? `M${[...upper, ...lower].join(" L")}Z` : "";
    const obsPath = observed.map(([t, v], i) =>
      `${i === 0 || t - observed[i - 1][0] > GAP_S ? "M" : "L"}${x(t)},${y(v)}`).join("");
    return { stepPath, bandPath, obsPath };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [w, from, to, observed, steps]);

  const lastObs = observed.at(-1);
  const lastCfg = steps.at(-1);
  let obsLabelY = lastObs ? y(lastObs[1]) : 0, cfgLabelY = lastCfg ? y(lastCfg.aws) : 0;
  if (lastObs && lastCfg && Math.abs(obsLabelY - cfgLabelY) < 14) {
    const mid = (obsLabelY + cfgLabelY) / 2, up = lastObs[1] >= lastCfg.aws;
    obsLabelY = mid + (up ? -7 : 7); cfgLabelY = mid + (up ? 7 : -7);
  }

  const onMove = (e: React.PointerEvent<SVGSVGElement>) => {
    if (!observed.length) return;
    const px = e.clientX - e.currentTarget.getBoundingClientRect().left;
    const t = from + ((px - M.l) / iw) * (to - from);
    let best = 0;
    for (let i = 1; i < observed.length; i++) if (Math.abs(observed[i][0] - t) < Math.abs(observed[best][0] - t)) best = i;
    setHover(best);
  };
  const h = hover !== null ? observed[hover] : null;
  const ticks = Array.from({ length: 5 }, (_, i) => from + ((to - from) * i) / 4);

  return (
    <div ref={ref} className="relative">
      <div className="mb-2 flex gap-4 text-xs text-[var(--viz-ink-2)]">
        <span><span aria-hidden className="mr-1 inline-block h-[2px] w-4 bg-[var(--viz-aws)] align-middle" />Observed AWS share</span>
        <span><span aria-hidden className="mr-1 inline-block w-4 border-t-2 border-dashed border-[var(--viz-ink-2)] align-middle" />Configured (±{MIN_TOLERANCE_PTS} pt band)</span>
      </div>
      <svg width={w} height={H} onPointerMove={onMove} onPointerLeave={() => setHover(null)} role="img"
           aria-label="AWS traffic share over the last 24 hours, observed versus configured">
        {[0, 25, 50, 75, 100].map((p) => (
          <g key={p}>
            <line x1={M.l} x2={M.l + iw} y1={y(p)} y2={y(p)} stroke={p === 0 ? "var(--viz-axis)" : "var(--viz-grid)"} />
            <text x={M.l - 6} y={y(p)} dy="0.32em" textAnchor="end" className="fill-[var(--viz-muted)] text-[11px] tabular-nums">{p}%</text>
          </g>
        ))}
        {ticks.map((t) => (
          <text key={t} x={x(t)} y={H - 6} textAnchor="middle" className="fill-[var(--viz-muted)] text-[11px] tabular-nums">{hhmm(t)}</text>
        ))}
        <path d={bandPath} fill="var(--viz-band)" />
        <path d={stepPath} fill="none" stroke="var(--viz-ink-2)" strokeWidth={2} strokeDasharray="5 4" />
        <path d={obsPath} fill="none" stroke="var(--viz-aws)" strokeWidth={2} strokeLinejoin="round" />
        {lastObs && <text x={M.l + iw + 6} y={obsLabelY} dy="0.32em" className="fill-[var(--viz-ink)] text-[11px] tabular-nums">Observed {lastObs[1].toFixed(1)}%</text>}
        {lastCfg && <text x={M.l + iw + 6} y={cfgLabelY} dy="0.32em" className="fill-[var(--viz-ink-2)] text-[11px] tabular-nums">Configured {lastCfg.aws}%</text>}
        {h && (
          <g pointerEvents="none">
            <line x1={x(h[0])} x2={x(h[0])} y1={M.t} y2={M.t + ih} stroke="var(--viz-axis)" />
            <circle cx={x(h[0])} cy={y(h[1])} r={4} fill="var(--viz-aws)" stroke="var(--viz-surface)" strokeWidth={2} />
          </g>
        )}
        {!observed.length && (
          <text x={M.l + iw / 2} y={M.t + ih / 2} textAnchor="middle" className="fill-[var(--viz-muted)] text-sm">no measurement yet</text>
        )}
      </svg>
      {h && (
        <div className="pointer-events-none absolute top-8 rounded-md border border-[var(--viz-border)] bg-[var(--viz-surface)] px-2 py-1 text-xs tabular-nums shadow-sm"
             style={{ left: Math.min(x(h[0]) + 8, w - 150) }}>
          <div className="text-[var(--viz-ink-2)]">{hhmm(h[0])} IST</div>
          <div className="text-[var(--viz-ink)]">Observed AWS {h[1].toFixed(1)}%</div>
          <div className="text-[var(--viz-ink-2)]">Configured AWS {configuredAt(h[0]) ?? "—"}%</div>
        </div>
      )}
      <details className="mt-2 text-xs text-[var(--viz-ink-2)]">
        <summary className="cursor-pointer">Show as table</summary>
        <table className="mt-2 w-full tabular-nums">
          <thead><tr className="text-left"><th>Time (IST)</th><th>Observed AWS</th><th>Configured AWS</th></tr></thead>
          <tbody>
            {observed.filter((_, i) => i % 12 === 0).map(([t, v]) => (
              <tr key={t}><td>{hhmm(t)}</td><td>{v.toFixed(1)}%</td><td>{configuredAt(t) ?? "—"}%</td></tr>
            ))}
          </tbody>
        </table>
      </details>
    </div>
  );
}
```

**`components/cell-card.tsx`**
```tsx
import type { CellHealth } from "@/lib/control-plane";
import { AsOf } from "./as-of";

export function CellCard({ c, now }: { c: CellHealth; now: string }) {
  const none = <span className="text-[var(--viz-muted)]">no measurement yet</span>;
  return (
    <article className="rounded-lg border border-[var(--viz-border)] bg-[var(--viz-surface)] p-4">
      <h3 className="flex items-center gap-2 font-medium text-[var(--viz-ink)]">
        <span aria-hidden className="size-2.5 rounded-[2px]" style={{ background: `var(--viz-${c.cloud})` }} />
        {c.cell}
      </h3>
      <dl className="mt-3 grid grid-cols-2 gap-y-1.5 text-sm">
        <dt className="text-[var(--viz-ink-2)]">Gateway requests/s</dt>
        <dd className="tabular-nums">{c.rps === null ? none : c.rps.toFixed(1)}</dd>
        <dt className="text-[var(--viz-ink-2)]">Availability (1 h)</dt>
        <dd className="tabular-nums">{c.availability === null ? none : `${(c.availability * 100).toFixed(3)}%`}</dd>
        <dt className="text-[var(--viz-ink-2)]">p95 latency (5 min)</dt>
        <dd className="tabular-nums">{c.p95ms === null ? none : `${Math.round(c.p95ms)} ms`}</dd>
      </dl>
      <div className="mt-3"><AsOf source="remote_write from cell" at={c.lastSampleAt} now={now} /></div>
    </article>
  );
}
```

**`app/page.tsx`**: overview, as a Server Component.
```tsx
import { getOverview, type Overview } from "@/lib/control-plane";
import { SplitPanel } from "@/components/split-panel";
import { SplitHistoryChart } from "@/components/split-history-chart";
import { CellCard } from "@/components/cell-card";
import { ist } from "@/lib/format";

export default async function Page() {
  let o: Overview;
  try {
    o = await getOverview();
  } catch (e) {
    return (
      <main className="mx-auto max-w-6xl p-4 sm:p-6">
        <h1 className="text-2xl font-semibold text-[var(--viz-ink)]">CloudBridge overview</h1>
        <p className="mt-4 text-sm text-[var(--viz-ink-2)]">
          Control-plane API unreachable ({(e as Error).message}). User traffic is unaffected; the control plane is off the request path.
        </p>
      </main>
    );
  }
  const w = o.configured?.weights;
  const steps = o.history.changes.map((c) => ({ t: Date.parse(c.appliedAt) / 1000, aws: c.weights.aws }));

  return (
    <main className="mx-auto max-w-6xl space-y-6 p-4 sm:p-6">
      <header className="flex flex-wrap items-baseline justify-between gap-2">
        <h1 className="text-2xl font-semibold text-[var(--viz-ink)]">
          {w ? `Is the ${w.aws}/${w.gcp} split happening?` : "CloudBridge overview"}
        </h1>
        <p className="text-sm text-[var(--viz-ink-2)]">as of {ist(o.asOf)}</p>
      </header>

      <SplitPanel o={o} />

      <section className="rounded-lg border border-[var(--viz-border)] bg-[var(--viz-surface)] p-5">
        <h2 className="mb-3 font-medium text-[var(--viz-ink)]">AWS share, last 24 h</h2>
        <SplitHistoryChart from={o.history.from} to={o.history.to} observed={o.history.observedAws} steps={steps} />
      </section>

      <section className="grid gap-4 md:grid-cols-2">
        {o.cells.length
          ? o.cells.map((c) => <CellCard key={c.cell} c={c} now={o.asOf} />)
          : <p className="text-sm text-[var(--viz-muted)]">No cell has sent gateway metrics yet.</p>}
      </section>
    </main>
  );
}
```

**Append to `app/globals.css`**: the AWS and GCP colours are checked to be distinguishable for colour-blind viewers in both light and dark mode.
```css
:root {
  --viz-surface: #fcfcfb; --viz-ink: #0b0b0b; --viz-ink-2: #52514e; --viz-muted: #898781;
  --viz-grid: #e1e0d9; --viz-axis: #c3c2b7; --viz-border: rgba(11,11,11,0.10);
  --viz-aws: #2a78d6; --viz-gcp: #eb6834; --viz-band: rgba(82,81,78,0.10);
  --status-good: #0ca30c; --status-warning: #fab219; --status-critical: #d03b3b;
}
@media (prefers-color-scheme: dark) {
  :root:where(:not([data-theme="light"])) {
    --viz-surface: #1a1a19; --viz-ink: #ffffff; --viz-ink-2: #c3c2b7;
    --viz-grid: #2c2c2a; --viz-axis: #383835; --viz-border: rgba(255,255,255,0.10);
    --viz-aws: #3987e5; --viz-gcp: #d95926; --viz-band: rgba(195,194,183,0.12);
  }
}
:root[data-theme="dark"] {
  --viz-surface: #1a1a19; --viz-ink: #ffffff; --viz-ink-2: #c3c2b7;
  --viz-grid: #2c2c2a; --viz-axis: #383835; --viz-border: rgba(255,255,255,0.10);
  --viz-aws: #3987e5; --viz-gcp: #d95926; --viz-band: rgba(195,194,183,0.12);
}
```

## How the verdict works
- **On target:** observed AWS share is within ±max(5 pts, 3σ) of the configured share. The 5-point minimum is there because affinity makes users the independent unit, not individual requests.
- **Converging:** the weights changed less than 23 h ago and the observed share sits between the old and new weights. Cookie affinity is expected to make it lag.
- **Short-term deviation:** the last 5 min are off but the last hour is on target.
- **Not happening:** off over both 5 min and 1 h. The page then suggests a likely cause:
  - one pool gets about 0%: Cloudflare probably marks it unhealthy;
  - stuck at about 50/50: the weights are probably on origins instead of pools;
  - otherwise: check pool health, or a break-glass change that was never committed.
- **Second check:** Cloudflare's per-pool counts are compared with the cells' own gateway request counts. If they disagree, the page says so, because that usually means one cell's metrics have stopped arriving.
- **No guessed numbers:** any missing number shows "no measurement yet". Cloudflare data older than 10 min shows "stale" instead of a verdict.

## Things to check when you paste it in
- **Install `server-only`:** `npm i server-only`.
- **Pool names:** the code assumes Cloudflare pools are named `cb-aws-prod` / `cb-gcp-prod`, per the `30-traffic` stack. Set `CB_ENV` on the API if this runs for another environment.
- **No unit tests yet:** `judgeSplit` is pure, so it's the obvious first Vitest target. Cover each verdict case, including the ~50/50 case.
- **Probe check not included:** the overview spec also lists a blackbox `X-CB-Cell` distribution panel. No metric records which cell answered each probe yet, so it isn't on the page.