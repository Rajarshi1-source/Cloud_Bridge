**No. Keep Argo CD as the only deployer, and make Argo faster instead.** Running `helm upgrade` from CI causes two problems:

1. **Two tools would manage the same releases.** Argo CD watches those resources and sees your `helm upgrade` as drift. With self-heal on, it puts the old version back within minutes, and your hotfix disappears. With self-heal off, the cluster no longer matches Git, and nobody can tell which version is actually running. We had exactly this in rev 1, when Terraform's `helm_release` and a `helm upgrade` step kept overwriting each other.
2. **The two clouds stop matching.** If the hotfix lands on one cell outside the ring files, the image digests in AWS and GCP differ. The nightly parity check fails, and rollback (`git revert` of a ring file) no longer restores what is actually running.

There's also a security cost: CI would need cluster-admin credentials for both clouds. With the current pull-based setup, CI never touches a cluster.

## Making Argo CD fast enough for hotfixes

The slow part is usually Argo waiting to notice the change, not the deploy itself:

- **Add a Git webhook.** By default Argo CD checks Git every 3 minutes. A webhook from GitHub to each cell's `argocd-server` `/api/webhook` starts the sync within seconds of the merge. This is the biggest win.
- **Or start the sync from CI.** After the ring PR merges, a workflow step can run `argocd app sync <app> --grpc-web` with a token scoped to sync only. Argo still does the deploying, so there is still only one owner.
- **Shorten the canary for hotfixes only.** Normally a release goes 10 → 50 → 100 with 5-minute analysis steps, plus a 30-minute soak in GCP before AWS gets it. For a labelled hotfix you could use a shorter step plan or soak, but keep the analysis gate. Skipping it is how one bad hotfix reaches both clouds at once.
- **Make image pulls fast.** With layered jars, a code-only fix ships one small layer through the ECR and Artifact Registry mirrors, so the pull itself should take seconds.

## If it's truly urgent and only one cloud is affected

Open a `ring-main` PR with the hotfix digest and add a `ring-window` exception to `parity/exceptions.yaml` with an owner and an expiry (2 hours at most). Then follow up with the normal ring-canary PR so both clouds converge. The fix still goes through Git, can be rolled back, and the parity job reports the gap until the clouds match again.

If you tell me where the time is going (detecting the change, image pull, canary steps or soak), I can make the specific change: webhook config, a sync step in `ring-promote.yml`, or a hotfix variant of the Rollout steps.