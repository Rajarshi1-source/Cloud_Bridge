You can, but if Argo CD manages the same app, the two tools will fight over it. It's usually better to make Argo faster than to go around it.

## Why `helm upgrade` alongside Argo CD causes trouble

- **Argo reverts it.** With `selfHeal: true`, Argo sees your hotfix as drift from Git and rolls it back, often within seconds to minutes.
- **Two owners for the same objects.** Argo renders charts with `helm template` and applies the result. It doesn't create a Helm release. Running `helm upgrade --install` creates a separate release secret that claims the same Deployments and Services. You can then get ownership errors, conflicts over who manages which fields, and `prune` deleting things you didn't expect.
- **Git stops being accurate.** If the hotfix never gets committed back, the next normal sync silently removes it. That's exactly what you don't want after an incident.
- **More access for CI.** GitHub Actions would need cluster credentials that can write to production. Argo's pull model exists so CI doesn't need them.

## Make the Argo path fast instead

Argo is usually slow because it **polls Git every 3 minutes by default**, not because syncing is slow. To fix that:

1. **Add a Git webhook.** Point your GitHub repo's webhook at `https://<argocd>/api/webhook`. Argo then refreshes right after each push instead of waiting for the next poll.
2. **Trigger the sync from your hotfix workflow:**
   ```yaml
   - name: Commit hotfix image tag
     run: |
       yq -i '.image.tag = "${{ github.sha }}"' envs/prod/values.yaml
       git commit -am "hotfix: ${{ github.sha }}" && git push
   - name: Sync now
     run: |
       argocd app sync my-app --grpc-web --timeout 300
       argocd app wait my-app --health --timeout 300
     env:
       ARGOCD_SERVER: ${{ secrets.ARGOCD_SERVER }}
       ARGOCD_AUTH_TOKEN: ${{ secrets.ARGOCD_TOKEN }}  # project-scoped token, sync-only
   ```
   This should take seconds, the change stays in Git, and CI only gets a sync-only token instead of cluster-admin access.
3. **Check for other slow spots.** These include:
   - sync waves or hooks, such as long migration Jobs
   - `timeout.reconciliation` in `argocd-cm`
   - an overloaded repo-server, for example a large monorepo or slow Helm dependency builds

## If you really need a bypass

Treat it as a documented break-glass procedure, not your normal hotfix path:

1. Turn off auto-sync for that app: `argocd app set my-app --sync-policy none`.
2. Apply the fix. Use `kubectl set image` or `helm template | kubectl apply`, not `helm upgrade`, so you don't create a competing release.
3. Commit the same change to Git right away.
4. Turn auto-sync back on and confirm the app shows as Synced.

**My recommendation:** use the webhook plus `argocd app sync` from Actions. You'll likely get hotfix times close to a direct `helm upgrade` without any of the problems above. If you share your Application manifest or workflow, I can help find where the delay actually comes from.