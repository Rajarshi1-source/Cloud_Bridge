I wrote the query against the control-plane PostgreSQL ledger. It isn't saved anywhere: this directory has no repo files, so it's below to paste into a Grafana Table panel (datasource role `cp_reader`, format **Table**). I haven't run it, because there's no database or Grafana here to test it against.

It extends the skill's reference cost-per-request query (Q1). It returns one row per service with AWS and GCP side by side, plus a final row for cost it can't attribute.

```sql
-- Panel: Cost per 1k requests by service: AWS vs GCP (prod, last 30 complete billing days)
-- Usage charges only (credits excluded). EffectiveCost and ListCost both shown. INR via fx_daily.
WITH prod_cells AS (
  SELECT id AS cell_id, cloud::text AS cloud
  FROM cells
  WHERE env = 'prod'
),
-- The window ends on the last day BOTH clouds have complete billing for (the newest charge day is
-- treated as partial), so a lagging export can't make one cloud look cheaper.
complete AS (
  SELECT p.cloud, max((c.charge_period_start AT TIME ZONE 'UTC')::date) - 1 AS through_day
  FROM cost_line_items c
  JOIN prod_cells p ON p.cell_id = c.cb_cell
  WHERE c.charge_period_start >= current_date - 45
  GROUP BY p.cloud
),
win AS (
  SELECT min(through_day) - 29 AS since,
         min(through_day)      AS through_day
  FROM complete
  HAVING count(*) = 2            -- one cloud has no data → empty panel, not a one-sided comparison
),
raw AS (
  SELECT (c.charge_period_start AT TIME ZONE 'UTC')::date AS day,
         coalesce(p.cloud,
                  CASE WHEN c.provider_name ILIKE ANY (ARRAY['aws%', 'amazon%']) THEN 'aws'
                       WHEN c.provider_name ILIKE 'google%'                      THEN 'gcp' END) AS cloud,
         p.cell_id,
         c.cb_service AS service,
         c.effective_cost,
         c.list_cost,
         c.billing_currency
  FROM cost_line_items c
  CROSS JOIN win w
  LEFT JOIN prod_cells p ON p.cell_id = c.cb_cell
  WHERE c.charge_category = 'Usage'
    AND c.charge_period_start >= current_date - 45                       -- plan-time partition pruning
    AND (c.charge_period_start AT TIME ZONE 'UTC')::date BETWEEN w.since AND w.through_day
    AND (p.cell_id IS NOT NULL OR c.cb_cell IS NULL)                     -- prod cells + untagged only
),
ledger AS (
  SELECT r.day, r.cloud, r.cell_id, r.service,
         r.effective_cost * x.rate AS eff_inr,
         r.list_cost      * x.rate AS list_inr,
         x.rate IS NULL            AS fx_missing
  FROM raw r
  LEFT JOIN fx_daily fx
         ON fx.day = r.day AND fx.from_ccy = r.billing_currency AND fx.to_ccy = 'INR'
  CROSS JOIN LATERAL (
    SELECT CASE WHEN r.billing_currency = 'INR' THEN 1 ELSE fx.rate END AS rate
  ) x
),
-- Direct: DB, cache and LB rows carry cb-service and attach to that service.
direct AS (
  SELECT cloud, service, sum(eff_inr) AS eff, sum(list_inr) AS list
  FROM ledger
  WHERE cell_id IS NOT NULL AND service IS NOT NULL
  GROUP BY 1, 2
),
-- Shared: node, NAT and control-plane cost of a cell, split per day by OpenCost CPU share (an estimate).
shared_daily AS (
  SELECT cloud, cell_id, day, sum(eff_inr) AS eff, sum(list_inr) AS list
  FROM ledger
  WHERE cell_id IS NOT NULL AND service IS NULL
  GROUP BY 1, 2, 3
),
shared AS (
  SELECT s.cloud, a.service, sum(s.eff * a.cpu_share) AS eff, sum(s.list * a.cpu_share) AS list
  FROM shared_daily s
  JOIN allocation_daily a ON a.cell_id = s.cell_id AND a.day = s.day
  GROUP BY 1, 2
),
-- Unallocated is shown, never spread: shared cost beyond the allocated shares (idle capacity,
-- days without OpenCost data) plus cost with no cb-cell tag.
unallocated AS (
  SELECT cloud, sum(eff) AS eff, sum(list) AS list
  FROM (
    SELECT s.cloud,
           s.eff  * (1 - coalesce(a.share, 0)) AS eff,
           s.list * (1 - coalesce(a.share, 0)) AS list
    FROM shared_daily s
    LEFT JOIN (SELECT cell_id, day, sum(cpu_share) AS share
               FROM allocation_daily GROUP BY 1, 2) a USING (cell_id, day)
    UNION ALL
    SELECT cloud, eff_inr, list_inr FROM ledger WHERE cell_id IS NULL
  ) u
  GROUP BY cloud
),
vol AS (
  SELECT p.cloud, v.service, sum(v.requests) AS req
  FROM request_volume_daily v
  JOIN prod_cells p USING (cell_id)
  CROSS JOIN win w
  WHERE v.day BETWEEN w.since AND w.through_day
  GROUP BY 1, 2
),
svc AS (
  SELECT cloud, service, c.eff, c.list, v.req
  FROM (SELECT cloud, service, sum(eff) AS eff, sum(list) AS list
        FROM (SELECT * FROM direct UNION ALL SELECT * FROM shared) d
        GROUP BY 1, 2) c
  FULL JOIN vol v USING (cloud, service)
),
pivot AS (
  SELECT service,
         max(eff  / nullif(req, 0) * 1000) FILTER (WHERE cloud = 'aws') AS aws_eff_1k,
         max(eff  / nullif(req, 0) * 1000) FILTER (WHERE cloud = 'gcp') AS gcp_eff_1k,
         max(list / nullif(req, 0) * 1000) FILTER (WHERE cloud = 'aws') AS aws_list_1k,
         max(list / nullif(req, 0) * 1000) FILTER (WHERE cloud = 'gcp') AS gcp_list_1k,
         max(eff) FILTER (WHERE cloud = 'aws') AS aws_eff,
         max(eff) FILTER (WHERE cloud = 'gcp') AS gcp_eff,
         max(req) FILTER (WHERE cloud = 'aws') AS aws_req,
         max(req) FILTER (WHERE cloud = 'gcp') AS gcp_req
  FROM svc
  GROUP BY service
  UNION ALL
  SELECT '(unallocated)', NULL, NULL, NULL, NULL,
         max(eff) FILTER (WHERE cloud = 'aws'),
         max(eff) FILTER (WHERE cloud = 'gcp'),
         NULL, NULL
  FROM unallocated
)
SELECT p.service                                               AS "Service",
       round(p.aws_eff_1k, 4)                                  AS "AWS ₹/1k req (effective)",
       round(p.gcp_eff_1k, 4)                                  AS "GCP ₹/1k req (effective)",
       round(100 * (p.gcp_eff_1k / nullif(p.aws_eff_1k, 0) - 1), 1)
                                                               AS "GCP vs AWS % (+ = GCP dearer)",
       round(p.aws_list_1k, 4)                                 AS "AWS ₹/1k req (list)",
       round(p.gcp_list_1k, 4)                                 AS "GCP ₹/1k req (list)",
       round(p.aws_eff, 2)                                     AS "AWS ₹ total",
       round(p.gcp_eff, 2)                                     AS "GCP ₹ total",
       p.aws_req                                               AS "AWS requests",
       p.gcp_req                                               AS "GCP requests",
       w.since || ' → ' || w.through_day                       AS "Billing window (UTC days)",
       (SELECT count(*) FROM ledger WHERE fx_missing)          AS "Rows missing FX"
FROM pivot p
CROSS JOIN win w
ORDER BY p.service = '(unallocated)', p.service;
```

**Choices that differ from the reference query:**
- **Window:** "Last 30 days" means the 30 days ending on the last day both clouds have complete billing data, not ending today. Billing exports run a day or two behind while request counts are current, so ending today would make costs per request look too low.
- **Currency:** each line item is converted to INR using that day's `fx_daily` rate. The reference query added AWS dollars and GCP rupees together.
- **Missing exchange rates:** if a day has no rate, those rows are left out of the totals. The last column counts them; set a Grafana override to turn it red when it's above 0.
- **Prod only, and totals by cloud:** if a cloud ever has more than one prod cell, costs and requests are added up before dividing.
- **Unattributed cost:** costs with no `cb-cell` tag, and shared node cost that isn't covered by service allocation, get their own `(unallocated)` row instead of disappearing. The no-tag part can't be traced to an environment, so it may include some non-prod cost.

**Things to know before reading the panel:**
- **Date boundaries don't line up:** billing days are counted in UTC, but `request_volume_daily` is rolled up at 00:05 IST, which is 5.5 hours apart. Over 30 days the effect is small; say so if someone asks.
- **No significance test:** the "GCP vs AWS %" column only describes the numbers. With little data, small differences are mostly noise, so add a panel description saying that, and that shared costs are an OpenCost estimate.
- **Freshness:** the window column shows how old the billing data is. You could pair the panel with the freshness stat panel (the skill's query that shows `max(ingested_at)` per provider).