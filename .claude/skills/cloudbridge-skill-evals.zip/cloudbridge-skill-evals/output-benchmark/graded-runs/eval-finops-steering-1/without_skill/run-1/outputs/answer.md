Your working directory is empty, so I couldn't check your schemas. This query assumes the standard billing exports, both in BigQuery: the native GCP detailed billing export, and the AWS Cost and Usage Report (CUR 2.0, the Data Exports format) loaded into BigQuery. Replace the three placeholders in angle brackets with your table names.

```sql
-- AWS vs GCP cost per service, last 30 complete days
-- Net cost (credits/discounts applied), tax excluded, USD only.
DECLARE start_date DATE DEFAULT DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY);
DECLARE end_date   DATE DEFAULT CURRENT_DATE();  -- exclusive; today's data is still incomplete

WITH service_map AS (
  -- Map each cloud's own service name to one shared category so rows line up
  SELECT * FROM UNNEST([
    STRUCT('aws' AS cloud, 'AmazonEC2'          AS native_service, 'Compute (VMs)'       AS service_category),
    ('gcp', 'Compute Engine',                     'Compute (VMs)'),
    ('aws', 'AmazonEKS',                          'Kubernetes'),
    ('gcp', 'Kubernetes Engine',                  'Kubernetes'),
    ('aws', 'AWSLambda',                          'Serverless'),
    ('gcp', 'Cloud Run',                          'Serverless'),
    ('gcp', 'Cloud Run functions',                'Serverless'),
    ('gcp', 'Cloud Functions',                    'Serverless'),
    ('aws', 'AmazonS3',                           'Object Storage'),
    ('gcp', 'Cloud Storage',                      'Object Storage'),
    ('aws', 'AmazonRDS',                          'Managed SQL'),
    ('gcp', 'Cloud SQL',                          'Managed SQL'),
    ('aws', 'AmazonDynamoDB',                     'NoSQL'),
    ('gcp', 'Cloud Firestore',                    'NoSQL'),
    ('gcp', 'Cloud Bigtable',                     'NoSQL'),
    ('aws', 'AmazonElastiCache',                  'In-memory Cache'),
    ('gcp', 'Cloud Memorystore for Redis',        'In-memory Cache'),
    ('aws', 'AmazonRedshift',                     'Data Warehouse'),
    ('gcp', 'BigQuery',                           'Data Warehouse'),
    ('aws', 'AmazonCloudWatch',                   'Monitoring & Logging'),
    ('gcp', 'Cloud Monitoring',                   'Monitoring & Logging'),
    ('gcp', 'Cloud Logging',                      'Monitoring & Logging'),
    ('aws', 'AmazonCloudFront',                   'CDN'),
    ('gcp', 'Networking',                         'Networking'),
    ('aws', 'AmazonVPC',                          'Networking'),
    ('aws', 'AWSDataTransfer',                    'Networking')
  ])
),

aws AS (
  SELECT
    'aws'                         AS cloud,
    line_item_product_code        AS native_service,
    SUM(line_item_unblended_cost) AS cost   -- Credit/Refund/discount rows are negative, so this nets them out
  FROM `<project>.<dataset>.aws_cur`
  WHERE DATE(line_item_usage_start_date) >= start_date
    AND DATE(line_item_usage_start_date) <  end_date
    AND line_item_line_item_type != 'Tax'
    AND line_item_currency_code = 'USD'
  GROUP BY native_service
),

gcp AS (
  SELECT
    'gcp'               AS cloud,
    service.description AS native_service,
    SUM(cost)
      + SUM(IFNULL((SELECT SUM(c.amount) FROM UNNEST(credits) AS c), 0)) AS cost  -- credits are negative
  FROM `<project>.<dataset>.gcp_billing_export_resource_v1_<BILLING_ACCOUNT_ID>`
  -- Filter on the partition column first to limit the scan (late-arriving rows can land a few days later)
  WHERE DATE(_PARTITIONTIME) >= DATE_SUB(start_date, INTERVAL 3 DAY)
    AND DATE(usage_start_time) >= start_date
    AND DATE(usage_start_time) <  end_date
    AND cost_type != 'tax'
    AND currency = 'USD'
  GROUP BY native_service
),

combined AS (
  SELECT
    COALESCE(m.service_category, u.native_service) AS service_category,  -- services with no mapping keep their own name
    u.cloud,
    u.cost
  FROM (SELECT * FROM aws UNION ALL SELECT * FROM gcp) AS u
  LEFT JOIN service_map AS m
    ON m.cloud = u.cloud AND m.native_service = u.native_service
)

SELECT
  service_category,
  ROUND(SUM(IF(cloud = 'aws', cost, 0)), 2)                      AS aws_cost,
  ROUND(SUM(IF(cloud = 'gcp', cost, 0)), 2)                      AS gcp_cost,
  ROUND(SUM(cost), 2)                                            AS total_cost,
  ROUND(SUM(IF(cloud = 'aws', cost, -cost)), 2)                  AS aws_minus_gcp,
  ROUND(SAFE_DIVIDE(SUM(IF(cloud = 'aws', cost, 0)), SUM(cost)) * 100, 1) AS aws_share_pct
FROM combined
GROUP BY service_category
HAVING ABS(SUM(cost)) >= 1        -- hide categories under $1 total
ORDER BY total_cost DESC;
```

**Choices you may want to change:**
- **Window:** the 30 days end yesterday, so today's half-loaded billing data doesn't skew the panel. To include today, set `end_date` to `DATE_ADD(CURRENT_DATE(), INTERVAL 1 DAY)`. Many dashboard tools (Grafana, Looker Studio, Metabase) provide their own time-range variable; you can use it in place of the two `DECLARE` lines.
- **Cost basis:** this is net cost on both clouds: AWS unblended cost with credit and refund rows included, and GCP cost plus credits. For the price before discounts, drop the credits part from GCP and add `AND line_item_line_item_type NOT IN ('Credit','Refund')` to the AWS filter.
- **Service mapping:** most of the mismatch between clouds comes from the mapping. One example is AWS data transfer charges, which mostly appear under `AmazonEC2`, not `AWSDataTransfer`. Services that aren't mapped still show up under their own names, so nothing gets dropped. You can find unmapped services by running `combined` on its own and filtering for `m.service_category IS NULL`.
- **Chart shape:** the query returns one row per service with separate AWS and GCP columns, which works as-is for a grouped or stacked bar chart. If your tool wants one row per series, select `service_category, cloud, SUM(cost)` from `combined` instead.

If your AWS cost data lives in Athena rather than BigQuery, I can rewrite the AWS part in Athena SQL. If you share your real table names, I can check the query against them with `bq`.