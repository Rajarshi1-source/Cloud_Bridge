I don't have a file-writing tool in this session and the working directory only holds the skill files, so nothing was written or compiled. The code below is ready to paste into `services/api-gateway`.

It starts from the skill's starter `CellHealthController` and fixes four problems in it:

- **Many probes at once.** When the 2 s cache expired, every concurrent probe ran its own check against the DB. Now one probe refreshes the cache and the others wait for its result.
- **Response time.** The starter ran the two checks one after the other, and the DB check had no time limit beyond the 3 s socket timeout. They now run in parallel, with a 1 s limit on the DB query and a 2 s limit on getting a connection. The worst case is about 3 s, under Cloudflare's 5 s monitor timeout.
- **Shutdown.** The gateway's own readiness is now checked on every request and never cached. When a pod starts shutting down, Cloudflare sees a 503 immediately.
- **Headers.** The response now has `Cache-Control: no-store` and `X-CB-Cell`. The route filters never added `X-CB-Cell` to this endpoint, because it's served by the controller rather than a route.

### `src/main/java/dev/cloudbridge/gateway/CellHealthController.java`

```java
package dev.cloudbridge.gateway;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.availability.ApplicationAvailability;
import org.springframework.boot.availability.ReadinessState;
import org.springframework.http.CacheControl;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClient;

import javax.sql.DataSource;
import java.time.Duration;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.locks.ReentrantLock;

/**
 * "Can this cell take orders?" — what Cloudflare's monitor asks every 60 s from SAS and SEAS.
 * UP = gateway accepting traffic + order-service readiness + cell DB SELECT 1.
 * Valkey is deliberately excluded: a cold or dead cache costs latency, it must not drain the cloud.
 */
@RestController
class CellHealthController {

    record Snapshot(Instant at, boolean orderService, boolean db) {
        boolean up() { return orderService && db; }
    }

    private final ApplicationAvailability availability;
    private final RestClient orderSvc;
    private final JdbcTemplate db;                               // read-only health user on the cell DB
    private final String cell;
    private final Duration ttl;
    private final ReentrantLock refresh = new ReentrantLock();   // not synchronized: avoids pinning virtual threads on Java 21
    private volatile Snapshot last = new Snapshot(Instant.EPOCH, false, false);

    CellHealthController(ApplicationAvailability availability,
                         DataSource dataSource,
                         @Value("${cloudbridge.order-url}") String orderUrl,
                         @Value("${cloudbridge.cell}") String cell,
                         @Value("${cloudbridge.health.cache-ttl:2s}") Duration ttl) {
        var rf = new SimpleClientHttpRequestFactory();
        rf.setConnectTimeout(Duration.ofMillis(300));
        rf.setReadTimeout(Duration.ofMillis(500));
        this.orderSvc = RestClient.builder().baseUrl(orderUrl).requestFactory(rf).build();
        this.db = new JdbcTemplate(dataSource);
        this.db.setQueryTimeout(1);                              // seconds; Hikari connection-timeout bounds acquisition at 2 s
        this.availability = availability;
        this.cell = cell;
        this.ttl = ttl;
    }

    @GetMapping("/healthz/cell")
    ResponseEntity<Map<String, Object>> health() {
        // Live, never cached: on graceful shutdown readiness flips to REFUSING_TRAFFIC and Cloudflare must see it at once.
        boolean gateway = availability.getReadinessState() == ReadinessState.ACCEPTING_TRAFFIC;
        Snapshot s = snapshot();
        boolean up = gateway && s.up();

        var checks = new LinkedHashMap<String, String>();
        checks.put("gateway", state(gateway));
        checks.put("order-service", state(s.orderService()));
        checks.put("db", state(s.db()));
        var body = new LinkedHashMap<String, Object>();
        body.put("cell", cell);
        body.put("status", state(up));
        body.put("checks", checks);
        body.put("checkedAt", s.at().toString());
        return ResponseEntity.status(up ? 200 : 503)
                .cacheControl(CacheControl.noStore())
                .header("X-CB-Cell", cell)
                .body(body);
    }

    /** 2 s single-flight cache: probes from several Cloudflare regions must not hammer the DB. */
    private Snapshot snapshot() {
        Snapshot s = last;
        if (fresh(s)) return s;
        refresh.lock();
        try {
            s = last;
            if (fresh(s)) return s;                              // another probe refreshed while we waited
            s = probe();
            last = s;
            return s;
        } finally {
            refresh.unlock();
        }
    }

    private boolean fresh(Snapshot s) {
        return s.at().plus(ttl).isAfter(Instant.now());
    }

    /** Both checks in parallel: worst case ≈ 3 s (DB acquire + query), inside Cloudflare's 5 s monitor timeout. */
    private Snapshot probe() {
        try (var exec = Executors.newVirtualThreadPerTaskExecutor()) {
            Future<Boolean> order = exec.submit(this::orderServiceReady);
            Future<Boolean> database = exec.submit(this::dbReachable);
            boolean orderOk = await(order);
            boolean dbOk = await(database);
            return new Snapshot(Instant.now(), orderOk, dbOk);
        }
    }

    private boolean orderServiceReady() {
        try {
            return orderSvc.get().uri("/actuator/health/readiness").retrieve()
                    .toBodilessEntity().getStatusCode().is2xxSuccessful();
        } catch (Exception e) {
            return false;
        }
    }

    private boolean dbReachable() {
        try {
            return Integer.valueOf(1).equals(db.queryForObject("SELECT 1", Integer.class));
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean await(Future<Boolean> f) {
        try {
            return f.get();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        } catch (ExecutionException e) {
            return false;
        }
    }

    private static String state(boolean ok) { return ok ? "UP" : "DOWN"; }
}
```

The response body only says UP or DOWN for each check and never includes error text, because the endpoint is reachable through Cloudflare.

### `application.yml` additions (gateway)

```yaml
spring:
  datasource:
    url: ${CELL_DB_URL}
    username: ${HEALTH_DB_USER:cb_health}      # login role with no table grants; SELECT 1 needs none
    password: ${HEALTH_DB_PASSWORD}
    hikari:
      maximum-pool-size: 2
      minimum-idle: 1
      connection-timeout: 2000
      data-source-properties:
        socketTimeout: 3

cloudbridge:
  cell: ${CB_CELL}
  order-url: ${ORDER_URL:http://order-service:8081}
  health:
    cache-ttl: 2s
```

The `cb_health` role needs `LOGIN` and a small `CONNECTION LIMIT` on the cell database, nothing else. The load-shedding filter should leave `/healthz/**` and `/actuator/**` alone, so heavy load still shows as 200 rather than draining the cell.

### `src/test/java/dev/cloudbridge/gateway/CellHealthIT.java`

This is the skill's test #4, plus a check that the cell goes down when order-service isn't ready.

```java
package dev.cloudbridge.gateway;

import com.sun.net.httpserver.HttpServer;
import org.junit.jupiter.api.*;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.boot.testcontainers.service.connection.ServiceConnection;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.concurrent.atomic.AtomicInteger;

import static org.assertj.core.api.Assertions.assertThat;

@Testcontainers
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, properties = {
        "cloudbridge.cell=cb-test",
        "cloudbridge.health.cache-ttl=0s",
        "INVENTORY_URL=http://localhost:1",
        "spring.data.redis.url=redis://localhost:1"     // Valkey unreachable on purpose
})
class CellHealthIT {
    @Container @ServiceConnection
    static PostgreSQLContainer<?> pg = new PostgreSQLContainer<>("postgres:18.4-alpine");

    static final AtomicInteger orderStatus = new AtomicInteger(200);
    static final HttpServer orderStub;
    static {
        try {
            orderStub = HttpServer.create(new InetSocketAddress("localhost", 0), 0);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
        orderStub.createContext("/actuator/health/readiness", ex -> {
            ex.sendResponseHeaders(orderStatus.get(), -1);
            ex.close();
        });
        orderStub.start();
    }

    @DynamicPropertySource
    static void props(DynamicPropertyRegistry r) {
        String url = "http://localhost:" + orderStub.getAddress().getPort();
        r.add("cloudbridge.order-url", () -> url);
        r.add("ORDER_URL", () -> url);
    }

    @AfterAll static void stopStub() { orderStub.stop(0); }

    @LocalServerPort int port;
    final HttpClient http = HttpClient.newHttpClient();

    HttpResponse<String> probe() throws Exception {
        return http.send(HttpRequest.newBuilder(URI.create("http://localhost:" + port + "/healthz/cell")).build(),
                HttpResponse.BodyHandlers.ofString());
    }

    @Test @Order(1)
    void upWithValkeyDown() throws Exception {
        var r = probe();
        assertThat(r.statusCode()).isEqualTo(200);
        assertThat(r.headers().firstValue("X-CB-Cell")).hasValue("cb-test");
        assertThat(r.headers().firstValue("Cache-Control")).hasValueSatisfying(v -> assertThat(v).contains("no-store"));
    }

    @Test @Order(2)
    void downWhenOrderServiceNotReady() throws Exception {
        orderStatus.set(503);
        try {
            assertThat(probe().statusCode()).isEqualTo(503);
        } finally {
            orderStatus.set(200);
        }
    }

    @Test @Order(3)                                      // last: stops the shared container
    void downWhenCellDbStops() throws Exception {
        pg.stop();
        assertThat(probe().statusCode()).isEqualTo(503);
    }
}
```

The test sets `cache-ttl` to `0s` so each probe runs a fresh check; production uses 2 s. Run it with `./mvnw -pl services/api-gateway verify`.