I can't find any code to add this to. The working directory (`/tmp/cbout-02xqw_gl`) is empty and isn't a git repo, so I don't know which service this endpoint belongs in.

Your skills point to two projects with different stacks, and the endpoint would be written differently in each:

- **NaukriNearby**: a Spring Boot 4.0.6 / Java 21 backend.
- **PRGraph**: a Next.js 14 Route Handler on Node 24, which would live at `app/api/healthz/cell/route.ts` or be rewritten to `/healthz/cell`.

Which one is it? It would also help to point me at the repo or open the session inside it.

If you don't have a design yet, here's what I'd build by default:

- **Reports this cell only:** the endpoint checks this cell's own Postgres and Redis (plus Elasticsearch for NaukriNearby), not services every cell shares. Otherwise one shared outage takes every cell out of Cloudflare's pool at once.
- **Status codes:** it returns 200 when the cell can take traffic and 503 when it can't. Cloudflare's load balancer monitors only look at the status code and, optionally, a string in the response body. The body is short JSON like `{"status":"ok","cell":"<id>","checks":{...}}`.
- **Timeouts:** each check gets its own short timeout of about 500ms, they run in parallel, and the whole request finishes in under about 2s. That keeps it well inside Cloudflare's monitor timeout.
- **Draining:** a flag (an environment variable or a Redis key) makes the endpoint return 503 on purpose, so you can take a cell out of rotation without stopping it.
- **Security and caching:** no login is required, since Cloudflare's monitors can send custom headers but not do a full login. Optionally it accepts a shared-secret header, and it sends `Cache-Control: no-store`.

Tell me if you'd change any of that, for example if the cell should also count as unhealthy when a downstream service like the LLM provider is down.