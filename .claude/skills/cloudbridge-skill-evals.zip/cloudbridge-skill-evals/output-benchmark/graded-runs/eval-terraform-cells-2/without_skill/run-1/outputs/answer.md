I'd push back. Workspaces suit **identical infrastructure deployed more than once**, like the same stack in dev, staging and prod. AWS prod and GCP prod are two different stacks. Putting them in one folder doesn't remove duplication. It moves it into conditionals.

**Why it's a bad fit here:**

1. **Nothing is actually shared.** `aws_vpc` and `google_compute_network` have no common code. Everything ends up wrapped in `count = terraform.workspace == "aws-prod" ? 1 : 0` or `for_each` tricks. The code is harder to read, and none of it is reused.
2. **One backend for both clouds.** Every workspace uses the same backend block. Your GCP state would live in an S3 bucket, or your AWS state in GCS. Each cloud's state then depends on the other cloud being up and its credentials being valid.
3. **Both providers load every time.** Every plan configures the AWS and GCP providers. You need credentials for both even when you only touch one. That also makes least-privilege CI harder, since an AWS-only pipeline still needs GCP access.
4. **No separation of access or blast radius.** HashiCorp's docs say workspaces aren't meant for cases that need separate credentials and access controls. With directories, you can lock down who can apply to prod in each cloud separately. With workspaces, that's much harder.
5. **Easy to apply in the wrong workspace.** The selected workspace is hidden state on someone's machine. It doesn't show up in the code or the PR diff. A `terraform apply` with the wrong workspace selected is a well-known way to cause an incident.
6. **Provider and version upgrades become all-or-nothing.** You can't bump the AWS provider without also re-planning GCP prod.

**What to tell him instead:** you get DRY from **modules**, not workspaces.
- Keep `live/aws-prod/` and `live/gcp-prod/` as separate root modules, each with its own backend, providers and credentials.
- Put repeated patterns in `modules/`, for example `modules/aws/network` and `modules/gcp/network`, and call them from the `live/` folders.
- If the boilerplate in `live/` is what bothers him (backend blocks, provider config), Terragrunt or Terraform Stacks solve exactly that while keeping state separate.
- Workspaces would make sense if you later need identical copies of one stack, such as several regions or short-lived preview environments. Even then, a lot of teams keep prod in a dedicated directory.

**Short version for the chat:**
> Workspaces are for running the same config more than once with the same backend and providers. AWS and GCP share almost no code, so we'd get a pile of `terraform.workspace` conditionals, one state backend for both clouds, credentials for both clouds on every run, and a hidden "which workspace am I in" risk on prod. Let's keep separate `live/` roots and get the DRY from shared modules instead (or Terragrunt if the boilerplate is the real pain).