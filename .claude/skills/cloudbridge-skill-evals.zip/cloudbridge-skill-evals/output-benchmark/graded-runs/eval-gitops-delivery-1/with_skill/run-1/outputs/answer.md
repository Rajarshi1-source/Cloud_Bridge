I didn't find any repo files here (no `.github/workflows/`, `gitops/` or `tools/`). So this walkthrough and the YAML below come from the CloudBridge delivery reference files, not from your repo.

**One correction first:** `ring-promote.yml` doesn't open the canary PR. The canary PR is opened by the `promote-canary` job in `ci-app.yml`. `ring-promote.yml` runs later and opens the PR that sends the release to AWS (`ring-main`). Both are below.

## How the fix reaches each cluster

Releases go to one cloud at a time. GKE goes first because it's the smaller cell (30% of traffic). EKS gets the release only after it has proven healthy on GKE.

1. **Merge to `main`** touching `services/**` starts `ci-app.yml`. For each service it runs `./mvnw verify` (with Testcontainers), builds the image, pushes it to Docker Hub as `:<sha>`, scans it with Trivy, signs it by digest with cosign and saves the digest.
2. **`promote-canary` job** runs `bump_ring.py --ring ring-canary`, which writes the new digests into `gitops/releases/ring-canary.yaml`. It then opens the PR `release(canary): <sha> → GCP ring` with labels `release,ring-canary`.
3. **You merge that PR.** Argo CD in the GKE cell (`cb-gcp-prod`) follows `ring-canary.yaml`, so it syncs. Pods pull the image by digest through the Artifact Registry mirror (`asia-south1-docker.pkg.dev/.../dockerhub/...`), not from Docker Hub directly.
4. **Canary rollout inside GKE:** Argo Rollouts moves traffic 10% → analysis → 50% → 100%. The `cb-canary-health` check aborts if the error rate reaches 1% or p95 reaches 300 ms.
5. **When the Rollout is Healthy,** Argo CD notifications sends `repository_dispatch: canary-healthy`, which starts `ring-promote.yml`. It waits 30 minutes, then checks two things: SLO burn below 1, and GCP p95 within 10% of AWS p95.
6. **If both checks pass,** it copies the canary digests into `ring-main.yaml` and opens the PR `release(main): promote canary digests → AWS ring`.
7. **You merge that PR.** Argo CD in the EKS cell (`cb-aws-prod`) syncs and pulls through the ECR pull-through cache, then runs the same canary steps inside EKS.

**Rolling back** means `git revert` on the ring file; Argo CD then syncs the previous digest. Nobody runs `kubectl` or `helm upgrade` by hand. The parity check allows the two clouds to run different versions for at most 2 hours, so a canary stuck on GKE turns into a CI failure.

## The workflow that opens the canary PR: `.github/workflows/ci-app.yml`

```yaml
name: app
on:
  pull_request:
    paths: ["services/**"]
  push:
    branches: [main]
    paths: ["services/**"]

permissions:
  contents: write
  id-token: write
  pull-requests: write

concurrency:
  group: app-${{ github.ref }}
  cancel-in-progress: ${{ github.event_name == 'pull_request' }}

jobs:
  build:
    runs-on: ubuntu-24.04
    strategy:
      fail-fast: false
      matrix:
        service: [api-gateway, order-service, inventory-service]
    env:
      IMAGE: docker.io/${{ vars.DOCKERHUB_USER }}/cb-${{ matrix.service }}
    steps:
      - uses: actions/checkout@<sha>
      - uses: actions/setup-java@<sha>
        with:
          distribution: temurin
          java-version: "21"
          cache: maven
      - name: Unit + Testcontainers
        working-directory: services/${{ matrix.service }}
        run: ./mvnw -B verify
      - uses: docker/setup-buildx-action@<sha>
      - uses: docker/login-action@<sha>
        if: github.ref == 'refs/heads/main'
        with:
          username: ${{ vars.DOCKERHUB_USER }}
          password: ${{ secrets.DOCKERHUB_TOKEN }}
      - id: build
        uses: docker/build-push-action@<sha>
        with:
          context: services/${{ matrix.service }}
          load: ${{ github.ref != 'refs/heads/main' }}
          push: ${{ github.ref == 'refs/heads/main' }}
          tags: ${{ env.IMAGE }}:${{ github.sha }}
          provenance: mode=max
          sbom: true
          cache-from: type=gha,scope=${{ matrix.service }}
          cache-to: type=gha,mode=max,scope=${{ matrix.service }}
      - name: Trivy image scan
        uses: aquasecurity/trivy-action@<sha>
        with:
          image-ref: ${{ env.IMAGE }}:${{ github.sha }}
          severity: HIGH,CRITICAL
          ignore-unfixed: true
          exit-code: "1"
      - uses: sigstore/cosign-installer@<sha>
        if: github.ref == 'refs/heads/main'
      - name: Sign by digest (keyless)
        if: github.ref == 'refs/heads/main'
        run: cosign sign --yes "${IMAGE}@${{ steps.build.outputs.digest }}"
      - name: Save digest
        if: github.ref == 'refs/heads/main'
        run: echo "${{ matrix.service }}=${{ steps.build.outputs.digest }}" > digest-${{ matrix.service }}.env
      - uses: actions/upload-artifact@<sha>
        if: github.ref == 'refs/heads/main'
        with:
          name: digest-${{ matrix.service }}
          path: digest-${{ matrix.service }}.env

  promote-canary:
    needs: build
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-24.04
    steps:
      - uses: actions/checkout@<sha>
      - uses: actions/download-artifact@<sha>
        with:
          pattern: digest-*
          merge-multiple: true
      - run: cat digest-*.env > digests.env && pip install pyyaml && python3 tools/bump_ring.py --ring ring-canary --digests digests.env
        env:
          DOCKERHUB_USER: ${{ vars.DOCKERHUB_USER }}
      - uses: peter-evans/create-pull-request@<sha>
        with:
          branch: release/canary-${{ github.sha }}
          title: "release(canary): ${{ github.sha }} → GCP ring"
          labels: release,ring-canary
          commit-message: "release(canary): ${{ github.sha }}"
```

## The next step, which opens the PR for AWS: `.github/workflows/ring-promote.yml`

```yaml
name: ring-promote
on:
  repository_dispatch:
    types: [canary-healthy]      # sent by Argo CD notifications when the GCP Rollout is Healthy
  workflow_dispatch: {}

permissions:
  contents: write
  pull-requests: write

jobs:
  promote:
    runs-on: ubuntu-24.04
    steps:
      - uses: actions/checkout@<sha>
      - name: Soak 30 minutes
        run: sleep 1800
      - name: Gate on SLO burn and relative latency
        run: |
          q() { curl -fsS -G "${{ vars.CB_PROM_URL }}/api/v1/query" \
                 -H "Authorization: Bearer ${{ secrets.CB_PROM_TOKEN }}" --data-urlencode "query=$1" \
                 | jq -r '.data.result[0].value[1] // "0"'; }
          burn=$(q 'sum(rate(http_server_requests_seconds_count{cb_cell="cb-gcp-prod",service="api-gateway",status=~"5.."}[30m])) / sum(rate(http_server_requests_seconds_count{cb_cell="cb-gcp-prod",service="api-gateway"}[30m])) / 0.005')
          ratio=$(q 'cb:latency_p95:5m{cb_cell="cb-gcp-prod",service="api-gateway"} / cb:latency_p95:5m{cb_cell="cb-aws-prod",service="api-gateway"}')
          echo "burn=$burn ratio=$ratio"
          awk -v b="$burn" -v r="$ratio" 'BEGIN { exit !(b < 1 && r < 1.10) }'
      - run: pip install pyyaml && python3 tools/bump_ring.py --ring ring-main --from-ring ring-canary
        env:
          DOCKERHUB_USER: ${{ vars.DOCKERHUB_USER }}
      - uses: peter-evans/create-pull-request@<sha>
        with:
          branch: release/main-${{ github.run_id }}
          title: "release(main): promote canary digests → AWS ring"
          labels: release,ring-main
```

## Before you rely on this

- **Checks won't run on the bot PRs.** A PR opened with the default `GITHUB_TOKEN` doesn't trigger other workflows, so the parity check that should run on each PR never fires on the canary or AWS PR. Give `create-pull-request` a `token:` from a GitHub App.
- **A fix to order-service alone still rebuilds all three services.** The canary PR may then show new digests for api-gateway and inventory-service as well. If you want only order-service to change, add a `paths-filter` job (pinned by SHA) to skip the others.
- **The GKE check only covers order-service.** The 10/50/100 analysis checks order-service itself, but the 30-minute gate in `ring-promote.yml` only looks at `api-gateway`. That's fine if order traffic goes through the gateway; otherwise add an order-service query to the gate.
- **Pin every action.** Replace each `<sha>` with the full commit SHA of the action version you choose.
- **Check the database migration.** If the fix includes a Flyway migration, it must be compatible with the previous app version, because GKE and EKS run different versions for up to 2 hours.