I couldn't save any files. This session has no tool for writing files, and your repo isn't in this working directory, which only holds the `.claude/skills` folder. So the full setup is below to paste in. None of it has been run, linted or tested.

It's based on the `drift.yml` starter in the iac-pipeline skill, with these changes:

- **Finds every live stack automatically.** It scans `infra/live/*/*` instead of using a hard-coded list of five prod stacks, so dev stacks and new cells are picked up without editing the workflow.
- **Skips stacks with empty state.** Dev stacks the TTL reaper has destroyed won't raise a false drift report every night.
- **Keeps one issue per stack.** It opens the issue on drift, updates it only when the drift actually changes, and closes it when the stack is clean again. The starter would have opened a new issue every night, and its `--body "...\n..."` would have shown literal `\n` text.
- **Leaves values out of issues.** Issues list resource addresses, the action and the names of changed attributes, built from the plan JSON. The starter copied diff lines out of the plan text, which can include values.
- **Treats a failed plan as unchecked, not clean.** If a plan errors, the stack gets an issue labelled `drift-check-failed` and the run goes red.
- **Uses a separate read-only identity.** A new `drift` environment, limited to `main`, gets its own drift-only AWS role and GCP service account. The existing plan identities only trust `pull_request` runs, so the starter's scheduled job couldn't have logged in.

---

### 1. `tools/affected_stacks.py`: add `--all`

```python
    ap = argparse.ArgumentParser()
    ap.add_argument("--base")
    ap.add_argument("--all", action="store_true", help="every live stack, ignoring git (nightly drift)")
    ap.add_argument("--ordered", action="store_true")
    a = ap.parse_args()
    if a.all:
        print(json.dumps({"stacks": [describe(s) for s in stacks()]}, indent=2))
        return
    if not a.base:
        ap.error("--base is required unless --all is given")
```

### 2. `.github/workflows/drift.yml`

```yaml
name: drift
on:
  schedule:
    - cron: "0 21 * * *"        # 02:30 IST
  workflow_dispatch: {}

permissions:
  contents: read

concurrency:
  group: drift
  cancel-in-progress: false

jobs:
  discover:
    runs-on: ubuntu-24.04
    outputs:
      stacks: ${{ steps.s.outputs.stacks }}
    steps:
      - uses: actions/checkout@<sha>
      - id: s
        run: echo "stacks=$(python3 tools/affected_stacks.py --all | jq -c .stacks)" >> "$GITHUB_OUTPUT"

  plan:
    needs: discover
    runs-on: ubuntu-24.04
    environment: drift                 # no reviewers, deployment branches = main only; gives the OIDC sub environment:drift
    permissions:
      contents: read
      id-token: write
    timeout-minutes: 20
    strategy:
      fail-fast: false
      max-parallel: 4
      matrix:
        include: ${{ fromJson(needs.discover.outputs.stacks) }}
    defaults:
      run:
        working-directory: ${{ matrix.path }}
    steps:
      - uses: actions/checkout@<sha>
      - uses: hashicorp/setup-terraform@<sha>
        with:
          terraform_version: "1.15.x"
          terraform_wrapper: false

      # global/* stacks read both clouds' state (00-ci-identity manages both; 30-traffic reads cell remote state)
      - if: matrix.cloud == 'aws' || matrix.cloud == 'global'
        uses: aws-actions/configure-aws-credentials@<sha>
        with:
          role-to-assume: ${{ vars.AWS_DRIFT_ROLE }}
          aws-region: ap-south-1
      - if: matrix.cloud == 'gcp' || matrix.cloud == 'global'
        uses: google-github-actions/auth@<sha>
        with:
          workload_identity_provider: ${{ vars.GCP_WIF_PROVIDER }}
          service_account: ${{ vars.GCP_DRIFT_SA }}

      - id: p
        env:
          CLOUDFLARE_API_TOKEN: ${{ matrix.layer == 'traffic' && secrets.CLOUDFLARE_READ_TOKEN || '' }}
        run: |
          terraform init -input=false -lockfile=readonly
          if [ -z "$(terraform state list)" ]; then
            echo "status=not-deployed" >> "$GITHUB_OUTPUT"; exit 0      # reaped ephemeral stack
          fi
          set +e
          # -lock=false: read-only, never contends with a real apply. Plan text stays out of the log.
          terraform plan -input=false -lock=false -detailed-exitcode -out=drift.tfplan > /dev/null 2> plan.err
          code=$?
          set -e
          case $code in
            0) echo "status=clean" >> "$GITHUB_OUTPUT" ;;
            2) echo "status=drift" >> "$GITHUB_OUTPUT"; terraform show -json drift.tfplan > plan.json ;;
            *) echo "status=error" >> "$GITHUB_OUTPUT"; cat plan.err >&2 ;;
          esac
          rm -f drift.tfplan                                            # contains sensitive values

      - id: r
        if: steps.p.outputs.status == 'drift'
        run: |
          echo "fp=$(python3 "$GITHUB_WORKSPACE/tools/drift_report.py" plan.json report.md)" >> "$GITHUB_OUTPUT"
          rm -f plan.json

      - id: out
        if: always()
        env:
          STACK: ${{ matrix.path }}
          STATUS: ${{ steps.p.outputs.status }}
          FP: ${{ steps.r.outputs.fp }}
        working-directory: ${{ github.workspace }}
        run: |
          out="$RUNNER_TEMP/drift-out"; mkdir -p "$out"
          jq -n --arg stack "$STACK" --arg status "${STATUS:-error}" --arg fp "$FP" \
            '{stack: $stack, status: $status, fingerprint: $fp}' > "$out/status.json"
          [ -f "$STACK/report.md" ] && cp "$STACK/report.md" "$out/"
          echo "slug=${STACK//\//-}" >> "$GITHUB_OUTPUT"

      - if: always()
        uses: actions/upload-artifact@<sha>
        with:
          name: drift-${{ steps.out.outputs.slug }}
          path: ${{ runner.temp }}/drift-out
          retention-days: 7

  report:
    needs: [discover, plan]
    if: always() && needs.discover.result == 'success'
    runs-on: ubuntu-24.04
    permissions:
      contents: read
      issues: write
    steps:
      - uses: actions/checkout@<sha>
      - uses: actions/download-artifact@<sha>
        with:
          pattern: drift-*
          path: artifacts
      - env:
          GH_TOKEN: ${{ github.token }}
          STACKS: ${{ needs.discover.outputs.stacks }}
        run: |
          gh label create drift --color B60205 --description "Live infra differs from Terraform" --force
          gh label create drift-check-failed --color FBCA04 --description "Nightly drift plan could not run" --force
          python3 tools/drift_issues.py artifacts
```

### 3. `tools/drift_report.py`

```python
#!/usr/bin/env python3
"""Summarise a drift plan as Markdown: addresses, actions and changed attribute names, never values.

usage: drift_report.py plan.json report.md   (prints a fingerprint of the drift to stdout)
"""
import hashlib, json, sys

MAX = 60

def keys(change: dict) -> list[str]:
    before, after = change.get("before"), change.get("after")
    if not before or not after:
        return []                                   # created/deleted: whole resource
    unknown = change.get("after_unknown") or {}
    return sorted(k for k in set(before) | set(after)
                  if before.get(k) != after.get(k) or unknown.get(k) is True)

def row(rc: dict) -> str:
    ks = keys(rc["change"])
    return f"- `{rc['address']}` **{'/'.join(rc['change']['actions'])}** — {', '.join(ks) if ks else 'whole resource'}"

def section(title: str, rcs: list[dict]) -> list[str]:
    if not rcs:
        return []
    more = [f"- …and {len(rcs) - MAX} more"] if len(rcs) > MAX else []
    return [f"#### {title} ({len(rcs)})", "", *map(row, rcs[:MAX]), *more, ""]

def main(plan_path: str, out_path: str) -> None:
    plan = json.load(open(plan_path))
    drift = plan.get("resource_drift") or []
    pending = [rc for rc in plan.get("resource_changes") or []
               if set(rc["change"]["actions"]) - {"no-op", "read"}]
    outputs = sorted(k for k, c in (plan.get("output_changes") or {}).items() if c["actions"] != ["no-op"])

    md = section("Changed outside Terraform", drift) + section("Terraform would change", pending)
    if outputs:
        md += ["#### Outputs that would change", "", ", ".join(f"`{o}`" for o in outputs), ""]
    with open(out_path, "w") as f:
        f.write("\n".join(md))

    ident = sorted(f"{tag}|{rc['address']}|{','.join(rc['change']['actions'])}|{','.join(keys(rc['change']))}"
                   for tag, group in (("d", drift), ("p", pending)) for rc in group)
    print(hashlib.sha256("\n".join(ident + [f"o|{o}" for o in outputs]).encode()).hexdigest()[:16])

if __name__ == "__main__":
    main(*sys.argv[1:3])
```

### 4. `tools/drift_issues.py`

```python
#!/usr/bin/env python3
"""One open `drift` issue per stack: open it on drift, update it when the drift changes, close it when clean.

usage: STACKS='<json>' drift_issues.py <artifacts-dir>
"""
import json, os, pathlib, re, subprocess, sys

RUN_URL = f"{os.environ['GITHUB_SERVER_URL']}/{os.environ['GITHUB_REPOSITORY']}/actions/runs/{os.environ['GITHUB_RUN_ID']}"
MARK = re.compile(r"<!-- drift-fingerprint: (\S+) -->")

def gh(*args: str, body: str | None = None) -> str:
    return subprocess.run(["gh", *args], input=body, text=True, capture_output=True, check=True).stdout

def render(stack: str, fp: str, report: str) -> str:
    return (f"Stack: `{stack}`\nLatest run: {RUN_URL}\n\n"
            "The nightly plan found differences between Terraform and the real infrastructure.\n\n"
            f"{report}\n"
            "Resolve by codifying the change in a PR (keep it) or re-applying `main` (revert it).\n\n"
            f"<!-- drift-fingerprint: {fp} -->\n")

def render_error(stack: str) -> str:
    return (f"Stack: `{stack}`\nLatest run: {RUN_URL}\n\n"
            "The nightly drift plan **could not run**, so this stack's drift status is unknown. "
            "Treat it as unchecked, not clean. The error is in the run log.\n\n"
            "<!-- drift-fingerprint: error -->\n")

def main(root: pathlib.Path) -> int:
    stacks = json.loads(os.environ["STACKS"])
    issues = {i["title"]: i for i in json.loads(gh(
        "issue", "list", "--label", "drift", "--state", "open", "--limit", "200",
        "--json", "number,title,body,labels"))}
    rows, errors = [], 0

    for s in stacks:
        stack = s["path"]
        d = root / f"drift-{stack.replace('/', '-')}"
        st = json.loads((d / "status.json").read_text()) if (d / "status.json").exists() else {"status": "error"}
        status = st["status"]
        report = (d / "report.md").read_text() if (d / "report.md").exists() else ""
        issue = issues.get(f"drift: {stack}")
        num = str(issue["number"]) if issue else None
        labels = {l["name"] for l in issue["labels"]} if issue else set()
        rows.append(f"| `{stack}` | {status} |")

        if status == "not-deployed":
            continue
        if status == "clean":
            if issue:
                gh("issue", "close", num, "--comment", f"Clean as of {RUN_URL}. Closing.")
            continue
        if status == "error":
            errors += 1
            if not issue:
                gh("issue", "create", "--title", f"drift: {stack}", "--label", "drift,drift-check-failed",
                   "--body-file", "-", body=render_error(stack))
            elif "drift-check-failed" not in labels:
                gh("issue", "edit", num, "--add-label", "drift-check-failed")
                gh("issue", "comment", num, "--body", f"Drift plan failed in {RUN_URL}; status unknown.")
            continue

        fp = st.get("fingerprint") or "unknown"
        if not issue:
            gh("issue", "create", "--title", f"drift: {stack}", "--label", "drift",
               "--body-file", "-", body=render(stack, fp, report))
            continue
        if "drift-check-failed" in labels:
            gh("issue", "edit", num, "--remove-label", "drift-check-failed")
        m = MARK.search(issue["body"] or "")
        if m and m.group(1) == fp:
            continue                                   # same drift as last night: no new noise
        gh("issue", "edit", num, "--body-file", "-", body=render(stack, fp, report))
        gh("issue", "comment", num, "--body", f"Drift changed in {RUN_URL}. Description updated.")

    with open(os.environ["GITHUB_STEP_SUMMARY"], "a") as f:
        f.write("### Nightly drift\n\n| Stack | Status |\n|---|---|\n" + "\n".join(rows) + "\n")
    return 1 if errors else 0

if __name__ == "__main__":
    sys.exit(main(pathlib.Path(sys.argv[1])))
```

### 5. `infra/live/global/00-ci-identity`: drift identity

```hcl
# aws.tf: add to local.aws_roles
    "cb-drift-aws"      = "repo:${local.repo}:environment:drift"

# ReadOnlyAccess already covers s3:Get*/List* on the state bucket; with -lock=false no lock writes are needed
resource "aws_iam_role_policy_attachment" "drift_readonly" {
  role       = aws_iam_role.ci["cb-drift-aws"].name
  policy_arn = "arn:aws:iam::aws:policy/ReadOnlyAccess"
}

# and keep drift out of the read-write state policy:
resource "aws_iam_role_policy" "state" {
  for_each = { for k, v in local.aws_roles : k => v if k != "cb-drift-aws" }
  ...
}
```

```hcl
# gcp.tf: add to local.gcp_sas
    "cb-drift-gcp"      = "attribute.environment/drift"

resource "google_project_iam_member" "drift_viewer" {
  project = var.gcp_project_id
  role    = "roles/viewer"
  member  = "serviceAccount:${google_service_account.ci["cb-drift-gcp"].email}"
}

resource "google_storage_bucket_iam_member" "drift_state" {
  bucket = "cb-tfstate-gcp"
  role   = "roles/storage.objectViewer"          # roles/viewer does not include object reads
  member = "serviceAccount:${google_service_account.ci["cb-drift-gcp"].email}"
}
```

`00-ci-identity` is applied by a person, so these identity changes need a manual `terraform apply` by whoever does the bootstrap.

### 6. GitHub setup

- Create a `drift` environment with **no required reviewers** and deployment branches limited to **`main`**.
- Add these variables to the environment: `AWS_DRIFT_ROLE` (the `cb-drift-aws` ARN) and `GCP_DRIFT_SA` (the `cb-drift-gcp` email).
- Add a `CLOUDFLARE_READ_TOKEN` secret to the environment. It should be a Cloudflare token for that one zone with **read** access to Load Balancing only.
- `GCP_WIF_PROVIDER` is already a repo variable.

### Still needs work

- **`20-bootstrap` on managed cells will fail at first.** The Helm provider has to read Argo CD's release Secrets in the `argocd` namespace, and the new drift identity has no Kubernetes access yet. On EKS, add an access entry for `cb-drift-aws` with `AmazonEKSAdminViewPolicy` limited to the `argocd` namespace (in `modules/cluster/aws-eks`, next to the existing `ci` entry). On GKE, `roles/viewer` doesn't allow reading Secrets, so add a namespaced RBAC Role. Until then, those stacks will show up as `drift-check-failed` rather than passing silently. Your existing `cb-plan-aws` PR plans likely have the same gap: only the apply role has an EKS access entry.
- **`<sha>` placeholders:** pin each action to a full commit SHA, as the existing workflows do.

If you open this session inside the repo checkout, I can make these changes as edits and run `actionlint` and `terraform validate` on them.