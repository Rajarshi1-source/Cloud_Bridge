I couldn't set this up yet. The working directory (`/tmp/cbout-ohc7k9wz`) is empty, so I can't see any of your stacks or how they're deployed. This session also has no shell or file-writing tools, so I can't run `terraform`, `pulumi`, `aws` or `gcloud`, or add a workflow file.

To build it, I need:

1. **Your IaC tool:** Terraform/OpenTofu, Pulumi, CloudFormation/CDK, or something else.
2. **Where the stack code lives:** a repo URL, or open me in that checkout. That's also how I'll find which stacks are "live" (workspaces, stack configs, or a list you give me).
3. **What runs it nightly:** GitHub Actions, GitLab CI, a cron job, or Terraform Cloud/Spacelift's built-in drift detection. If you already use one of those, turning on its drift detection is usually the simplest option.
4. **Where alerts go:** Slack, email, a GitHub issue per drifted stack, etc.
5. **Cloud credentials for the job:** for example, OIDC to AWS or GCP. The job should get read-only or plan-only access.

Here's what I'd set up by default: a nightly scheduled job that runs plan/preview against each live stack in parallel. It would report a stack as drifted when plan exits with code 2 (`terraform plan -detailed-exitcode`), or the equivalent check for your tool. Each run would open or update one issue per drifted stack and close it once the stack is clean again. It would never apply changes on its own.

If you open me in the repo and point me at your stacks, I can write it from there.