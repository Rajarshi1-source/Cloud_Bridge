You can't have both clouds decrementing one shared number on their own without coordinating. What you can do is split the stock so each cloud owns a slice and can only sell from that slice. This is called **escrow**, or the demarcation protocol. Each cell sells against its own local allowance, and you rebalance between cells asynchronously, away from the checkout path.

## The core pattern: per-cell allocations

```
warehouse_on_hand(sku=123) = 100
  ├─ AWS allocation  = 60   (AWS may sell ≤ 60, no cross-cloud call)
  ├─ GCP allocation  = 35   (GCP may sell ≤ 35)
  └─ unallocated     = 5    (safety buffer / held by the inventory authority)
```

**Invariant:** `sum(allocations) + unallocated == on_hand`. No cell can sell more than its own allocation, so the total sold can never exceed what's on hand. You get that guarantee without a 2PC or a global lock.

**Checkout in a cell** is a single local, atomic, conditional decrement:

```sql
UPDATE cell_allocation
SET    available = available - :qty
WHERE  sku = :sku AND available >= :qty;
-- 0 rows affected → this cell is out; don't sell (or request more, see below)
```

The same works as a DynamoDB `ConditionExpression: available >= :qty`, a Spanner/Firestore transaction, or a Redis Lua script. It only has to be atomic inside one cell.

**Rebalancing** is a separate, asynchronous step:
- One **inventory authority** owns the true `on_hand` and the `unallocated` pool. Put it wherever the warehouse system (WMS) lives, or in one region.
- When a cell runs low (for example, `available < low_watermark`), it asks for more. The authority moves units from `unallocated` to that cell. Each grant is one local transaction at the authority, then an idempotent "grant" message to the cell.
- When a cell has excess and the other cell is starving, the authority asks the rich cell to **release** units. That cell decrements its own allocation locally first, then sends a "released" message. Only after the release arrives does the authority credit the pool. **Units move one way per step, and each step is debit first, then credit.** Because of that, a lost or delayed message can leave units stranded for a while, but it can never create extra stock.
- Use idempotent messages (a grant ID or sequence number per transfer) over an outbox or queue. Retries are then safe.

## The details that make it work

1. **Reserve, don't decrement, at cart or checkout.** Write a reservation with a TTL against the cell's allocation, and confirm it when payment succeeds. Expired reservations go back into the cell's local pool. Everything stays local.
2. **Warehouse changes go through the authority only.** Restocks, damage and cycle-count corrections update `on_hand`/`unallocated`. If a correction is negative and the pool can't absorb it, the authority asks cells to release units. In that case you may already have sold stock you don't have, which is a compensation case (see 5).
3. **Choose the split dynamically.** Allocate in proportion to each cell's recent sales rate, and keep a buffer. For SKUs with plenty of stock this almost never blocks anyone.
4. **Low stock is where the tradeoff shows.** With 3 units left split 2/1, a customer in GCP might see "sold out" while AWS still holds 2. Options:
   - **Spillover:** on a local miss, call the other cell synchronously and ask it to *sell on your behalf*, or to release a unit to you. This is a single-owner RPC, not a distributed transaction, and it only runs on the rare miss.
   - **Single-home the scarce SKUs:** below a threshold, the authority pulls the whole allocation into one cell, and all sales of that SKU route there (owner-per-SKU routing). Do this for hot or limited drops too.
5. **Have a compensation path anyway.** Physical reality (a miscount, a damaged item) will occasionally break the invariant, whatever your software does. Have a backorder/cancel/refund saga ready instead of trying to prevent it with locking.

## Alternatives, and when to use them

| Approach | Use when |
|---|---|
| **Escrow allocations (above)** | Default. Both cells sell everything, and checkout stays local. |
| **Single owner per SKU** (route writes to its home cell) | Low-volume or scarce SKUs. Simplest correct option, but you pay cross-cloud latency for non-home buyers. |
| **Bounded-counter CRDT** | Same idea as escrow, but cells trade "rights" peer to peer without a central authority. More complex, and rarely worth it with only 2 cells. |
| **Oversell + compensate** | Low-value goods where an occasional cancellation is cheaper than lost sales. |
| **Global DB (Spanner multi-region, CockroachDB)** | You accept one vendor's consensus on the write path. It isn't a hand-rolled distributed transaction, but every sale still pays cross-region latency, and with AWS + GCP you'd be running it across clouds. |

**My recommendation:** use escrow allocations, with an inventory authority co-located with the warehouse system. Rebalance asynchronously based on each cell's sales rate. Single-home any SKU that falls below a small threshold. That gives you "never oversell" from local atomic operations, with no cross-cloud call on the normal path.

If you tell me what datastore each cell uses and roughly how many units per SKU you hold, I can sketch the schema and the rebalancer loop.