Use **escrow leases**. Each cell sells only stock it has been given in advance. The two cells never coordinate on the request path, and their combined allowance can never be more than what's in the warehouse.

## How it works

**1. A control-plane allocator splits the stock into per-cell leases.**
Each cell gets a row per SKU:

| column | meaning |
|---|---|
| `granted_qty` | how many units this cell may sell |
| `sold_qty` | how many it has sold so far |
| `lease_epoch` | fencing token that increases with every grant or renewal |
| `expires_at` | now + 15 min |

The rule the allocator keeps is: **the sum of `granted_qty` across all cells ≤ warehouse stock.** For example, 100 units could go 70 to AWS and 30 to GCP, matching the traffic split, with some held back if you want a buffer.

**2. Inside a cell, a reservation is one atomic statement against that cell's own Postgres:**

```sql
UPDATE inventory.inventory_lease
   SET sold_qty = sold_qty + :qty
 WHERE sku = :sku
   AND expires_at > now()
   AND sold_qty + :qty <= granted_qty
RETURNING granted_qty - sold_qty AS remaining;
-- 0 rows → 409 OUT_OF_STOCK_IN_CELL
```

The application never reads the row and writes it back, so concurrent requests can't race each other. As a second guard, add `CHECK (sold_qty <= granted_qty)` on the table. The reservation insert and this decrement go in the same local transaction, with `reservation_id = Idempotency-Key` so a retried request doesn't sell twice.

**3. Cells renew asynchronously, off the request path.**
Every 5 minutes each cell calls `POST /admin/leases/renew` and reports its `sold_qty`. The allocator moves unsold stock toward whichever cell is selling faster and replies with a new grant and a **higher epoch**.

**4. Fencing stops a "zombie" cell.**
A cell might be cut off from the network or have a skewed clock. If its renewal or grant carries an **older epoch**, it is rejected, so it can't overwrite a newer allocation.

**5. Expired leases stop selling on their own.**
If a cell can't reach the allocator, its lease runs out and it stops selling that SKU without anyone telling it to. The allocator waits **`expires_at + 60 s`** before giving that unsold quantity to the other cell. The extra 60 seconds covers clock skew, so the two cells can never both believe they own the same units.

## The trade-off to state plainly

**It never oversells, but it can briefly undersell.** Stock granted to a cell you can't reach is stuck there for up to about 16 minutes. A customer routed to a cell whose lease has run out gets "out of stock in this cell" even if the other cell still has units. Mitigations:
- Size grants by recent sales rate, not just the traffic split.
- Renew more often for hot SKUs.
- Keep a small allocator reserve for top-ups.

For low-stock SKUs (for example, fewer than N units left), you can also give the whole quantity to one cell, so the last few units aren't split across both.

## How this fits the order flow

`POST /orders` with `Idempotency-Key` runs these steps:
1. Claim the key.
2. Reserve against the lease (step 2 above).
3. In one local transaction, commit the order and an outbox `order.created` event.

If the commit fails after the reservation succeeded, the reservation stays `HELD`. A reaper releases unconfirmed reservations after 15 minutes, and `order.created` confirms the ones that did go through. No step ever spans two databases or two clouds.

## Tests that prove it

- **Concurrency:** 50 parallel reservations against a lease of 20 → exactly 20 succeed (Testcontainers Postgres 18).
- **Fencing:** a renewal with epoch N−1 after epoch N has been granted → rejected.
- **Expiry:** after `expires_at`, the cell refuses sales for that SKU with no allocator contact.

**One-line version:** "Each cell sells from a fenced, expiring lease on its share of stock. The allocator never grants more than exists, so we may briefly undersell but we can never oversell, and nothing spans two clouds."

The full Flyway migration, the allocator's renew SQL and the Java `InventoryLeaseRepository` are in the skill's `references/` folder. I can scaffold them into `services/inventory-service` if you want.