I couldn't find your existing workflow here. This directory only has the `.claude/skills` files, and this session can't write files, so the complete files are below for you to add. I haven't run them; check the steps under "To switch over" before relying on them.

**What was wrong with the old job:**
- **Long-lived AWS keys.** One set of static keys could change everything.
- **`apply -auto-approve` makes a new plan when it runs.** It applies whatever the state looks like at that moment, not what anyone reviewed.
- **No approval step.**
- **No concurrency control**, so two merges can apply to the same state at once.

**How the new version works:**
- A read-only plan job saves `tfplan`, encrypts it and uploads it.
- A protected environment pauses the run until a reviewer approves the plan they can see.
- The apply job is the only thing that can assume the apply role. It decrypts the plan, checks its hash and runs `terraform apply tfplan`.
- If the state changed in between, the saved plan refuses to apply. That failure is the safety check working.

### `.github/workflows/_terraform-stack.yml`

```yaml
name: terraform-stack
on:
  workflow_call:
    inputs:
      stack: { type: string, required: true }   # e.g. infra/live/aws-prod/10-foundation
      cloud: { type: string, required: true }   # aws | gcp | global
      env:   { type: string, required: true }   # GitHub environment gating the apply, e.g. aws-prod
    outputs:
      changed:
        value: ${{ jobs.plan.outputs.changed }}

# One plan→apply per stack at a time; never cancel an apply mid-flight.
concurrency:
  group: tf-${{ inputs.stack }}
  cancel-in-progress: false

jobs:
  plan:
    runs-on: ubuntu-24.04
    permissions:
      contents: read
      id-token: write
    outputs:
      changed: ${{ steps.plan.outputs.changed }}
      sha256: ${{ steps.seal.outputs.sha256 }}
      artifact: ${{ steps.seal.outputs.artifact }}
    defaults:
      run:
        working-directory: ${{ inputs.stack }}
    steps:
      - uses: actions/checkout@<sha> # v5
        with:
          persist-credentials: false
      - uses: hashicorp/setup-terraform@<sha> # v3
        with:
          terraform_version: "1.15.x"
          terraform_wrapper: false

      # Read-only identities. No `environment:` here, so the OIDC sub is ref:refs/heads/main.
      - if: inputs.cloud == 'aws'
        uses: aws-actions/configure-aws-credentials@<sha> # v5
        with:
          role-to-assume: ${{ vars.AWS_PLAN_ROLE }}
          aws-region: ap-south-1
      - if: inputs.cloud != 'aws'
        uses: google-github-actions/auth@<sha> # v3
        with:
          workload_identity_provider: ${{ vars.GCP_WIF_PROVIDER }}
          service_account: ${{ vars.GCP_PLAN_SA }}

      - run: terraform init -input=false -lockfile=readonly

      - id: plan
        env:
          CLOUDFLARE_API_TOKEN: ${{ inputs.cloud == 'global' && secrets.CLOUDFLARE_READ_TOKEN || '' }}
        run: |
          set +e
          terraform plan -input=false -lock-timeout=5m -detailed-exitcode -out=tfplan
          code=$?
          set -e
          case $code in
            0) echo "changed=false" >> "$GITHUB_OUTPUT" ;;
            2) echo "changed=true"  >> "$GITHUB_OUTPUT" ;;
            *) exit "$code" ;;
          esac

      - name: Show the plan to the reviewer
        if: steps.plan.outputs.changed == 'true'
        run: |
          {
            echo "### \`${{ inputs.stack }}\` → \`${{ inputs.env }}\`"
            echo "Plan sha256: \`$(sha256sum tfplan | cut -d' ' -f1)\`"
            echo "<details><summary>Rendered plan (sensitive values masked)</summary>"
            echo; echo '```'
            terraform show -no-color tfplan
            echo '```'; echo "</details>"
          } >> "$GITHUB_STEP_SUMMARY"

      # Plan files contain secrets in clear text; artifacts are readable by anyone with repo read access.
      # Encrypt to a public key; only apply environments hold the private key.
      - id: seal
        if: steps.plan.outputs.changed == 'true'
        env:
          AGE_RECIPIENT: ${{ vars.TFPLAN_AGE_RECIPIENT }}
          STACK: ${{ inputs.stack }}
        run: |
          sudo apt-get install -y --no-install-recommends age >/dev/null
          echo "sha256=$(sha256sum tfplan | cut -d' ' -f1)" >> "$GITHUB_OUTPUT"
          echo "artifact=tfplan-${STACK//\//_}-${{ github.run_attempt }}" >> "$GITHUB_OUTPUT"
          age -r "$AGE_RECIPIENT" -o tfplan.age tfplan
          rm -f tfplan

      - if: steps.plan.outputs.changed == 'true'
        uses: actions/upload-artifact@<sha> # v4
        with:
          name: ${{ steps.seal.outputs.artifact }}
          path: ${{ inputs.stack }}/tfplan.age
          retention-days: 1
          if-no-files-found: error

  apply:
    needs: plan
    if: needs.plan.outputs.changed == 'true'    # no-op plans never ask for approval
    runs-on: ubuntu-24.04
    environment: ${{ inputs.env }}               # pauses here for required reviewers
    permissions:
      contents: read
      id-token: write
    defaults:
      run:
        working-directory: ${{ inputs.stack }}
    steps:
      - uses: actions/checkout@<sha> # v5
        with:
          persist-credentials: false
      - uses: hashicorp/setup-terraform@<sha> # v3
        with:
          terraform_version: "1.15.x"
          terraform_wrapper: false

      # Apply identities trust only sub = environment:<env>, i.e. only this job after approval.
      - if: inputs.cloud == 'aws'
        uses: aws-actions/configure-aws-credentials@<sha> # v5
        with:
          role-to-assume: ${{ vars.AWS_APPLY_ROLE }}      # environment-scoped variable
          aws-region: ap-south-1
      - if: inputs.cloud != 'aws'
        uses: google-github-actions/auth@<sha> # v3
        with:
          workload_identity_provider: ${{ vars.GCP_WIF_PROVIDER }}
          service_account: ${{ vars.GCP_APPLY_SA }}       # environment-scoped variable

      - uses: actions/download-artifact@<sha> # v4
        with:
          name: ${{ needs.plan.outputs.artifact }}
          path: ${{ inputs.stack }}

      - name: Decrypt and verify the reviewed plan
        env:
          AGE_IDENTITY: ${{ secrets.TFPLAN_AGE_IDENTITY }}  # environment secret
          EXPECTED: ${{ needs.plan.outputs.sha256 }}
        run: |
          sudo apt-get install -y --no-install-recommends age >/dev/null
          age -d -i <(printf '%s\n' "$AGE_IDENTITY") -o tfplan tfplan.age
          echo "$EXPECTED  tfplan" | sha256sum -c -

      - run: terraform init -input=false -lockfile=readonly

      - name: Apply exactly the reviewed plan
        env:
          CLOUDFLARE_API_TOKEN: ${{ secrets.CLOUDFLARE_API_TOKEN }}  # only exists in traffic-prod
        run: terraform apply -input=false -lock-timeout=5m tfplan
```

### `.github/workflows/iac-apply.yml`

```yaml
name: iac-apply
on:
  push:
    branches: [main]
    paths: ["infra/**"]

permissions:
  contents: read
  id-token: write

# Merges apply in order; merge B's foundation never runs between merge A's foundation and bootstrap.
concurrency:
  group: iac-apply-main
  cancel-in-progress: false

jobs:
  detect:
    runs-on: ubuntu-24.04
    outputs:
      layers: ${{ steps.a.outputs.layers }}
    steps:
      - uses: actions/checkout@<sha> # v5
        with:
          fetch-depth: 0
          persist-credentials: false
      - id: a
        env:
          BEFORE: ${{ github.event.before }}   # not HEAD~1: a rebase-merge pushes several commits
        run: |
          echo "layers=$(python3 tools/affected_stacks.py --base "$BEFORE" --ordered | jq -c '.layers')" >> "$GITHUB_OUTPUT"

  foundation:
    needs: detect
    if: fromJson(needs.detect.outputs.layers).foundation[0] != null
    strategy:
      max-parallel: 1        # gcp before aws: smaller cell first
      matrix:
        include: ${{ fromJson(needs.detect.outputs.layers).foundation }}
    uses: ./.github/workflows/_terraform-stack.yml
    with:
      stack: ${{ matrix.path }}
      cloud: ${{ matrix.cloud }}
      env: ${{ matrix.env }}
    secrets: inherit

  bootstrap:
    needs: [detect, foundation]
    if: always() && !failure() && !cancelled() && fromJson(needs.detect.outputs.layers).bootstrap[0] != null
    strategy:
      max-parallel: 1
      matrix:
        include: ${{ fromJson(needs.detect.outputs.layers).bootstrap }}
    uses: ./.github/workflows/_terraform-stack.yml
    with:
      stack: ${{ matrix.path }}
      cloud: ${{ matrix.cloud }}
      env: ${{ matrix.env }}
    secrets: inherit

  traffic:
    needs: [detect, bootstrap]
    if: always() && !failure() && !cancelled() && fromJson(needs.detect.outputs.layers).traffic[0] != null
    uses: ./.github/workflows/_terraform-stack.yml
    with:
      stack: infra/live/global/30-traffic
      cloud: global
      env: traffic-prod
    secrets: inherit
```

`tools/affected_stacks.py` is the version in the skill's `references/starter-code.md`. It never returns `global/00-ci-identity` as a layer, so the stack that creates the CI identities is never applied by CI.

### Identity changes (`infra/live/global/00-ci-identity`)

The plan job now runs on a push to main without an environment, so the plan identities also need to trust that:

```hcl
# aws.tf
locals {
  aws_roles = {
    "cb-plan-aws"       = ["repo:${local.repo}:pull_request", "repo:${local.repo}:ref:refs/heads/main"]
    "cb-apply-aws-prod" = ["repo:${local.repo}:environment:aws-prod"]
    "cb-apply-aws-dev"  = ["repo:${local.repo}:environment:aws-dev"]
  }
}
# in data.aws_iam_policy_document.trust, sub condition:
#   values = each.value
```

```hcl
# gcp.tf: add to attribute_mapping
    "attribute.ref" = "assertion.ref"

locals {
  gcp_bindings = {
    plan-pr      = { sa = "cb-plan-gcp",       principal = "attribute.event_name/pull_request" }
    plan-main    = { sa = "cb-plan-gcp",       principal = "attribute.ref/refs/heads/main" }
    apply-prod   = { sa = "cb-apply-gcp-prod", principal = "attribute.environment/gcp-prod" }
    traffic-prod = { sa = "cb-apply-traffic",  principal = "attribute.environment/traffic-prod" }
  }
}

resource "google_service_account_iam_member" "wif" {
  for_each           = local.gcp_bindings
  service_account_id = google_service_account.ci[each.value.sa].name
  role               = "roles/iam.workloadIdentityUser"
  member             = "principalSet://iam.googleapis.com/${google_iam_workload_identity_pool.gh.name}/${each.value.principal}"
}
```
(`google_service_account.ci` now needs its own `for_each` over the three account names.)

A person applies this stack once with their own credentials. CI never applies it.

### To switch over
1. **Pin every `@<sha>`** to a full commit SHA. I couldn't look them up from here; `pinact` or Dependabot can fill them in. Then add `iac-pr.yml` as a required status check so main only receives plans that passed the plan-risk and policy gates.
2. **Create a key pair** with `age-keygen`:
   - The public key goes in the repo variable `TFPLAN_AGE_RECIPIENT`.
   - The private key goes in the environment secret `TFPLAN_AGE_IDENTITY` in every apply environment.
3. **Set repo-level values:**
   - Variables: `AWS_PLAN_ROLE`, `GCP_WIF_PROVIDER`, `GCP_PLAN_SA`.
   - Secret: `CLOUDFLARE_READ_TOKEN`.
4. **Configure the environments** (`aws-prod`, `gcp-prod`, `traffic-prod`, and the dev ones):
   - Set the apply identity as an environment variable: `AWS_APPLY_ROLE` or `GCP_APPLY_SA`.
   - Turn on required reviewers and "prevent self-review", allow deployments from `main` only, and stop admins from bypassing.
   - Dev environments can skip reviewers.
   - Put `CLOUDFLARE_API_TOKEN` (scoped to one zone's Load Balancing) only in `traffic-prod`.
5. **Retire the old keys.** After the first successful run, delete `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY` from the repo secrets, then deactivate and delete that IAM user's access keys.

**What reviewers see:** the approval prompt links to the run. The plan job's summary shows the rendered diff and its sha256, and the apply job checks that same hash before applying. If another merge changes the state while an approval is pending, the apply fails with "Saved plan is stale". Re-run the workflow.

**Optional extra lock-down:** customise the GitHub OIDC `sub` claim to include `job_workflow_ref`. The apply roles could then be assumed only from `_terraform-stack.yml` on main, not just from any job in the environment.