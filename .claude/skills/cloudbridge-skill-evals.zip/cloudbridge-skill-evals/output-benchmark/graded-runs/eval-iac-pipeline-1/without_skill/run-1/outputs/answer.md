I couldn't find your existing workflow (the working directory is empty) and I can't write files in this session, so here is a complete replacement to drop into `.github/workflows/terraform.yml`. It assumes your Terraform lives in `infra/`. Change `TF_DIR` if it doesn't.

## What changes

| Before | After |
|---|---|
| Long-lived AWS keys stored in GitHub secrets | GitHub's OIDC (short-lived login tokens) gives each job temporary AWS credentials. No stored keys. |
| One set of permissions for everything | Two IAM roles: a **read-only plan role** and an **apply role** that only the `production` environment can use |
| `apply -auto-approve` runs on whatever main looks like at that moment | The **saved plan file** is applied, after a human approves it. Terraform refuses to apply a plan if the state has changed since it was made. |
| Nobody sees the plan first | The plan is posted as a PR comment and in the run summary, so the approver reads exactly what will be applied |
| Applies can overlap | One global concurrency group; runs on main are never cancelled mid-apply |
| Unpinned Terraform/providers | Pinned Terraform version, `-lockfile=readonly`, and `fmt`/`validate` checks |

## `.github/workflows/terraform.yml`

```yaml
name: terraform

on:
  pull_request:
    branches: [main]
    paths: ["infra/**", ".github/workflows/terraform.yml"]
  push:
    branches: [main]
    paths: ["infra/**", ".github/workflows/terraform.yml"]
  workflow_dispatch:

permissions:
  contents: read

# PR plans run per PR and can be cancelled. Main runs share one group and are
# never cancelled, so only one apply can happen at a time.
concurrency:
  group: terraform-${{ github.event_name == 'pull_request' && github.ref || 'main' }}
  cancel-in-progress: ${{ github.event_name == 'pull_request' }}

env:
  TF_DIR: infra
  TF_VERSION: "1.9.8"          # set to the version you actually use
  AWS_REGION: us-east-1
  TF_IN_AUTOMATION: "true"
  TF_INPUT: "false"

jobs:
  plan:
    runs-on: ubuntu-latest
    permissions:
      contents: read
      id-token: write          # OIDC
      pull-requests: write     # plan comment
    outputs:
      has_changes: ${{ steps.plan.outputs.has_changes }}
    defaults:
      run:
        working-directory: ${{ env.TF_DIR }}
    steps:
      - uses: actions/checkout@v4

      - uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: ${{ vars.AWS_PLAN_ROLE_ARN }}
          role-session-name: tf-plan-${{ github.run_id }}
          aws-region: ${{ env.AWS_REGION }}

      - uses: hashicorp/setup-terraform@v3
        with:
          terraform_version: ${{ env.TF_VERSION }}
          terraform_wrapper: false

      - run: terraform fmt -check -recursive
      - run: terraform init -lockfile=readonly
      - run: terraform validate -no-color

      - id: plan
        shell: bash
        run: |
          set +e
          terraform plan -lock-timeout=5m -no-color -detailed-exitcode -out=tfplan 2>&1 | tee plan.txt
          ec=${PIPESTATUS[0]}
          set -e
          if   [ "$ec" -eq 0 ]; then echo "has_changes=false" >> "$GITHUB_OUTPUT"
          elif [ "$ec" -eq 2 ]; then echo "has_changes=true"  >> "$GITHUB_OUTPUT"
          else exit "$ec"; fi

      - name: Plan summary
        if: always() && steps.plan.outcome != 'skipped'
        run: |
          {
            echo '### Terraform plan'
            echo '```'
            tail -c 60000 plan.txt
            echo '```'
          } >> "$GITHUB_STEP_SUMMARY"

      - name: Comment plan on PR
        if: github.event_name == 'pull_request'
        uses: actions/github-script@v7
        with:
          script: |
            const fs = require('fs');
            const plan = fs.readFileSync(`${process.env.TF_DIR}/plan.txt`, 'utf8');
            const body = [
              '<!-- tf-plan -->',
              '### Terraform plan',
              `Changes: **${{ steps.plan.outputs.has_changes }}**`,
              '<details><summary>Show plan</summary>',
              '', '```', plan.slice(-60000), '```', '</details>',
            ].join('\n');
            const { owner, repo } = context.repo;
            const issue_number = context.issue.number;
            const comments = await github.paginate(github.rest.issues.listComments, { owner, repo, issue_number });
            const prev = comments.find(c => c.body.startsWith('<!-- tf-plan -->'));
            if (prev) await github.rest.issues.updateComment({ owner, repo, comment_id: prev.id, body });
            else      await github.rest.issues.createComment({ owner, repo, issue_number, body });

      - name: Upload plan
        if: github.event_name != 'pull_request' && steps.plan.outputs.has_changes == 'true'
        uses: actions/upload-artifact@v4
        with:
          name: tfplan
          path: ${{ env.TF_DIR }}/tfplan
          retention-days: 3

  apply:
    needs: plan
    if: >-
      github.event_name != 'pull_request' &&
      github.ref == 'refs/heads/main' &&
      needs.plan.outputs.has_changes == 'true'
    runs-on: ubuntu-latest
    environment: production    # required reviewers decide here
    permissions:
      contents: read
      id-token: write
    defaults:
      run:
        working-directory: ${{ env.TF_DIR }}
    steps:
      - uses: actions/checkout@v4   # same commit as the plan job

      - uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: ${{ vars.AWS_APPLY_ROLE_ARN }}
          role-session-name: tf-apply-${{ github.run_id }}
          aws-region: ${{ env.AWS_REGION }}

      - uses: hashicorp/setup-terraform@v3
        with:
          terraform_version: ${{ env.TF_VERSION }}
          terraform_wrapper: false

      - run: terraform init -lockfile=readonly

      - uses: actions/download-artifact@v4
        with:
          name: tfplan
          path: ${{ env.TF_DIR }}

      # Applying a saved plan needs no -auto-approve. It applies exactly what
      # was reviewed, and fails if the state changed since the plan was made.
      - run: terraform apply -lock-timeout=5m -no-color tfplan
```

## AWS setup

1. **Register GitHub as a login provider in IAM** (one time per account). Provider URL: `token.actions.githubusercontent.com`, audience: `sts.amazonaws.com`.

2. **Plan role trust policy.** It can only be used by PRs and by main:
   ```json
   {
     "Effect": "Allow",
     "Principal": { "Federated": "arn:aws:iam::ACCOUNT:oidc-provider/token.actions.githubusercontent.com" },
     "Action": "sts:AssumeRoleWithWebIdentity",
     "Condition": {
       "StringEquals": { "token.actions.githubusercontent.com:aud": "sts.amazonaws.com" },
       "StringLike": { "token.actions.githubusercontent.com:sub": [
         "repo:ORG/REPO:pull_request",
         "repo:ORG/REPO:ref:refs/heads/main"
       ]}
     }
   }
   ```
   Permissions: read-only access to your resources, plus access to the state bucket (and the lock table, if you use one). **Keep this role truly read-only.** Anyone who can open a PR can edit this workflow or add an `external` data source and run any code they like with these credentials.

3. **Apply role trust policy.** It can only be used by the `production` environment:
   ```json
   "StringEquals": {
     "token.actions.githubusercontent.com:aud": "sts.amazonaws.com",
     "token.actions.githubusercontent.com:sub": "repo:ORG/REPO:environment:production"
   }
   ```
   Give it the permissions your current access-key user has, then cut them down over time.

## GitHub setup

- **Settings → Environments → `production`:**
  - Add required reviewers and turn on "Prevent self-review".
  - Under deployment branches, allow **`main` only**. Otherwise a workflow on a PR branch could request the environment and get the apply role.
- **Repo variables** (`vars`, not secrets): `AWS_PLAN_ROLE_ARN` and `AWS_APPLY_ROLE_ARN`.
- **Branch protection on `main`:** require the `plan` check and a review.
- **After the first successful apply,** delete the `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY` secrets, then deactivate and delete that IAM user's keys.

## Things to know

- **Plan files can contain secrets in plain text.** Anyone with read access to the repo can download workflow artifacts, which is why retention is set to 3 days. If that's not acceptable, encrypt the plan before uploading it, or store it in a locked-down S3 bucket instead.
- **Pin the actions to commit SHAs.** I used version tags (`@v4`) because I can't look up the current SHAs from here. Swap in the SHAs, or let Dependabot or Renovate manage them.
- **PRs from forks won't get a plan.** GitHub doesn't give them OIDC tokens. That's the safe default, so don't work around it with `pull_request_target`.
- **One extra plan is skipped:** if a merge produces no changes, the apply job doesn't run and nobody is asked to approve.

I haven't run any of this, since there was no repo or AWS account here to test against. If you paste your current workflow and backend config, I can adapt this to your directory layout, multiple environments, or state-locking setup.