I can't create files here: the working directory is empty and I only have read and search tools in this session. Below is the implementation. I wrote it for Express + Postgres in TypeScript because you didn't name a stack; tell me yours and I'll port it.

## How it works

When Cloudflare retries, it sends the same request again, headers included. So the client sends an `Idempotency-Key` header with each order, and the server records that key in the same database transaction that creates the order. A retry with the same key gets the original response back instead of creating a second order.

```sql
CREATE TABLE idempotency_keys (
  account_id      bigint      NOT NULL,
  key             text        NOT NULL,
  request_hash    text        NOT NULL,
  response_status int,
  response_body   jsonb,
  created_at      timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (account_id, key)
);
-- Cleanup job: DELETE FROM idempotency_keys WHERE created_at < now() - interval '24 hours';
```

```ts
import express from "express";
import crypto from "node:crypto";
import { pool } from "./db";

export const router = express.Router();

router.post("/orders", async (req, res, next) => {
  const key = req.get("Idempotency-Key");
  if (!key || key.length > 255) {
    return res.status(400).json({ error: "Idempotency-Key header is required" });
  }

  const accountId = req.user.id; // keys are scoped per caller
  // Retries are byte-identical, so the same body always gives the same hash
  const requestHash = crypto.createHash("sha256").update(JSON.stringify(req.body)).digest("hex");

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    // If another request with this key is still in progress, this INSERT waits on the
    // unique index until that request commits (→ 0 rows) or rolls back (→ we claim the key).
    const claim = await client.query(
      `INSERT INTO idempotency_keys (account_id, key, request_hash)
       VALUES ($1, $2, $3)
       ON CONFLICT (account_id, key) DO NOTHING
       RETURNING 1`,
      [accountId, key, requestHash],
    );

    if (claim.rowCount === 0) {
      await client.query("ROLLBACK");
      const { rows: [prior] } = await client.query(
        `SELECT request_hash, response_status, response_body
           FROM idempotency_keys WHERE account_id = $1 AND key = $2`,
        [accountId, key],
      );
      if (prior.request_hash !== requestHash) {
        return res.status(422).json({ error: "Idempotency-Key was reused with a different request body" });
      }
      return res.status(prior.response_status).set("Idempotent-Replayed", "true").json(prior.response_body);
    }

    const { rows: [order] } = await client.query(
      `INSERT INTO orders (account_id, items, total_cents)
       VALUES ($1, $2, $3) RETURNING *`,
      [accountId, JSON.stringify(req.body.items), req.body.total_cents],
    );

    await client.query(
      `UPDATE idempotency_keys SET response_status = 201, response_body = $3
        WHERE account_id = $1 AND key = $2`,
      [accountId, key, order],
    );

    await client.query("COMMIT");
    res.status(201).json(order);
  } catch (err) {
    await client.query("ROLLBACK").catch(() => {});
    next(err);
  } finally {
    client.release();
  }
});
```

## Why this holds up during a failover

- **Both requests arrive at once:** this is the usual case. The original request is still running on the old server when the retry reaches the new one. The retry's `INSERT` waits on the primary-key lock, then returns the stored response. No extra "in progress" state or 409 handling is needed.
- **The original request dies partway through:** its transaction rolls back and the key is released, so the retry creates the order normally. You never end up with a key saved but no order.
- **Same key, different body:** the server returns 422. This catches client bugs instead of quietly replaying the wrong order.

## Things this relies on

1. **The client must send a key** that it generates once per checkout (a UUID) and reuses on its own retries. Without one, the server can't tell a retry from a genuine second order, so the header is required here.
2. **All servers must use the same database.** If each region has its own writable Postgres (active-active), this check doesn't protect you. The key has to live somewhere every region agrees on.
3. **Side effects outside the database aren't covered.** If creating an order also charges a card or calls another service, pass the same idempotency key to that service (Stripe accepts one, for example). Or move those calls into an outbox processed after commit. This transaction can't undo an external call.

If you tell me your framework and database, or put the project files in this directory, I'll fit this to your actual code.