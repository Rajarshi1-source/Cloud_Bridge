I can't see any of your config. This directory is empty, so the steps below are generic and you'll need to fill in your own names. **The main rule: change routing directly at the DNS or load-balancer level, not through Terraform.** Your state bucket is down, and running `terraform apply` without state could try to recreate or destroy resources.

## 1. Decide where you make the switch (about 30 seconds)
Ask yourself: **who serves your public DNS?**
- **Cloudflare, NS1 or another DNS provider outside AWS** → best case. Go to step 2a.
- **Route 53** → its data plane usually keeps answering during AWS incidents, but its control plane (where you make changes) runs in us-east-1 and can fail. Try 2b. If changes won't go through, use health-check failover if you set it up in advance.
- **Cloudflare or another proxy/CDN in front** → change the origin, not DNS. This also avoids waiting for TTLs to expire.

## 2. Check that GCP can take the traffic before you send it
```bash
gcloud config set project <PROJECT>
gcloud compute forwarding-rules list            # get the GCP LB IP
gcloud compute backend-services get-health <BACKEND> --global
curl -sv --resolve app.example.com:443:<GCP_LB_IP> https://app.example.com/healthz
```
Also scale GCP up now, so the traffic doesn't flatten it:
```bash
gcloud compute instance-groups managed resize <MIG> --size=<N> --region=<REGION>
# or GKE:
kubectl scale deploy/<app> --replicas=<N>
gcloud run services update <svc> --min-instances=<N> --region=<REGION>
```

## 3. Move the traffic
**2a. Cloudflare:**
```bash
curl -X PATCH "https://api.cloudflare.com/client/v4/zones/$ZONE/dns_records/$REC" \
  -H "Authorization: Bearer $CF_TOKEN" -H "Content-Type: application/json" \
  --data '{"content":"<GCP_LB_IP>","ttl":60}'
```
If you use a Cloudflare load balancer, disable the AWS pool or set its weight to 0 instead.

**2b. Route 53:**
```bash
aws route53 change-resource-record-sets --hosted-zone-id <ZONE> --change-batch '{
 "Changes":[{"Action":"UPSERT","ResourceRecordSet":{
  "Name":"app.example.com","Type":"A","TTL":60,
  "ResourceRecords":[{"Value":"<GCP_LB_IP>"}]}}]}'
```
If you use weighted or failover records, set the AWS weight to 0 rather than replacing the record.

**Cloud DNS (if your zone lives in GCP):**
```bash
gcloud dns record-sets update app.example.com. --zone=<ZONE> --type=A --ttl=60 --rrdatas=<GCP_LB_IP>
```

## 4. Watch out for these
- **Data layer:** is your primary database in AWS? If so, GCP apps may be up but unable to write. Promote the GCP replica only if you accept the lost-replication risk, and make sure AWS can't keep accepting writes at the same time (split-brain).
- **Secrets and config** that GCP pulls from AWS (Secrets Manager, S3, SSM) will fail, so check the GCP app logs right away.
- **TTL:** clients cache the old record for its previous TTL. Lowering it now only helps future changes.
- **Terraform drift:** write down every manual change. When the state bucket is back, run `terraform plan` and fix the drift with `-refresh-only` or code changes before anyone runs `apply`.

## 5. Check that it worked
```bash
dig +short app.example.com @1.1.1.1
dig +short app.example.com @8.8.8.8
```
Then watch the GCP LB request rate and error rates in Cloud Monitoring.

**Tell me three things and I'll give you the exact commands:** your DNS provider, what runs on GCP (GKE, Cloud Run or VMs), and where your database primary is. I have `gcloud` here and can help check the GCP side directly if you give me the project ID.