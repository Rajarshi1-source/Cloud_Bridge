You can't use Terraform right now because the traffic stack's state lives in GCS. Use the break-glass script instead: it changes the Cloudflare pool weights through the API. This is the one sanctioned way around IaC, and it's meant for exactly this situation.

## 0. Check whether Cloudflare has already moved traffic (30 seconds)
If AWS's `/healthz/cell` is failing, the health monitor marks the AWS pool unhealthy after about 2–3 minutes (60 s interval × 2 retries). Sticky failover then moves sessions to GCP, so most traffic may already be there. Look at the dashboard's "configured vs observed" panel, or `cb_cf_pool_requests_total{pool="gcp"}`. Break-glass is still worth running: it stops traffic from returning to AWS if AWS recovers only partly.

## 1. Check that GCP can take 100%
Normally `evacuate.yml` does a capacity check first. Break-glass skips it, so check by hand. GCP usually carries 30%, and tripling its load on a cold node pool can take it down too. At minimum, make sure the HPA max and node pool have room, and scale up now if you can.

## 2. Get the IDs without Terraform
The script expects pool IDs from `terraform output pool_ids`, which you can't read with GCS down. Get them from Cloudflare instead:

```bash
export CF_API_TOKEN=...   # LB-scoped break-glass token
export CF_ZONE_ID=...
# LB id + its pool ids
curl -s -H "Authorization: Bearer $CF_API_TOKEN" \
  "https://api.cloudflare.com/client/v4/zones/$CF_ZONE_ID/load_balancers" \
  | jq '.result[] | {id, name, default_pools, fallback_pool, random_steering}'
# map pool ids -> names (aws / gcp)
curl -s -H "Authorization: Bearer $CF_API_TOKEN" \
  "https://api.cloudflare.com/client/v4/accounts/$CF_ACCOUNT_ID/load_balancers/pools" \
  | jq '.result[] | {id, name}'
```

## 3. Shift the traffic
```bash
export CF_LB_ID=<lb id>
export CF_POOL_IDS='{"aws":"<aws pool id>","gcp":"<gcp pool id>"}'
export CB_CP_API=... CB_CP_TOKEN=...   # control plane, for the audit record

python3 tools/cf_break_glass.py --weights aws=0,gcp=100 \
  --reason "AWS outage + GCS state backend unreachable"
```
The load balancer is proxied, so the change takes effect at the edge within seconds. If the control-plane API is down too, the script still applies the change. It prints a warning, and you'll need to record the change by hand later.

## 4. Afterwards (required)
- Record the change as `traffic_changes` with `source = break_glass` if the script couldn't, and open a priority issue.
- Once GCS is reachable, commit `{"weights": {"aws": 0, "gcp": 100}}` to `infra/live/global/30-traffic/terraform.tfvars.json`. Then `terraform plan` should show no drift, which proves the code matches what's live.
- When you're ready to move traffic back, run the normal failback playbook rather than break-glass.

**Caveats:**
- Users whose sessions are pinned to AWS will lose sight of any orders written to the AWS database until failback, because each cell has its own database.
- I couldn't find `tools/cf_break_glass.py` in the current directory, so run this from your CloudBridge repo checkout.
- I haven't run anything against your Cloudflare account.