I couldn't make the fix. There's no `shapes.tf` in `/tmp/cbout-p7u1ckh9`: this directory only has the `.claude/skills/` docs, and no `infra/` tree. I also have no file-editing tool in this session. Below is the change to make and what it affects. Point me at the real repo, or apply the change yourself.

## The fix

You're right about the bug, and it's worse than double the hardware. `t3.large` is 2 vCPU / 8 GiB and burstable. `e2-standard-4` is 4 vCPU / 16 GiB and general-purpose. So the CPU class differs as well as the size.

The reference `shapes.tf` (from the project's starter code) has the corrected row:

```hcl
# infra/modules/cell/shapes.tf
standard = { aws = "m6i.large", gcp = "n2-standard-2", vcpu = 2, mem_gib = 8, class = "general-purpose" }
```

Change only the AWS side to `m6i.large` if you'd rather keep GCP cost data. Changing only the GCP side to `e2-standard-2` would still leave a burstable vs general-purpose mismatch. My recommendation is the full pair above.

## Why nothing caught it

This is the bigger problem. Both checks read the table's **declared** `vcpu`/`mem_gib`/`class` values, not the real instance type:

- The contract test's `shape_parity_standard` run asserts `output.cell.shape.vcpu == 2 && mem_gib == 8`. That passes for any row labelled 2/8, whatever the instance strings are.
- The parity checker's `fact_cell_shape()` returns `tf["cell"]["shape"]`, which is the same self-reported values.

A row like `{aws="t3.large", gcp="e2-standard-4", vcpu=2, mem_gib=8}` passes both. Add a static map from instance type to real specs (e.g. `m6i.large → 2/8/gp`, `n2-standard-2 → 2/8/gp`), and assert that both columns of every row match it. Better still, make the parity adapters read the real machine type from EC2/GCE instead of from Terraform outputs.

## What this affects

1. **The 40% figure: stop quoting it.** Every GCP cell on `standard` had twice the vCPU and memory. Two effects pull in opposite directions:
   - The GCP node cost was inflated.
   - The extra capacity probably lowered GCP latency, and maybe its node count.

   The result also depends on whether the dashboard compares totals or cost per 1k requests. Totals under a 70/30 split mostly measure the traffic split. Either way, the number can't be corrected after the fact. It has to be re-measured.
2. **Cost ledger and dashboard.** Mark every ledger row from `standard` cells before the fix date as unequal-shape, or exclude it. Only count data from after the apply, over the same window on both clouds. Billing exports lag 1–2 days, so expect a gap before comparable numbers exist.
3. **Steering recommender.** It fits fixed and per-request cost over a 28-day window and needs at least 21 days of history. Every window that includes pre-fix data is contaminated. Don't merge any open `traffic:recommender` PR that's based on it. The recommender should report "insufficient data" for about 3 weeks after the fix.
4. **Capacity and latency models.** The `capacity.yaml` numbers measured with k6 for the GCP cell came from 4 vCPU nodes, so GCP's capacity is overstated by about 2× on the new shape. Re-run k6 on both cells after the fix. The recommender uses these figures for its headroom and latency limits, and Ansible uses them for its evacuation capacity checks. A stale GCP figure could let a drill or a weight shift overload the GCP cell.
5. **HPA and node sizing.** If HPA max replicas or node limits were tuned on the 16 GiB GCP nodes, they may not fit on 8 GiB nodes. Check pod packing before you apply.
6. **The apply itself.** Changing the instance type replaces the node pool or VM on each affected cell, so it's disruptive. Roll it out one cloud at a time, and consider draining traffic away from the cell being changed first.
7. **Records.** Changing a shape row is a cost-comparison event. Record it in the parity history and add a dashboard annotation so the before/after break is visible.