I couldn't create any files: this session has no tool for writing files or running commands, and the working directory has no `ansible/` tree or Terraform code yet. Below is the complete role and its supporting files to paste in. **Nothing has been linted, tested with Molecule or run against a VM.**

**How the "no SSH from the internet" part works:**
- **EC2:** Ansible connects through AWS SSM Session Manager. Nothing needs to listen on the internet.
- **GCE:** Ansible uses SSH, but only through an IAP tunnel, and logs in with OS Login.
- **Safety check:** the playbook stops before touching any host whose connection isn't SSM or IAP, so it can't quietly fall back to plain SSH to a public IP.
- **Firewall rules belong in Terraform.** The prerequisites are listed after the files.

### `ansible/requirements.yml`
```yaml
# Pin exact versions on build day (ansible-galaxy collection list)
collections:
  - name: amazon.aws
  - name: community.aws     # aws_ssm connection plugin
  - name: google.cloud
```

### `ansible/ansible.cfg`
```ini
[defaults]
inventory = inventories/
roles_path = roles
result_format = yaml
interpreter_python = auto_silent
forks = 10
timeout = 60

[ssh_connection]
pipelining = True
```

### `ansible/inventories/aws_ec2.yml`
```yaml
plugin: amazon.aws.aws_ec2
regions:
  - ap-south-1
filters:
  "tag:cb-ansible-role": k3s_server
  instance-state-name: running
hostnames:
  - instance-id
keyed_groups:
  - key: tags['cb-env']
    prefix: env
  - key: tags['cb-cloud']
    prefix: cloud
compose:
  # SSM targets the instance ID; never fall back to the public IP
  ansible_host: instance_id
  ansible_aws_ssm_instance_id: instance_id
  cb_cell: tags['cb-cell']
```

### `ansible/inventories/gcp_compute.yml`
```yaml
plugin: google.cloud.gcp_compute
projects:
  - "{{ lookup('ansible.builtin.env', 'GCP_PROJECT_ID') }}"
zones:
  - asia-south1-a
filters:
  - labels.cb-ansible-role = k3s_server
  - status = RUNNING
auth_kind: application
hostnames:
  - name
keyed_groups:
  - key: labels['cb-env']
    prefix: env
  - key: labels['cb-cloud']
    prefix: cloud
compose:
  # The plugin defaults ansible_host to the NAT IP; IAP tunnels need the instance name
  ansible_host: name
  gcp_zone: zone.split('/')[-1]
  gcp_project: selfLink.split('/')[6]
  cb_cell: labels['cb-cell']
```

### `ansible/inventories/group_vars/all.yml`
```yaml
k3s_version: "v1.36.2+k3s1"   # same minor as EKS/GKE — checked by the parity contract
k3s_minor: "1.36"
```

### `ansible/inventories/group_vars/cloud_aws.yml`
```yaml
ansible_connection: community.aws.aws_ssm
ansible_aws_ssm_region: ap-south-1
ansible_aws_ssm_bucket_name: cb-ansible-ssm-transfer   # created by Terraform global stack
ansible_become: true
cb_cloud: aws
```

### `ansible/inventories/group_vars/cloud_gcp.yml`
```yaml
ansible_connection: ansible.builtin.ssh
ansible_user: "{{ lookup('ansible.builtin.env', 'GCP_OSLOGIN_USER') }}"
ansible_ssh_common_args: >-
  -o StrictHostKeyChecking=accept-new
  -o ProxyCommand="gcloud compute start-iap-tunnel %h 22 --listen-on-stdin --zone={{ gcp_zone }} --project={{ gcp_project }}"
ansible_become: true
cb_cloud: gcp
```

### `ansible/roles/k3s_server/defaults/main.yml`
```yaml
k3s_disable: [traefik]          # Traefik is Argo CD-managed
k3s_kubelet_args:
  - "kube-reserved=cpu=100m,memory=256Mi"
  - "system-reserved=cpu=100m,memory=128Mi"
  - "eviction-hard=memory.available<100Mi"
# node-label is only applied when the node first registers
k3s_node_labels:
  - "cb-cell={{ cb_cell }}"
  - "cb-cloud={{ cb_cloud }}"
k3s_restart_on_change: true     # Molecule sets false (no systemd in the container)
```

### `ansible/roles/k3s_server/meta/argument_specs.yml`
```yaml
argument_specs:
  main:
    short_description: Install and configure a pinned single-node k3s server
    options: &opts
      k3s_version: {type: str, required: true}
      k3s_minor: {type: str, required: true}
      cb_cell: {type: str, required: true}
      cb_cloud: {type: str, required: true, choices: [aws, gcp]}
      k3s_disable: {type: list, elements: str}
      k3s_kubelet_args: {type: list, elements: str}
      k3s_node_labels: {type: list, elements: str}
      k3s_restart_on_change: {type: bool}
  config_only:
    short_description: Render /etc/rancher/k3s/config.yaml only
    options: *opts
```

### `ansible/roles/k3s_server/templates/config.yaml.j2`
```jinja
# Managed by Ansible (k3s_server role)
write-kubeconfig-mode: "0600"
disable: {{ k3s_disable | to_json }}
kubelet-arg: {{ k3s_kubelet_args | to_json }}
node-label: {{ k3s_node_labels | to_json }}
```

### `ansible/roles/k3s_server/tasks/config_only.yml`
```yaml
- name: Ensure k3s config directory
  ansible.builtin.file:
    path: /etc/rancher/k3s
    state: directory
    mode: "0755"

- name: Write k3s config
  ansible.builtin.template:
    src: config.yaml.j2
    dest: /etc/rancher/k3s/config.yaml
    mode: "0600"
  notify: Restart k3s
```

### `ansible/roles/k3s_server/tasks/main.yml`
```yaml
- name: Pinned version matches the parity-contract minor
  ansible.builtin.assert:
    that: k3s_version is match('^v' ~ (k3s_minor | regex_escape) ~ '\.[0-9]+\+k3s[0-9]+$')
    fail_msg: "k3s {{ k3s_version }} does not match contract minor {{ k3s_minor }}"
    quiet: true

- name: Render config
  ansible.builtin.import_tasks: config_only.yml

- name: Read installed k3s version
  ansible.builtin.command: k3s --version
  register: k3s_installed
  changed_when: false
  failed_when: false

- name: Decide whether the pinned version needs installing
  ansible.builtin.set_fact:
    k3s_needs_install: "{{ k3s_version not in (k3s_installed.stdout | default('')) }}"

- name: Download installer from the same tag as the binary
  ansible.builtin.get_url:
    url: "https://raw.githubusercontent.com/k3s-io/k3s/{{ k3s_version | urlencode }}/install.sh"
    dest: /usr/local/bin/k3s-install.sh
    mode: "0755"
    force: true
  when: k3s_needs_install | bool

- name: Install pinned k3s (installer restarts the service itself)
  ansible.builtin.command: /usr/local/bin/k3s-install.sh
  environment:
    INSTALL_K3S_VERSION: "{{ k3s_version }}"
  when: k3s_needs_install | bool
  changed_when: true

- name: Ensure k3s is enabled and running
  ansible.builtin.service:
    name: k3s
    state: started
    enabled: true

- name: Apply pending config restart before readiness check
  ansible.builtin.meta: flush_handlers

- name: Wait for node Ready (node object may not exist yet right after start)
  ansible.builtin.command: k3s kubectl wait --for=condition=Ready node --all --timeout=30s
  register: k3s_ready
  until: k3s_ready.rc == 0
  retries: 12
  delay: 10
  changed_when: false
```

### `ansible/roles/k3s_server/handlers/main.yml`
```yaml
- name: Restart k3s
  ansible.builtin.service:
    name: k3s
    state: restarted
  # A fresh install/upgrade already restarted k3s with the new config
  when:
    - k3s_restart_on_change | bool
    - not (k3s_needs_install | default(false) | bool)
```

### `ansible/playbooks/k3s.yml`
```yaml
- name: Configure k3s on budget-profile VMs
  hosts: all
  gather_facts: false          # don't connect until the transport is verified
  pre_tasks:
    - name: Refuse any transport other than SSM (EC2) or IAP (GCE)
      ansible.builtin.assert:
        that: >-
          ansible_connection == 'community.aws.aws_ssm' or
          (ansible_connection == 'ansible.builtin.ssh' and
           'start-iap-tunnel' in (ansible_ssh_common_args | default('')))
        fail_msg: "{{ inventory_hostname }} would be reached over direct SSH — not allowed"
        quiet: true

    - name: Gather facts
      ansible.builtin.setup:
  roles:
    - k3s_server
```

### Molecule: `ansible/roles/k3s_server/molecule/default/`
```yaml
# molecule.yml
driver:
  name: docker
platforms:
  - name: k3s-ubuntu
    image: ubuntu:24.04
provisioner:
  name: ansible
  inventory:
    group_vars:
      all:
        k3s_version: "v1.36.2+k3s1"
        k3s_minor: "1.36"
        cb_cell: cb-test-dev
        cb_cloud: aws
        k3s_restart_on_change: false
verifier:
  name: ansible
```
```yaml
# converge.yml — config only; k3s can't run in an unprivileged container
- name: Converge
  hosts: all
  tasks:
    - name: Render config
      ansible.builtin.include_role:
        name: k3s_server
        tasks_from: config_only
```
```yaml
# verify.yml
- name: Verify
  hosts: all
  tasks:
    - name: Read rendered config
      ansible.builtin.slurp:
        src: /etc/rancher/k3s/config.yaml
      register: cfg

    - name: Assert traefik disabled and labels present
      ansible.builtin.assert:
        that:
          - "'\"traefik\"' in (cfg.content | b64decode)"
          - "'cb-cell=cb-test-dev' in (cfg.content | b64decode)"
          - "'cb-cloud=aws' in (cfg.content | b64decode)"
```

Run it with: `cd ansible && ansible-playbook playbooks/k3s.yml`. Use `--limit cloud_aws` or `--limit cloud_gcp` to do one cloud at a time.

### Changes from the skill's reference version
- **GCE connection fix:** the GCE inventory plugin sets the host address to the public NAT IP by default. The IAP tunnel needs the instance name, so the reference version wouldn't have connected. The project and zone now come from each instance.
- **EC2 connection:** the SSM instance ID is set explicitly, so a missing value can't fall back to an IP.
- **Pinned installer:** the install script is downloaded from the k3s tag that matches the pinned version, not the unpinned `get.k3s.io`.
- **Readiness check retries:** right after k3s starts, the node may not be registered yet, which made the reference's single check fail. It now retries.
- **No double restart:** k3s isn't restarted again after an install or upgrade, because the installer already restarts it.
- **Stricter version check:** the minor-version check uses a regex, so a `1.3` pin can't match `1.36`.
- **No public IP in the certificate:** I removed `tls-san: <public IP>`. The k3s API is never exposed, so it shouldn't advertise one.

### What Terraform needs to provide (I haven't written this part)
- **EC2:**
  - The security group must have no rule allowing port 22 or 6443 in.
  - Each instance needs an instance profile with `AmazonSSMManagedInstanceCore`.
  - The `cb-ansible-ssm-transfer` S3 bucket must exist in ap-south-1.
  - Instances need outbound access to the SSM endpoints.
  - The machine running Ansible needs `session-manager-plugin` installed.
- **GCE:**
  - Allow port 22 **only** from Google's IAP range, `35.235.240.0/20`. Port 6443 stays closed.
  - Set `enable-oslogin=TRUE` on the instances.
  - The CI service account needs `roles/iap.tunnelResourceAccessor` and `roles/compute.osAdminLogin`.
- **Both clouds:** set the `cb-ansible-role=k3s_server`, `cb-cell`, `cb-cloud` and `cb-env` tags or labels.

**Unverified:** I'm not sure the GCE inventory plugin fills in `{{ lookup(...) }}` inside `projects:`. If it doesn't, put the project ID in directly.