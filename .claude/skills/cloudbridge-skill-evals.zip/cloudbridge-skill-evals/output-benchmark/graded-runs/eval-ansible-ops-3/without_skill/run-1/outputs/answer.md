I couldn't write the files: the working directory (`/tmp/cbout-60mlrhvo`) is empty, and this session can't write files or run shell commands. I've put the full role below so you can paste it into the repo.

I based it on the Terraform modules I found in an earlier scratchpad (`infra/modules/cluster/k3s-vm-aws` and `k3s-vm-gcp`). Those tag the VMs with `cb-ansible-role=k3s_server` and `cb-k8s-minor`. The AWS module connects through SSM, and the GCP module connects through IAP.

## How SSH stays closed to the internet

- **AWS:** port 22 is never opened. Ansible connects through SSM, and the role turns off and masks `sshd`. It refuses to do this unless the connection is actually SSM, so you can't lock yourself out.
- **GCE:** the only way in is IAP's address range (`35.235.240.0/20`, which your Terraform already allows). The role also sets the host firewall (ufw) to allow port 22 from that range only, and removes any "allow 22 from anywhere" rule.
- **Both:** the host firewall blocks all incoming traffic except port 443 and the cluster's internal pod and service networks. The Kubernetes API port (6443) is never opened, so you reach it through an SSM or IAP port-forward.

## Files

**`ansible/requirements.yml`**
```yaml
collections:
  - name: amazon.aws
    version: ">=8.0.0"   # aws_ssm connection plugin lives here from 8.0
  - name: google.cloud
  - name: community.general
```

**`ansible/inventory/aws_ec2.yml`**
```yaml
plugin: amazon.aws.aws_ec2
regions:
  - us-east-1            # set to your budget region(s)
filters:
  tag:cb-ansible-role: k3s_server
  instance-state-name: running
hostnames:
  - instance-id
compose:
  ansible_host: instance_id
  ansible_aws_ssm_region: placement.availability_zone[:-1]
  k3s_channel: "'v' ~ tags['cb-k8s-minor']"
groups:
  aws_k3s: true
  k3s_server: "tags.get('cb-ansible-role') == 'k3s_server'"
```

**`ansible/inventory/gcp_compute.yml`**
```yaml
plugin: google.cloud.gcp_compute
projects:
  - your-project-id      # set
auth_kind: application
filters:
  - labels.cb-ansible-role = k3s_server
  - status = RUNNING
hostnames:
  - name
compose:
  ansible_host: name
  gcp_project: selfLink.split('/')[6]
  gcp_zone: selfLink.split('/')[8]
  k3s_channel: "'v' ~ (labels['cb-k8s-minor'] | replace('-', '.'))"
groups:
  gcp_k3s: true
  k3s_server: "labels.get('cb-ansible-role') == 'k3s_server'"
```

**`ansible/group_vars/aws_k3s.yml`**
```yaml
ansible_connection: amazon.aws.aws_ssm
ansible_aws_ssm_bucket_name: "{{ lookup('env', 'CB_SSM_BUCKET') }}"
k3s_ssh_allow_cidrs: []
k3s_disable_sshd: true
```

**`ansible/group_vars/gcp_k3s.yml`**
```yaml
ansible_user: "{{ lookup('env', 'CB_OSLOGIN_USER') }}"
ansible_ssh_common_args: >-
  -o ProxyCommand="gcloud compute start-iap-tunnel {{ inventory_hostname }} 22
  --listen-on-stdin --zone={{ gcp_zone }} --project={{ gcp_project }} --verbosity=warning"
  -o StrictHostKeyChecking=accept-new
k3s_ssh_allow_cidrs:
  - 35.235.240.0/20      # IAP TCP forwarding only
k3s_disable_sshd: false
```

**`ansible/k3s.yml`**
```yaml
- name: Configure budget k3s servers
  hosts: k3s_server
  become: true
  roles:
    - k3s_server
```

**`ansible/roles/k3s_server/defaults/main.yml`**
```yaml
k3s_channel: ""                      # set per host from the cb-k8s-minor label, e.g. v1.31
k3s_install_script_url: https://get.k3s.io
k3s_disable: []                      # e.g. [traefik] if you bring your own ingress
k3s_cluster_cidr: 10.42.0.0/16
k3s_service_cidr: 10.43.0.0/16
k3s_ssh_allow_cidrs: []
k3s_disable_sshd: false
```

**`ansible/roles/k3s_server/tasks/main.yml`**
```yaml
- name: Require a pinned k3s minor channel
  ansible.builtin.assert:
    that: k3s_channel is match('^v1\.\d+$')
    fail_msg: "k3s_channel must look like v1.31 (from the cb-k8s-minor tag/label), got '{{ k3s_channel }}'"

- name: Host firewall
  ansible.builtin.import_tasks: firewall.yml

- name: Install k3s
  ansible.builtin.import_tasks: install.yml

- name: Lock down sshd
  ansible.builtin.import_tasks: sshd.yml
```

**`ansible/roles/k3s_server/tasks/firewall.yml`**
```yaml
- name: Install ufw
  ansible.builtin.apt:
    name: ufw
    state: present
    update_cache: true
    cache_valid_time: 3600

- name: Remove any open-to-the-world SSH rules
  community.general.ufw:
    rule: allow
    port: "22"
    proto: tcp
    delete: true

- name: Remove OpenSSH app profile rule
  community.general.ufw:
    rule: allow
    name: OpenSSH
    delete: true

- name: Allow SSH only from approved ranges
  community.general.ufw:
    rule: allow
    port: "22"
    proto: tcp
    from_ip: "{{ item }}"
  loop: "{{ k3s_ssh_allow_cidrs }}"

- name: Allow HTTPS (cloud firewall restricts the source to Cloudflare)
  community.general.ufw:
    rule: allow
    port: "443"
    proto: tcp

- name: Allow pod and service networks
  community.general.ufw:
    rule: allow
    from_ip: "{{ item }}"
  loop:
    - "{{ k3s_cluster_cidr }}"
    - "{{ k3s_service_cidr }}"

- name: Allow forwarded traffic to pods
  community.general.ufw:
    default: allow
    direction: routed

- name: Deny everything else inbound
  community.general.ufw:
    default: deny
    direction: incoming

- name: Enable ufw
  community.general.ufw:
    state: enabled
```

**`ansible/roles/k3s_server/tasks/install.yml`**
```yaml
- name: Create k3s config directory
  ansible.builtin.file:
    path: /etc/rancher/k3s
    state: directory
    mode: "0755"

- name: Write k3s config
  ansible.builtin.template:
    src: config.yaml.j2
    dest: /etc/rancher/k3s/config.yaml
    mode: "0600"
  notify: Restart k3s

- name: Read installed k3s version
  ansible.builtin.command: k3s --version
  register: k3s_installed
  changed_when: false
  failed_when: false

- name: Download k3s install script
  ansible.builtin.get_url:
    url: "{{ k3s_install_script_url }}"
    dest: /usr/local/bin/k3s-install.sh
    mode: "0755"

- name: Install or upgrade k3s to the pinned minor
  ansible.builtin.command: /usr/local/bin/k3s-install.sh
  environment:
    INSTALL_K3S_CHANNEL: "{{ k3s_channel }}"
  when: >-
    k3s_installed.rc != 0 or
    k3s_installed.stdout is not search('k3s version ' ~ (k3s_channel | regex_escape) ~ '\.')
  changed_when: true

- name: Wait for the node to be Ready
  ansible.builtin.command: k3s kubectl get nodes --no-headers
  register: k3s_nodes
  until: k3s_nodes.rc == 0 and ' Ready ' in k3s_nodes.stdout
  retries: 30
  delay: 10
  changed_when: false
```

**`ansible/roles/k3s_server/tasks/sshd.yml`**
```yaml
- name: Refuse to disable sshd unless connected via SSM
  ansible.builtin.assert:
    that: ansible_connection is search('aws_ssm')
    fail_msg: "k3s_disable_sshd is set but this host is not managed over SSM; refusing to lock you out."
  when: k3s_disable_sshd

- name: Stop and mask sshd (management is via SSM)
  ansible.builtin.systemd_service:
    name: "{{ item }}"
    state: stopped
    enabled: false
    masked: true
  loop:
    - ssh.socket
    - ssh.service
  when: k3s_disable_sshd
```

**`ansible/roles/k3s_server/handlers/main.yml`**
```yaml
- name: Restart k3s
  ansible.builtin.systemd_service:
    name: k3s
    state: restarted
```

**`ansible/roles/k3s_server/templates/config.yaml.j2`**
```yaml
# Managed by Ansible (k3s_server role)
write-kubeconfig-mode: "0600"
secrets-encryption: true
cluster-cidr: {{ k3s_cluster_cidr }}
service-cidr: {{ k3s_service_cidr }}
tls-san:
  - 127.0.0.1
{% if k3s_disable %}
disable:
{% for item in k3s_disable %}
  - {{ item }}
{% endfor %}
{% endif %}
```

**Run:**
```sh
ansible-galaxy collection install -r ansible/requirements.yml
CB_SSM_BUCKET=… CB_OSLOGIN_USER=… \
  ansible-playbook -i ansible/inventory/ ansible/k3s.yml
```

## Changes needed outside the role

1. **AWS SSM transfer bucket:** Ansible's SSM connection copies files through an S3 bucket. The `k3s-vm-aws` module doesn't create one, and the VM's role (`${name}-vm`) has no S3 access. You need a private bucket, plus read, write and delete access to it for both the instance role and whoever runs Ansible. Without that, the AWS run will fail on the first file copy.
2. **GCP permissions:** whoever runs Ansible needs `roles/iap.tunnelResourceAccessor` and `roles/compute.osAdminLogin`. If the VM sits on the `default` network, delete its `default-allow-ssh` rule, which allows SSH from any address and would bypass the IAP-only setup.
3. **Upgrades only:** changing `k8s_version` in Terraform updates the tag, and the next run upgrades k3s to that version. Lowering it won't downgrade k3s.

I haven't run `ansible-playbook --syntax-check` or `ansible-lint` on this, because I can't execute anything in this session. Run both before the first live run.