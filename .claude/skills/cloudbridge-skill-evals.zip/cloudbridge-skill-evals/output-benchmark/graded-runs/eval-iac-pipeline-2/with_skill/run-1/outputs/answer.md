You need three layers. A rule in CI blocks the merge. A protection in the Terraform code and the cloud stops the delete even if CI misses it. And you prove it works with tests at the rule, plan, workflow and settings level.

I haven't built or run any of this. This workspace contains only the CloudBridge skill docs, not your repo. The design below comes from the plan-risk gate in those docs. Reading the docs' example workflow, I found four ways a delete could get past it as written. They're listed in step 1 with the fixes.

## 1. The CI block

The plan-risk rule in `control-plane/plan-risk/rules.py` already treats these types as stateful: `aws_db_instance`, `aws_rds_cluster` and `google_sql_database_instance`. Any planned change on one of them whose actions include `delete` gets `block`. That covers removing the resource and both kinds of replace (`["delete","create"]` and `["create","delete"]`). A block fails the PR unless someone adds the `allow-destructive` label, and that override gets logged.

The four gaps, and the fix for each:

1. **A failed plan currently lets the PR through.** The comment job runs with `if: always()` and only checks the `risk.json` files that exist. If a stack's plan job fails or never runs, there is no file to check, so nothing blocks. Fix: make one job, `iac-gate`, the only required check, and have it fail unless every planned stack produced a result.
2. **Required checks and `paths:` filters don't mix.** With `paths: ["infra/**"]`, PRs that don't touch infra never report the check, so they wait forever. Fix: remove the filter. The change-detection step returns an empty list for those PRs and the gate passes straight away.
3. **The override label stays on new commits.** Once someone adds `allow-destructive`, later pushes to the PR are still allowed through. Fix: ignore the label on `synchronize` (new commit) events and remove it, so a reviewer has to add it again for the new plan.
4. **Merging re-plans, and nothing checks that second plan.** Run the same rules in apply mode, just before `terraform apply tfplan`. Fail if the result is `block` and the merged PR did not have the label.

```yaml
# iac-pr.yml
on:
  pull_request:
    types: [opened, synchronize, reopened, labeled, unlabeled]   # no paths: filter

  iac-gate:                      # the ONLY required status check
    needs: [detect, plan]
    if: always()
    runs-on: ubuntu-24.04
    steps:
      - name: Fail closed
        run: |
          [ "${{ needs.detect.result }}" = success ] || exit 1
          case "${{ needs.plan.result }}" in success|skipped) ;; *) echo "::error::a plan failed"; exit 1;; esac
      - uses: actions/download-artifact@<sha>
        with: { path: artifacts }
      - name: Enforce plan-risk
        env:
          GH_TOKEN: ${{ github.token }}
          EXPECTED: ${{ needs.detect.outputs.stacks }}
        run: |
          want=$(jq length <<<"$EXPECTED"); got=$(ls artifacts/plan-*/risk.json 2>/dev/null | wc -l)
          [ "$got" -eq "$want" ] || { echo "::error::$want stacks planned, $got risk reports"; exit 1; }
          blocked=$(jq -s 'map(select(.verdict=="block")) | length' artifacts/plan-*/risk.json)
          [ "$blocked" -eq 0 ] && exit 0
          override=$(jq -r '[.pull_request.labels[].name] | index("allow-destructive") != null' "$GITHUB_EVENT_PATH")
          if [ "${{ github.event.action }}" = synchronize ]; then
            override=false
            gh pr edit ${{ github.event.pull_request.number }} --remove-label allow-destructive || true
          fi
          [ "$override" = true ] || { echo "::error::plan-risk BLOCK: deletes a stateful resource"; exit 1; }
```

Also check who added the label: on `labeled` events, confirm that `github.event.sender.login` is in a DB-owners team. Otherwise anyone with triage access can override the block.

## 2. Protections that work without CI

- **In Terraform:** `lifecycle { prevent_destroy = true }` on both DB modules. This is already in the terraform-cells design. Any plan that deletes the instance then errors, and with the fail-closed fix that failed plan turns the gate red. On its own it isn't enough, because the same PR can remove the line.
- **In the cloud:** turn on deletion protection: `deletion_protection = true` on RDS, and both `deletion_protection` and `settings.deletion_protection_enabled` on Cloud SQL. Because this lives in the cloud, a delete takes two separate applies (first turn protection off, then delete), so one PR can't do both.
- **In IAM (the final safety net):** take `rds:DeleteDBInstance` / `rds:DeleteDBCluster` and `cloudsql.instances.delete` away from the prod apply roles. On AWS use an explicit Deny; on GCP use a custom role without the permission. Real deletions then go through a separate break-glass role.

Add a `warn` rule for the first step of that two-step path: deletion protection going true→false, or `skip_final_snapshot` going to true. The rules currently look only at the planned values, not the current ones, so this rule also needs to read `change.before`.

## 3. Proving it works

| Level | What you run | What counts as proof |
|---|---|---|
| Rules | `evals/plan-risk/run_eval.py` on every PR that touches the gate (required check) | Block-class recall = 1.00 on the cases below |
| Real plan output | Fixtures made by real `terraform plan`, not hand-written JSON | The rule matches what Terraform actually outputs |
| Workflow | Test PRs against a dev stack | The check goes red or green as in the table below |
| Settings | `gh api repos/<you>/cloudbridge/rulesets` | `iac-gate` is required, with no admin bypass |

**Test cases to add for RDS and Cloud SQL (each on both clouds):**
- Should block:
  - The resource block deleted.
  - Removed via `count` going 1→0, or a `for_each` key removed.
  - The whole module removed, or a stack switched from `cloud = "aws"` to `"gcp"`.
  - A replace forced by a change that recreates it (RDS `identifier`, Cloud SQL `name`/`region`).
  - A replace with `create_before_destroy`, which comes out as `["create","delete"]`.
- Should pass (traps that must not block):
  - An in-place update such as `backup_retention_period`.
  - A rename with a `moved` block.
  - A `removed { lifecycle { destroy = false } }` block, which produces a `forget` action, not a delete.
  - A data source with the same type.
- Should warn: deletion protection being turned off.

**Real plan fixtures:** hand-written JSON only shows the rule matches your own guesses. Build each fixture from a minimal config, a state file with the instance in it, and `terraform plan -refresh=false -out=p && terraform show -json p`. This should work offline with fake credentials: AWS `skip_credentials_validation` / `skip_requesting_account_id`, and a dummy Google `access_token`. Also generate them with `tofu`, since CI runs both Terraform and OpenTofu.

**Test PRs on a dev stack:**

| PR | Expected `iac-gate` |
|---|---|
| Remove the RDS instance | Red. A plan error from `prevent_destroy` also counts as red |
| Remove `prevent_destroy` and the RDS instance in one PR | Red (`stateful-destroy`) |
| Same, plus the `allow-destructive` label | Green, with an override row in `plan_risk_reports` |
| Push a new commit after the label | Red again, label removed |
| Same four for Cloud SQL | Same results |
| Break the plan on purpose (bad provider credentials) | Red (fail-closed) |
| A docs-only PR | Green, and quick |

Save the run links as evidence. If you want this to keep being true, a weekly scheduled job can open a draft test PR with `gh pr create --draft` and check that the gate fails.

Should I write these files into the repo (rules changes, test cases, fixture generator, `iac-gate` job, IAM changes)? If so, tell me where the CloudBridge repo is checked out.