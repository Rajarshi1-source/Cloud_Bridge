Your working directory is empty, so I couldn't see your setup. This answer assumes **Terraform on GitHub Actions**, which is the most common way to manage both RDS and Cloud SQL from one repo. Tell me if you use something else and I'll adapt it.

I couldn't run any commands in this session, so the policy and tests below are untested. Step 4 is where you prove it works yourself.

## The idea

CI runs `terraform plan`, turns the plan into JSON and runs a policy against it. The check fails if a database instance would be deleted or replaced, or if its deletion protection would be turned off. A branch rule then makes that check required, so a red check blocks the merge.

`prevent_destroy` and `deletion_protection` on their own aren't enough. If a PR removes the whole resource block, those settings disappear along with it. The plan shows what would actually happen, so checking the plan catches it.

## 1. The policy: `policy/db_guard.rego`

```rego
package main

import rego.v1

protected_types := {
	"aws_db_instance",
	"aws_rds_cluster",
	"aws_rds_cluster_instance",
	"google_sql_database_instance",
}

# Catches deletes and replacements; a replacement's actions include "delete" in either order
deny contains msg if {
	some rc in input.resource_changes
	protected_types[rc.type]
	"delete" in rc.change.actions
	msg := sprintf("%s would be DELETED/REPLACED (actions: %v)", [rc.address, rc.change.actions])
}

# Turning protection off is usually step 1 of a two-PR delete
deny contains msg if {
	some rc in input.resource_changes
	protected_types[rc.type]
	rc.change.before.deletion_protection == true
	rc.change.after.deletion_protection == false
	msg := sprintf("%s: deletion_protection is being disabled", [rc.address])
}

deny contains msg if {
	some rc in input.resource_changes
	rc.type == "google_sql_database_instance"
	rc.change.before.settings[0].deletion_protection_enabled == true
	rc.change.after.settings[0].deletion_protection_enabled == false
	msg := sprintf("%s: settings.deletion_protection_enabled is being disabled", [rc.address])
}

# A `removed { lifecycle { destroy = false } }` block leaves the DB running but stops Terraform managing it
warn contains msg if {
	some rc in input.resource_changes
	protected_types[rc.type]
	"forget" in rc.change.actions
	msg := sprintf("%s is being removed from Terraform state", [rc.address])
}
```

A replacement is the case people usually miss. Changing a field like `identifier`, `engine` or the Cloud SQL `name` quietly destroys the database and creates a new one. The first rule catches that.

## 2. Tests for the policy: `policy/db_guard_test.rego`

```rego
package main

import rego.v1

rc(t, actions, before, after) := {
	"address": sprintf("%s.main", [t]), "type": t,
	"change": {"actions": actions, "before": before, "after": after},
}

test_rds_delete_blocked if {
	p := {"resource_changes": [rc("aws_db_instance", ["delete"], {}, null)]}
	count(deny) == 1 with input as p
}

test_cloudsql_delete_blocked if {
	p := {"resource_changes": [rc("google_sql_database_instance", ["delete"], {}, null)]}
	count(deny) == 1 with input as p
}

test_replace_blocked if {
	p := {"resource_changes": [rc("aws_db_instance", ["delete", "create"], {}, {})]}
	count(deny) == 1 with input as p
}

test_create_before_destroy_replace_blocked if {
	p := {"resource_changes": [rc("aws_rds_cluster", ["create", "delete"], {}, {})]}
	count(deny) == 1 with input as p
}

test_rds_protection_off_blocked if {
	p := {"resource_changes": [rc("aws_db_instance", ["update"],
		{"deletion_protection": true}, {"deletion_protection": false})]}
	count(deny) == 1 with input as p
}

test_cloudsql_api_protection_off_blocked if {
	p := {"resource_changes": [rc("google_sql_database_instance", ["update"],
		{"settings": [{"deletion_protection_enabled": true}]},
		{"settings": [{"deletion_protection_enabled": false}]})]}
	count(deny) == 1 with input as p
}

test_in_place_update_allowed if {
	p := {"resource_changes": [rc("aws_db_instance", ["update"],
		{"deletion_protection": true, "instance_class": "db.t4g.medium"},
		{"deletion_protection": true, "instance_class": "db.t4g.large"})]}
	count(deny) == 0 with input as p
}

test_other_resource_delete_allowed if {
	p := {"resource_changes": [rc("aws_s3_bucket", ["delete"], {}, null)]}
	count(deny) == 0 with input as p
}
```

The tests that expect "allowed" matter as much as the ones that expect "blocked". A policy that blocks everything would also pass the blocked tests.

## 3. The workflow: `.github/workflows/db-guard.yml`

```yaml
name: db-guard
on: pull_request
permissions: { contents: read, id-token: write }

jobs:
  db-guard:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: hashicorp/setup-terraform@v3
        with: { terraform_wrapper: false }   # otherwise the wrapper corrupts `show -json` output
      # Cloud auth via OIDC: aws-actions/configure-aws-credentials and/or google-github-actions/auth
      - run: |
          curl -sSL https://github.com/open-policy-agent/conftest/releases/download/v0.56.0/conftest_0.56.0_Linux_x86_64.tar.gz \
            | tar xz conftest
      - run: ./conftest verify --policy policy/        # run the policy's own tests first
      - run: terraform init -input=false
      - run: terraform plan -input=false -lock=false -out=tfplan
      - run: terraform show -json tfplan > plan.json
      - run: ./conftest test plan.json --policy policy/ --no-color
```

If you have more than one Terraform root folder, use a matrix so every one that contains a database gets planned. Pin the actions to commit SHAs.

## 4. Proving it works

You need evidence at three levels:

1. **The policy logic is right.** Run `conftest verify --policy policy/` (or `opa test policy/ -v`). It runs on every PR, so if someone weakens the policy, its tests fail.
2. **The whole pipeline catches it.** Open throwaway draft PRs against a real database config:
   - Delete the `aws_db_instance` block.
   - Change the Cloud SQL `name`, which forces a replacement.
   - Set `deletion_protection = false`.

   Each one should turn `db-guard` red with a clear message. Then open one PR with a harmless change, like a tag, and check that it stays green. Keep the links to these PRs as your evidence.
3. **A red check actually blocks the merge.** Make `db-guard` a required status check in a branch ruleset on `main`, and don't allow bypass, including for admins. To confirm:
   ```bash
   gh api repos/OWNER/REPO/rules/branches/main
   ```
   The output should list a `required_status_checks` rule containing `db-guard`. Then look at one of the red test PRs and confirm the Merge button is disabled. Without this setting, a failing check is only a warning.

## Gaps to close, or the proof doesn't hold

- **Apply the plan that was checked.** If the merge pipeline runs a fresh `terraform apply`, it can do something different from what the PR's plan showed. Either save the plan and apply that file, or run the same policy check again before `apply`.
- **Protect the guard itself.** Add `policy/` and `.github/workflows/` to CODEOWNERS and require code-owner review. Otherwise one PR could remove the database and the guard together.
- **Turn protection on everywhere:**
  - RDS: `deletion_protection = true`.
  - Cloud SQL: both `deletion_protection = true` (Terraform's own setting) and `settings { deletion_protection_enabled = true }` (the GCP-side setting).
  - `lifecycle { prevent_destroy = true }` on each database resource.
- **CI only covers changes made through Terraform.** To also block deletes from the console or CLI, add an AWS SCP that denies `rds:DeleteDBInstance` and `rds:DeleteDBCluster`, and a GCP IAM deny policy on `cloudsql.googleapis.com/instances.delete`.
- **When you really do need to delete one:** do it as a deliberate two-step change that the code owners approve. Don't add a bypass label or environment variable to the policy, because anyone who can open a PR could use it.

If you point me at your repo, I can add these files, fit the workflow to how your folders and cloud auth are set up, and run the policy tests.