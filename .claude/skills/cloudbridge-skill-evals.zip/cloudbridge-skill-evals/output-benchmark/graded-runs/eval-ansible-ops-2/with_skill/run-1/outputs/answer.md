**Short answer for the interviewer:** Terraform and Argo CD both *declare state and reconcile toward it*. CloudBridge has two kinds of work that don't fit that model, and Ansible handles both:

1. **Configuring the budget-profile VMs.** These are EC2/GCE hosts running k3s, and there are no golden images yet. Somebody has to harden the OS, install a pinned k3s, set up the registry mirror, node_exporter and origin certs. That's idempotent host configuration, which is what Ansible is for.
2. **Running procedures.** Evacuation, failback, pre-warm and drills are multi-step sagas with checks, waits, branches and rollback. No resource ends up in the desired state, so there's nothing for Terraform or Argo CD to declare.

## The split

| Layer | Owner | Why |
|---|---|---|
| VMs, networks, firewalls, IAM, clusters, databases, Cloudflare LB and weights | **Terraform** | Needs state, plan and drift detection |
| Apps and cluster add-ons | **Argo CD** | Keeps reconciling from Git |
| OS hardening, k3s install, exporters, origin TLS, registry mirror on budget VMs | **Ansible** | Long-lived hosts that change over time need idempotent config |
| Argo CD bootstrap on budget k3s | **Ansible** drops a k3s `HelmChart` + root ApplicationSet into `/var/lib/rancher/k3s/server/manifests/` | The k3s API is never exposed, and k3s applies that directory on its own. Managed EKS/GKE cells get the same chart from Terraform's `20-bootstrap` stack |
| Evacuate / failback / pre-warm / drill | **Ansible playbooks** | Sagas that need a rollback step |
| Alertmanager alert → action | **Event-Driven Ansible (`ansible-rulebook`)** | Outside prod it runs a drill. In prod it only opens a PR proposing the evacuation, and a human merges it |

Each object has exactly one owner. Ansible never creates cloud resources, and it never manages app releases.

## How they connect: tags, not state

Terraform tags each budget VM (`cb-ansible-role`, `cb-cell`, `cb-cloud`, `cb-env`). The `aws_ec2` and `gcp_compute` dynamic inventory plugins build groups from those tags, so Ansible never reads Terraform state. There's no public SSH: AWS hosts are reached through SSM Session Manager, GCP hosts through IAP. The one place Ansible calls Terraform is the evacuation playbook. It runs `community.general.terraform` on the traffic stack, so weight changes still go through Terraform as their owner.

## Alternatives I rejected (worth saying out loud)

- **Terraform `remote-exec` / `local-exec` provisioners:** if a provisioner fails, Terraform taints the resource, and any change to the config means replacing the VM.
- **The `ansible/ansible` Terraform provider:** it ties inventory to reads of Terraform state.
- **Ansible `helm` for apps:** that gives releases a second owner. It's the same bug the first version had with Terraform plus `helm upgrade`.

## Why the evacuation saga is the strongest argument

1. Record the current weights so there's something to roll back to.
2. Capacity check: `capacity_ratio = HPA max × per-pod RPS / 7-day peak RPS`. It must be at least 1.2.
3. If it's short, pre-warm and check again. If it's still short, **refuse**. Evacuating into an undersized cell turns a one-cloud incident into a two-cloud outage.
4. Shift traffic in steps (50 → 25 → 0). After each step, wait for the health monitor and draining, then check burn rate and p95 latency on the receiving cell. Abort if they're over the limits.
5. A `rescue:` block puts the recorded weights back if anything fails.
6. Write a dated drill report.

It runs from a GitHub Actions runner outside both clouds, because the escape hatch can't live in the building that's on fire.

## Soundbites

- "Terraform builds the house, Argo CD keeps the furniture in place, and Ansible configures the rooms that aren't prefabricated and runs the fire drill."
- "Health-based failover asks *is it up?* My playbook asks *can it take the load?*, and it refuses if the answer is no."
- "In dev, automation acts. In prod, automation writes the PR."

**A follow-up they might ask:** "Would Ansible go away later?" Partly. If you move to golden images built with Packer, or to managed EKS/GKE only, the host-configuration job mostly disappears. The procedure job stays, because drills and evacuations are still sagas that need someone to run them. Admitting this shows you picked Ansible on purpose and didn't just reach for it by habit.