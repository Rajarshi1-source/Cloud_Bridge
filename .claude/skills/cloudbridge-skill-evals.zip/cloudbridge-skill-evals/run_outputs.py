#!/usr/bin/env python3
"""With-skill vs without-skill output runs for the CloudBridge test prompts (headless `claude -p`).

with_skill   : throwaway project with ALL nine CloudBridge skills installed under .claude/skills/
without_skill: throwaway project with no CloudBridge skills
Both: same model, same tools (Read/Glob/Grep/Skill only — no web, no shell, no writes), answer captured
from the final result. Layout follows skill-creator: <ws>/iteration-N/<eval-name>/<config>/outputs/answer.md
"""
import argparse, json, os, shutil, subprocess, tempfile, time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

def run(prompt: str, skills_dir: Path | None, model: str, timeout: int) -> dict:
    proj = Path(tempfile.mkdtemp(prefix="cbout-"))
    try:
        if skills_dir:
            dest = proj / ".claude" / "skills"
            dest.mkdir(parents=True)
            for d in skills_dir.iterdir():
                if (d / "SKILL.md").exists():
                    shutil.copytree(d, dest / d.name, ignore=shutil.ignore_patterns("evals"))
        cmd = ["claude", "-p", prompt, "--output-format", "stream-json", "--verbose", "--model", model,
               "--max-turns", "20", "--allowedTools", "Read,Glob,Grep,Skill",
               "--disallowedTools", "Bash,Write,Edit,WebSearch,WebFetch,Agent"]
        env = {k: v for k, v in os.environ.items() if k != "CLAUDECODE"}
        t0 = time.time()
        p = subprocess.run(cmd, cwd=proj, env=env, capture_output=True, text=True, timeout=timeout)
        dur = time.time() - t0
        tools, result, usage, err = [], "", {}, None
        for line in p.stdout.splitlines():
            try:
                ev = json.loads(line)
            except json.JSONDecodeError:
                continue
            if ev.get("type") == "assistant":
                for c in ev["message"].get("content", []):
                    if c.get("type") == "tool_use":
                        tools.append({"name": c["name"], "input": json.dumps(c.get("input", {}))[:200]})
                    pass
            if ev.get("type") == "result":
                result = ev.get("result") or ""
                usage = ev.get("usage") or {}
                low = result.lower()
                if ev.get("is_error") or not result.strip():
                    err = "usage-limit" if ("limit" in low and "reset" in low) else "result-error"
        return {"answer": result, "tools": tools, "seconds": round(dur, 1), "usage": usage, "error": err}
    except subprocess.TimeoutExpired:
        return {"answer": "", "tools": [], "seconds": timeout, "usage": {}, "error": "timeout"}
    finally:
        shutil.rmtree(proj, ignore_errors=True)

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--skills-dir", required=True)
    ap.add_argument("--prompts", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--model", default="claude-opus-5-5")
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--timeout", type=int, default=900)
    ap.add_argument("--only", nargs="*", help="eval dir names to (re)run")
    ap.add_argument("--configs", nargs="*", default=["with_skill", "without_skill"])
    a = ap.parse_args()
    skills_dir, out = Path(a.skills_dir), Path(a.out)
    data = json.loads(Path(a.prompts).read_text())
    jobs = []
    for skill, evals in data["skills"].items():
        for e in evals:
            name = f"{skill.removeprefix('cloudbridge-')}-{e['id']}"
            if a.only and name not in a.only:
                continue
            for cfg in a.configs:
                jobs.append((name, skill, e, cfg))
    with ThreadPoolExecutor(max_workers=a.workers) as ex:
        futs = {ex.submit(run, e["prompt"], skills_dir if cfg == "with_skill" else None, a.model, a.timeout): (n, s, e, cfg)
                for n, s, e, cfg in jobs}
        for f in as_completed(futs):
            n, s, e, cfg = futs[f]
            r = f.result()
            d = out / n / cfg / "outputs"
            d.mkdir(parents=True, exist_ok=True)
            (d / "answer.md").write_text(r["answer"])
            (d.parent / "transcript.json").write_text(json.dumps({"tools": r["tools"], "error": r["error"]}, indent=2))
            tok = sum(v for k, v in r["usage"].items() if isinstance(v, int) and k.endswith("tokens"))
            (d.parent / "timing.json").write_text(json.dumps({"total_tokens": tok, "total_duration_seconds": r["seconds"]}))
            meta = out / n / "eval_metadata.json"
            if not meta.exists():
                meta.write_text(json.dumps({"eval_id": e["id"], "eval_name": n, "skill": s,
                                            "prompt": e["prompt"], "assertions": e["assertions"]}, indent=2))
            used = [t["input"] for t in r["tools"] if t["name"] in ("Skill", "Read")]
            print(f"{n:<34} {cfg:<14} {r['seconds']:>6}s err={r['error']} chars={len(r['answer'])} skill_reads={len(used)}", flush=True)

if __name__ == "__main__":
    main()
