#!/usr/bin/env python3
"""Sibling-aware trigger (routing) eval for the CloudBridge skill set.

Unlike skill-creator's run_eval.py (one skill at a time), this installs ALL nine CloudBridge skills
as project commands in a throwaway project dir, runs `claude -p <query>`, and records which skill
(if any) Claude consults first. That measures the real failure mode for a skill family: picking the
wrong sibling, or triggering on another capstone's request.

Usage: python3 route_eval.py --skills-dir ../cloudbridge-skills --eval-set trigger_eval_set.json \
         --runs 2 --workers 8 --model claude-opus-5-5 --out results.json
"""
import argparse, json, os, re, select, shutil, subprocess, tempfile, time
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

def load_skills(skills_dir: Path) -> dict[str, str]:
    out = {}
    for p in sorted(skills_dir.glob("*/SKILL.md")):
        t = p.read_text()
        fm = re.match(r"^---\n(.*?)\n---", t, re.S).group(1)
        name = re.search(r"^name:\s*(.+)$", fm, re.M).group(1).strip()
        desc = re.search(r"^description:\s*(.+)$", fm, re.M).group(1).strip()
        out[name] = desc
    return out

def run_one(query: str, skills: dict[str, str], timeout: int, model: str | None) -> str:
    proj = Path(tempfile.mkdtemp(prefix="cbroute-"))
    try:
        cmd_dir = proj / ".claude" / "commands"
        cmd_dir.mkdir(parents=True)
        for name, desc in skills.items():
            indented = "\n  ".join(desc.split("\n"))
            (cmd_dir / f"{name}.md").write_text(f"---\ndescription: |\n  {indented}\n---\n\n# {name}\n\nThis skill handles: {desc}\n")
        cmd = ["claude", "-p", query, "--output-format", "stream-json", "--verbose", "--include-partial-messages"]
        if model:
            cmd += ["--model", model]
        env = {k: v for k, v in os.environ.items() if k != "CLAUDECODE"}
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, cwd=proj, env=env)
        buf, pending, acc, start = "", None, "", time.time()
        try:
            while time.time() - start < timeout:
                if proc.poll() is not None and not select.select([proc.stdout], [], [], 0)[0]:
                    break
                r, _, _ = select.select([proc.stdout], [], [], 1.0)
                if not r:
                    continue
                chunk = os.read(proc.stdout.fileno(), 8192)
                if not chunk:
                    break
                buf += chunk.decode("utf-8", "replace")
                while "\n" in buf:
                    line, buf = buf.split("\n", 1)
                    try:
                        ev = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if ev.get("type") == "assistant":
                        for c in ev.get("message", {}).get("content", []):
                            txt = c.get("text", "") if c.get("type") == "text" else ""
                            if "limit" in txt.lower() and ("session" in txt.lower() or "usage" in txt.lower()):
                                return "error:usage-limit"      # not a routing decision — exclude from scoring
                        continue
                    if ev.get("type") != "stream_event":
                        if ev.get("type") == "result":
                            if ev.get("is_error") or not ev.get("modelUsage"):
                                return "error:result"
                            return "none"
                        continue
                    se = ev.get("event", {})
                    if se.get("type") == "content_block_start":
                        cb = se.get("content_block", {})
                        if cb.get("type") == "tool_use":
                            if cb.get("name") in ("Skill", "Read"):
                                pending, acc = cb["name"], ""
                            else:
                                return f"other-tool:{cb.get('name')}"
                    elif se.get("type") == "content_block_delta" and pending:
                        acc += se.get("delta", {}).get("partial_json", "")
                    elif se.get("type") == "content_block_stop" and pending:
                        for name in skills:
                            if name in acc:
                                return name
                        m = re.search(r'"(?:skill|file_path)"\s*:\s*"([^"]+)"', acc)
                        return f"other-skill:{m.group(1) if m else acc[:60]}"
                    elif se.get("type") == "message_stop":
                        return "none"
            return "timeout"
        finally:
            if proc.poll() is None:
                proc.kill()
                proc.wait()
    finally:
        shutil.rmtree(proj, ignore_errors=True)

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--skills-dir", required=True)
    ap.add_argument("--eval-set", required=True)
    ap.add_argument("--runs", type=int, default=2)
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--timeout", type=int, default=90)
    ap.add_argument("--model", default=None)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    skills = load_skills(Path(a.skills_dir))
    items = json.loads(Path(a.eval_set).read_text())
    preds: dict[int, list[str]] = defaultdict(list)
    with ProcessPoolExecutor(max_workers=a.workers) as ex:
        futs = {ex.submit(run_one, it["query"], skills, a.timeout, a.model): i
                for i, it in enumerate(items) for _ in range(a.runs)}
        for f in as_completed(futs):
            try:
                preds[futs[f]].append(f.result())
            except Exception as e:
                preds[futs[f]].append(f"error:{e}")

    rows, per_skill = [], defaultdict(lambda: Counter())
    for i, it in enumerate(items):
        got = preds[i]
        exp = it["expect"]
        def ok(g: str) -> bool:
            return g == exp if exp != "none" else not g.startswith("cloudbridge-")
        valid = [g for g in got if not g.startswith(("error:", "timeout"))]
        if not valid:
            rows.append({"query": it["query"], "expect": exp, "got": got, "pass_rate": None, "pass": None})
            per_skill[exp]["invalid"] += 1
            continue
        rate = sum(ok(g) for g in valid) / len(valid)
        rows.append({"query": it["query"], "expect": exp, "got": got, "pass_rate": rate, "pass": rate >= 0.5})
        per_skill[exp]["total"] += 1
        per_skill[exp]["pass"] += rate >= 0.5
        for g in got:
            if g.startswith("cloudbridge-") and g != exp:
                per_skill[exp][f"confused_with:{g}"] += 1
    summary = {k: dict(v) for k, v in per_skill.items()}
    scored = [r for r in rows if r["pass"] is not None]
    passed = sum(r["pass"] for r in scored)
    pos = [r for r in scored if r["expect"] != "none"]
    neg = [r for r in scored if r["expect"] == "none"]
    report = {"total": len(rows), "scored": len(scored), "invalid": len(rows) - len(scored), "passed": passed,
              "positive_accuracy": round(sum(r["pass"] for r in pos) / len(pos), 3) if pos else None,
              "negative_accuracy": round(sum(r["pass"] for r in neg) / len(neg), 3) if neg else None,
              "per_skill": summary, "rows": rows}
    Path(a.out).write_text(json.dumps(report, indent=2))
    print(json.dumps({k: report[k] for k in ("total", "scored", "invalid", "passed", "positive_accuracy", "negative_accuracy")}, indent=2))
    for r in rows:
        if r["pass"] is False:
            print(f"FAIL expect={r['expect']:<38} got={r['got']} :: {r['query'][:80]}")

if __name__ == "__main__":
    main()
